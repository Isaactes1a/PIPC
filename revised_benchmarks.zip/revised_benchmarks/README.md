# Revised PIPC submission benchmarks

This directory is the active reproduction entry point for the revised manuscript. Historical experiments remain in sibling directories for provenance and are intentionally excluded from the submission dataset.

## Environment

- Python 3.12, NumPy, SciPy, Matplotlib
- PyTorch with float64 support; CUDA is used when available
- XeLaTeX, BibTeX, and Poppler for the manuscript and visual audit

Every method writes the same versioned JSON record plus NPZ field/history arrays. Reference generation is excluded from method timing, while operator/feature construction and the complete solve are included.

## Run order

Use `--quick` first on each solver. Full commands are:

```powershell
python beam_three_method.py --output results/beam_full
python heat_three_method.py --output results/heat_full
python plate_linear_three_method.py --output results/plate_linear_full
python plate_three_method.py --output results/plate_full
```

Generate figures and tables only after those commands have completed:

```powershell
python make_result_figures.py --beam results/beam_full --heat results/heat_full --plate results/plate_full --linear-plate results/plate_linear_full --output ../../PIPC_LaTeX_Package/figures
python make_tables.py --beam results/beam_full --heat results/heat_full --plate results/plate_full --linear-plate results/plate_linear_full --output ../../PIPC_LaTeX_Package/generated_tables
```

The plate-reference, initialization, and spatial-refinement audits used in the
manuscript are reproduced separately so that their checkpoints can be resumed:

```powershell
$env:OMP_NUM_THREADS='1'; $env:OPENBLAS_NUM_THREADS='1'; $env:MKL_NUM_THREADS='1'
python reference_convergence_audit.py --plate-only --output results/reference_convergence_audit.json
python reference_convergence_audit.py --extend-square --output results/reference_convergence_audit.json
python initialization_robustness.py --workers 2 --output results/initialization_robustness
python rbffd_convergence.py --reference results/reference_convergence_fields.npz --output results/rbffd_convergence
python refresh_plate_benchmarks.py
python make_enhancement_outputs.py
```

The worker count and single-threaded BLAS settings keep the concurrent
initialization runs within a bounded memory footprint.  `--quick` is available
for smoke testing, and the two long-running audit scripts resume from existing
per-case checkpoints unless `--no-resume` is supplied.

Then run `validate_submission.py` on all four JSON files and compile `PIPC_LaTeX_Package/main.tex` with XeLaTeX and BibTeX. Plotting scripts never call a solver or contain hand-entered result values.

## Interpretation

`constraint_bc_linf` is the error at PIPC's finite constraint set. `dense_boundary_linf` is an independent trace audit between those points. PINN optimizer steps, CL-PIELM/PIELM linear solves, and PIPC nonlinear residual evaluations are retained as different counters.
