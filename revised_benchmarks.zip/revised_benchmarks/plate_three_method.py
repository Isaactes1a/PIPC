"""Nonlinear von Karman plate comparison: PIPC, CL-PIELM, PINN, and FEM."""

from __future__ import annotations

import argparse
import importlib.util
import json
import math
import sys
import time
from pathlib import Path

import numpy as np
import torch
from scipy.interpolate import griddata

from common import MethodRecord, SEEDS, summarize_stochastic, write_results
import phs_rbf_fd as PHS


HERE = Path(__file__).resolve().parent
LEGACY = HERE.parent / "ablation_pielm"
if str(LEGACY) not in sys.path:
    sys.path.insert(0, str(LEGACY))
DEFAULT_OUTPUT = HERE / "results" / "plate"


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, LEGACY / filename)
    module = importlib.util.module_from_spec(spec); sys.modules[name] = module
    assert spec.loader is not None; spec.loader.exec_module(module); return module


P = load("audited_plate_pipc", "plate_cpi_trf.py")
FEM = load("audited_plate_fem", "plate_vk_fem.py")
torch.set_default_dtype(torch.float64)


def cfg(shape, quick):
    if quick:
        return {"N_grid": 10, "N_bnd": 50, "N_layers": 4, "eval_N": 41}
    return {"N_grid": 20, "N_bnd": 100, "N_layers": 6, "eval_N": 81}


def gaussian_ops(points, centers, sigma):
    d = points[:, None, :] - centers[None, :, :]
    x, y = d[..., 0], d[..., 1]; s2 = sigma**2
    phi = np.exp(-(x*x + y*y)/(2*s2)); px = -x/s2*phi; py = -y/s2*phi
    pxx = (x*x/s2**2 - 1/s2)*phi; pyy = (y*y/s2**2 - 1/s2)*phi
    pxy = x*y/s2**2*phi
    return phi, px, py, pxx, pyy, pxy, pxx + pyy


def spacing(points):
    d=np.linalg.norm(points[:,None]-points[None,:],axis=2); d[d==0]=np.inf
    return float(np.median(np.min(d,axis=1)))


def inside(shape, points):
    if shape=="square": return (np.abs(points[:,0])<=1+1e-12)&(np.abs(points[:,1])<=1+1e-12)
    r=np.hypot(points[:,0],points[:,1]); th=np.arctan2(points[:,1],points[:,0]); return r<=1+0.3*np.sin(5*th)+1e-12


def evaluation_points(shape, n):
    x=np.linspace(-1,1,n); X,Y=np.meshgrid(x,x,indexing="xy"); pts=np.column_stack([X.ravel(),Y.ravel()]); return X,Y,pts[inside(shape,pts)]


def dense_boundary(shape, n=240):
    if shape=="star":
        th=np.linspace(0,2*np.pi,n,endpoint=False); r=1+0.3*np.sin(5*th); return np.column_stack([r*np.cos(th),r*np.sin(th)])
    m=max(n//4,2); t=np.linspace(-1,1,m,endpoint=False)
    return np.vstack([np.column_stack([t,-np.ones_like(t)]),np.column_stack([np.ones_like(t),t]),
                      np.column_stack([-t,np.ones_like(t)]),np.column_stack([-np.ones_like(t),-t])])


def interpolation_metrics(pred_pts,pred,ref_pts,ref,eval_pts):
    p=griddata(pred_pts,pred,eval_pts,method="linear"); r=griddata(ref_pts,ref,eval_pts,method="linear")
    keep=np.isfinite(p)&np.isfinite(r); p,r=p[keep],r[keep]; e=p-r
    return {"relative_l2":float(np.linalg.norm(e)/max(np.linalg.norm(r),1e-30)),
            "mse":float(np.mean(e**2)),"linf":float(np.max(np.abs(e)))},p,r,keep


def direct_metrics(pred, ref):
    pred, ref = np.asarray(pred, dtype=float), np.asarray(ref, dtype=float)
    keep = np.isfinite(pred) & np.isfinite(ref)
    p, r = pred[keep], ref[keep]
    e = p - r
    return {"relative_l2": float(np.linalg.norm(e) / max(np.linalg.norm(r), 1e-30)),
            "mse": float(np.mean(e ** 2)), "linf": float(np.max(np.abs(e)))}, pred, ref, keep


def solve_pipc(shape, quick, fem, eval_pts):
    if shape == "square":
        pts, is_bnd = PHS.square_cloud(11 if quick else 21)
        pcfg = {"stencil": 19 if quick else 31, "poly_degree": 2 if quick else 4,
                "phs_order": 3}
    else:
        pts, is_bnd = PHS.star_cloud(80 if quick else 200, 0.14 if quick else 0.06)
        pcfg = {"stencil": 19 if quick else 31, "poly_degree": 2 if quick else 4,
                "phs_order": 3}
    return PHS.solve_vk_pipc(shape, pcfg, fem, eval_pts, quick, pts=pts, is_bnd=is_bnd)


def assemble_cl_matrix(o,b,gamma,prev,D,E,h,q):
    Pm,L,XX,YY,XY=o; Pb=b; ni,n=Pm.shape; nb=Pb.shape[0]
    pw,pp=prev[0:n],prev[2*n:3*n]
    wxx,wyy,wxy=XX@pw,YY@pw,XY@pw; pxx,pyy,pxy=XX@pp,YY@pp,XY@pp
    A=np.zeros((4*ni+4*nb,4*n)); rhs=np.zeros(4*ni+4*nb)
    A[0:ni,0:n]=D*L;A[0:ni,n:2*n]=Pm
    A[ni:2*ni,0:n]=gamma*h*(pyy[:,None]*XX+pxx[:,None]*YY-2*pxy[:,None]*XY);A[ni:2*ni,n:2*n]=L;rhs[ni:2*ni]=-q
    A[2*ni:3*ni,2*n:3*n]=L;A[2*ni:3*ni,3*n:4*n]=Pm
    A[3*ni:4*ni,0:n]=gamma*(wxy[:,None]*XY-0.5*wxx[:,None]*YY-0.5*wyy[:,None]*XX);A[3*ni:4*ni,3*n:4*n]=(1/E)*L
    for k in range(4): A[4*ni+k*nb:4*ni+(k+1)*nb,k*n:(k+1)*n]=Pb
    norms=np.linalg.norm(A,axis=1); norms[norms==0]=1; A=A/norms[:,None]; rhs=rhs/norms
    return A,rhs


def solve_cl(shape,quick,solver,fem,eval_pts):
    started=time.perf_counter(); centers=solver.pts; interior=centers[solver.idx_int]; bcenters=centers[solver.idx_bnd]; h0=spacing(centers)
    choices=[]
    for factor in (0.75,1.0,1.5,2.0):
        sigma=factor*h0; Pi,_,_,XX,YY,XY,L=gaussian_ops(interior,centers,sigma);Pb,*_=gaussian_ops(bcenters,centers,sigma)
        zero=np.zeros(4*len(centers));A,rhs=assemble_cl_matrix((Pi,L,XX,YY,XY),Pb,0,zero,solver.D,solver.cfg["E"],solver.cfg["h"],solver.cfg["q0"])
        coeff,*_=np.linalg.lstsq(A,rhs,rcond=1e-12);res=float(np.sqrt(np.mean((A@coeff-rhs)**2)));choices.append((res,sigma,factor,coeff,(Pi,L,XX,YY,XY),Pb))
    chosen=min(choices,key=lambda z:z[0]);_,sigma,factor,coeff,o,Pb=chosen;history=[];solves=1
    solve_started=time.perf_counter()
    for gamma in (0.25,0.5,0.75,1.0):
        for iteration in range(1,21):
            A,rhs=assemble_cl_matrix(o,Pb,gamma,coeff,solver.D,solver.cfg["E"],solver.cfg["h"],solver.cfg["q0"]);new,*_=np.linalg.lstsq(A,rhs,rcond=1e-12);solves+=1
            change=float(np.linalg.norm(new-coeff)/max(np.linalg.norm(new),1e-30));coeff=new
            if change<1e-8:break
        history.append({"gamma":gamma,"iterations":iteration,"relative_coefficient_change":change})
    solve_time=time.perf_counter()-solve_started;n=len(centers);_,_,_,XXe,YYe,XYe,Le=gaussian_ops(eval_pts,centers,sigma);Pe,*_=gaussian_ops(eval_pts,centers,sigma)
    w=Pe@coeff[:n]
    if "eval_w" in fem:
        metrics,field,ref,keep=direct_metrics(w, fem["eval_w"])
    else:
        metrics,field,ref,keep=interpolation_metrics(eval_pts,w,fem["pts"],fem["w"],eval_pts)
    wi,pi=o[0]@coeff[:n],o[0]@coeff[2*n:3*n];wxx,wyy,wxy=o[2]@coeff[:n],o[3]@coeff[:n],o[4]@coeff[:n];pxx,pyy,pxy=o[2]@coeff[2*n:3*n],o[3]@coeff[2*n:3*n],o[4]@coeff[2*n:3*n]
    r0=solver.D*(o[1]@coeff[:n])+o[0]@coeff[n:2*n];r1=o[1]@coeff[n:2*n]+solver.cfg["q0"]+solver.cfg["h"]*(pyy*wxx+pxx*wyy-2*pxy*wxy);r2=o[1]@coeff[2*n:3*n]+o[0]@coeff[3*n:];r3=(1/solver.cfg["E"])*(o[1]@coeff[3*n:])+wxy*wxy-wxx*wyy
    bpts=dense_boundary(shape,100 if quick else 400);Pbd,*_=gaussian_ops(bpts,centers,sigma);dense=float(np.max(np.abs(Pbd@coeff[:n])))
    rec=MethodRecord("CL-PIELM","von_karman_plate",shape,None,"completed",**metrics,audit_residual_rms=float(np.sqrt(np.mean(np.concatenate([r0,r1,r2,r3])**2))),constraint_bc_linf=None,dense_boundary_linf=dense,
                     end_to_end_time_s=time.perf_counter()-started,stage_times_s={"curriculum_picard":solve_time},counts={"linear_solves":solves,"stages":5,"rank":None},history=history,
                     details={"basis":"Gaussian fixed features","sigma":sigma,"sigma_over_h":factor,"linear_width_candidates":[{"sigma_over_h":x[2],"linear_rms":x[0]} for x in choices],"adaptation":"four-field Picard curriculum"})
    return rec,field


class PlatePINN4(torch.nn.Module):
    def __init__(self,wscale,D,E):
        super().__init__();self.sw=wscale;self.sm=D*wscale;self.sp=E*wscale*wscale
        self.net=torch.nn.Sequential(torch.nn.Linear(2,128),torch.nn.Tanh(),torch.nn.Linear(128,128),torch.nn.Tanh(),torch.nn.Linear(128,4))
        for m in self.modules():
            if isinstance(m,torch.nn.Linear):torch.nn.init.xavier_normal_(m.weight);torch.nn.init.zeros_(m.bias)
    def forward(self,x):
        y=self.net(x)
        return (self.sw*y[:,:1],self.sm*y[:,1:2],self.sp*y[:,2:3],self.sp*y[:,3:])


def lap2(f,x):
    """Laplacian and Hessian components (xx, yy, xy) of a scalar field."""
    g=torch.autograd.grad(f,x,torch.ones_like(f),create_graph=True)[0]
    xx=torch.autograd.grad(g[:,:1],x,torch.ones_like(g[:,:1]),create_graph=True)[0]
    yy=torch.autograd.grad(g[:,1:],x,torch.ones_like(g[:,1:]),create_graph=True)[0]
    return xx[:,:1]+yy[:,1:],xx[:,:1],yy[:,1:],xx[:,1:]


def pinn4_residual(model,x,D,E,h,q):
    """Four-field (w, Mw, psi, Mpsi) mixed residual, matching PIPC/CL-PIELM."""
    x=x.requires_grad_(True)
    w,Mw,psi,Mpsi=model(x)
    lapw,wxx,wyy,wxy=lap2(w,x)
    lapMw,_,_,_=lap2(Mw,x)
    lappsi,psi_xx,psi_yy,psi_xy=lap2(psi,x)
    lapMpsi,_,_,_=lap2(Mpsi,x)
    r0=D*lapw+Mw
    r1=lapMw+q+h*(psi_yy*wxx+psi_xx*wyy-2*psi_xy*wxy)
    r2=lappsi+Mpsi
    r3=(1.0/E)*lapMpsi+(wxy*wxy-wxx*wyy)
    return r0,r1,r2,r3,w,Mw,psi,Mpsi


def solve_pinn(shape,seed,quick,solver,fem,eval_pts):
    np.random.seed(seed);torch.manual_seed(seed);torch.cuda.manual_seed_all(seed);device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # Reference-free characteristic scales: w ~ q L^4 / D, Mw ~ D w,
    # psi ~ E w^2 and Mpsi ~ E w^2.  FEM is used only for auditing.
    wscale=max(solver.cfg["q0"]/solver.D,1e-6);mscale=max(solver.D*wscale,1e-12);pscale=max(solver.cfg["E"]*wscale*wscale,1e-12)
    model=PlatePINN4(wscale,solver.D,solver.cfg["E"]).to(device=device,dtype=torch.float64);xi=torch.as_tensor(solver.pts[solver.idx_int],dtype=torch.float64,device=device);xb=torch.as_tensor(dense_boundary(shape,80 if quick else 400),dtype=torch.float64,device=device)
    adam_steps,lb_steps=((80,15) if quick else (6000,2000));history=[]
    def parts():
        r0,r1,r2,r3,_,_,_,_=pinn4_residual(model,xi.clone(),solver.D,solver.cfg["E"],solver.cfg["h"],solver.cfg["q0"])
        _,_,_,_,w,Mw,psi,Mpsi=pinn4_residual(model,xb.clone(),solver.D,solver.cfg["E"],solver.cfg["h"],solver.cfg["q0"])
        pde=torch.mean((r0/solver.cfg["q0"])**2)+torch.mean((r1/solver.cfg["q0"])**2)+torch.mean((r2/pscale)**2)+torch.mean((r3/wscale**2)**2)
        bc=torch.mean((w/wscale)**2)+torch.mean((Mw/mscale)**2)+torch.mean((psi/pscale)**2)+torch.mean((Mpsi/pscale)**2)
        return pde,bc,pde+bc
    started=time.perf_counter();a0=time.perf_counter();opt=torch.optim.Adam(model.parameters(),lr=1e-3)
    for step in range(adam_steps):
        opt.zero_grad();p,b,l=parts();l.backward();opt.step()
        if step%max(adam_steps//40,1)==0 or step==adam_steps-1:history.append({"phase":"adam","step":step,"loss":float(l.detach().cpu()),"pde":float(p.detach().cpu()),"bc":float(b.detach().cpu())})
    if device.type=="cuda":torch.cuda.synchronize()
    at=time.perf_counter()-a0;calls={"n":0};l0=time.perf_counter();lb=torch.optim.LBFGS(model.parameters(),lr=1,max_iter=lb_steps,history_size=50,line_search_fn="strong_wolfe",tolerance_grad=1e-12,tolerance_change=1e-12)
    def closure():lb.zero_grad();p,b,l=parts();l.backward();calls["n"]+=1;return l
    lb.step(closure)
    if device.type=="cuda":torch.cuda.synchronize()
    lt=time.perf_counter()-l0;xe=torch.as_tensor(eval_pts,dtype=torch.float64,device=device);w=model(xe)[0].detach().cpu().numpy()[:,0]
    if "eval_w" in fem:
        metrics,field,ref,keep=direct_metrics(w, fem["eval_w"])
    else:
        metrics,field,ref,keep=interpolation_metrics(eval_pts,w,fem["pts"],fem["w"],eval_pts)
    r0,r1,r2,r3,_,_,_,_=pinn4_residual(model,xe.clone(),solver.D,solver.cfg["E"],solver.cfg["h"],solver.cfg["q0"]);wb=model(xb)[0]
    rec=MethodRecord("PINN","von_karman_plate",shape,seed,"budget_completed",**metrics,audit_residual_rms=float(torch.sqrt(torch.mean(torch.cat([r0,r1,r2,r3])**2)).detach().cpu()),constraint_bc_linf=None,dense_boundary_linf=float(torch.max(torch.abs(wb)).detach().cpu()),end_to_end_time_s=time.perf_counter()-started,stage_times_s={"adam":at,"lbfgs":lt},counts={"adam_steps":adam_steps,"lbfgs_closures":calls["n"]},history=history,details={"network":"2x128 tanh","form":"four-field second-order mixed","boundary":"soft normalized MSE","device":str(device)})
    return rec,field


def run(output,quick,skip_pinn):
    records=[];arrays={}
    for shape in ("square","star"):
        fem=FEM.vk_fem(shape,2 if quick and shape=="square" else 1 if quick else 4 if shape=="square" else 3,max_iter=40,tol=1e-11);_,_,eval_pts=evaluation_points(shape,41 if quick else 81)
        # The legacy FEM routine uses the opposite transverse-load sign convention.
        # Align the reported physical deflection before computing cross-method errors.
        fem = dict(fem)
        fem["w"] = -np.asarray(fem["w"])
        fem["eval_w"] = FEM.R.fem_field(
            fem["pts"], fem["cells"], fem["w"], eval_pts,
            fem["corner_pts"], fill_value=np.nan)
        pipc,solver,alpha,pfield,ref,keep=solve_pipc(shape,quick,fem,eval_pts);cl,cfield=solve_cl(shape,quick,solver,fem,eval_pts);records.extend([pipc,cl]);arrays[f"{shape}_eval_points"]=eval_pts;arrays[f"{shape}_fem"]=ref;arrays[f"{shape}_pipc"]=pfield;arrays[f"{shape}_cl_pielm"]=cfield;arrays[f"{shape}_keep"]=keep
        if not skip_pinn:
            stochastic=[]
            for seed in SEEDS:
                rec,field=solve_pinn(shape,seed,quick,solver,fem,eval_pts);records.append(rec);stochastic.append(rec);arrays[f"{shape}_pinn_seed_{seed}"]=field
            arrays[f"{shape}_pinn_summary_json"]=np.array(json.dumps(summarize_stochastic(stochastic)))
    write_results(output/"plate_results.json",{"quick":quick,"seeds":list(SEEDS),"fem":"independent P2 mixed FEM"},records);np.savez_compressed(output/"plate_fields.npz",**arrays);return records


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--output",type=Path,default=DEFAULT_OUTPUT);p.add_argument("--quick",action="store_true");p.add_argument("--skip-pinn",action="store_true");a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);r=run(a.output,a.quick,a.skip_pinn);print(json.dumps([{"method":x.method,"domain":x.domain,"seed":x.seed,"rel_l2":x.relative_l2,"time":x.end_to_end_time_s} for x in r],indent=2))


if __name__=="__main__":main()
