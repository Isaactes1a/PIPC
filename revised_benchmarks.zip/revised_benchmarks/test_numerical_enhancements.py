"""Regression tests for the reference, initialization, and convergence enhancements."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
LEGACY = HERE.parent / "ablation_pielm"
sys.path[:0] = [str(HERE), str(LEGACY)]

import phs_rbf_fd as PHS
import plate_rm as RM


class NumericalEnhancementTests(unittest.TestCase):
    def test_star_p2_boundary_includes_midpoints(self):
        corner, triangles = RM.fem_mesh("star", 1)
        _, p2_cells = RM.make_p2_mesh(corner, triangles)
        boundary = RM.p2_topological_boundary_nodes(triangles, p2_cells)
        self.assertEqual(len(boundary), 240)
        self.assertGreater(len(boundary), 120)

    def test_elementwise_p2_evaluation_reproduces_quadratic(self):
        corner, triangles = RM.fem_mesh("square", 2)
        p2_points, p2_cells = RM.make_p2_mesh(corner, triangles)
        polynomial = lambda p: 1 + 2*p[:, 0] - 3*p[:, 1] + 4*p[:, 0]**2 \
            + 2*p[:, 0]*p[:, 1] - p[:, 1]**2
        values = polynomial(p2_points)
        query = np.array([[-0.73, -0.41], [-0.1, 0.2], [0.62, -0.33], [0.4, 0.77]])
        predicted = RM.fem_field(p2_points, p2_cells, values, query, corner,
                                 fill_value=np.nan)
        np.testing.assert_allclose(predicted, polynomial(query), rtol=0, atol=2e-13)

    def test_phs_interpolation_reproduces_quadratic(self):
        points, _ = PHS.square_cloud(9)
        query = np.array([[-0.73, -0.41], [-0.1, 0.2], [0.62, -0.33], [0.4, 0.77]])
        values = 1 + points[:, 0] - 2*points[:, 1] + points[:, 0]*points[:, 1]
        expected = 1 + query[:, 0] - 2*query[:, 1] + query[:, 0]*query[:, 1]
        predicted = PHS.interpolate_points(points, values, query, 19, 2, 3)
        np.testing.assert_allclose(predicted, expected, rtol=0, atol=5e-12)

    def test_explicit_row_scales_are_accepted(self):
        points, boundary = PHS.square_cloud(7)
        solver = PHS.VKRBFDSolver(
            "square", {"stencil": 19, "poly_degree": 2}, quick=True,
            pts=points, is_bnd=boundary)
        n = solver.N_int
        linear = solver.linear_prior()
        prior = np.r_[linear[:n], linear[n:], np.zeros(2*n)]
        scales = solver.residual_row_scales(prior)
        self.assertTrue(np.all(np.isfinite(scales)))
        self.assertTrue(np.all(scales > 0))
        result, _ = solver.solve_trf(prior, max_nfev=2, xtol=1e-8,
                                     row_scales=scales, tr_solver="exact")
        self.assertLessEqual(result.nfev, 2)


if __name__ == "__main__":
    unittest.main()
