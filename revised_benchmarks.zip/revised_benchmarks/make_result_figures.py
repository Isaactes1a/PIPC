"""Generate manuscript figures exclusively from persisted JSON/NPZ results."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
import numpy as np

from plot_style import (
    ERROR_CMAP,
    RESULT_CMAP,
    absolute_error,
    add_three_tick_colorbar,
    configure_publication_style,
    inward_ticks,
    shared_limits,
)

configure_publication_style()

DOMAINS = ("square", "equilateral_triangle", "snowflake")


def load_pair(folder: Path, stem: str):
    return json.loads((folder / f"{stem}_results.json").read_text(encoding="utf-8")), np.load(folder / f"{stem}_fields.npz")


def median_seed(payload, problem, domain):
    rr = [r for r in payload["records"] if r["problem"] == problem and r["domain"] == domain and r["method"] == "PINN"]
    vals = np.array([r["relative_l2"] for r in rr]); med = np.median(vals)
    return int(rr[int(np.argmin(abs(vals-med)))]["seed"])


def save(fig, out, name):
    for ax in fig.axes:
        inward_ticks(ax)
    fig.savefig(out / f"{name}.pdf", bbox_inches="tight")
    fig.savefig(out / f"{name}.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


def domain_triangle_mask(tri, shape):
    """Mask Delaunay triangles whose centroid lies outside the domain polygon.

    The star is non-convex: the raw Delaunay triangulation of its interior
    points connects vertices across the concave notches, and tricontourf would
    fill those exterior valleys. The square needs no masking.
    """
    cx = tri.x[tri.triangles].mean(axis=1)
    cy = tri.y[tri.triangles].mean(axis=1)
    if shape == "star":
        r = np.hypot(cx, cy)
        th = np.arctan2(cy, cx)
        inside = r <= 1 + 0.3 * np.sin(5 * th) + 1e-10
    else:
        inside = (np.abs(cx) <= 1 + 1e-10) & (np.abs(cy) <= 1 + 1e-10)
    return ~inside


def beam_fig(folder, out):
    p,d=load_pair(folder,"beam");x=d["x"];fig,axs=plt.subplots(1,3,figsize=(11.2,3.1),sharex=True)
    for ax,bc in zip(axs,("SS","CC","CF")):
        seed=median_seed(p,"euler_bernoulli_beam",bc)
        ax.plot(x,d[f"{bc}_reference"],"k-",lw=2,label="analytic")
        ax.plot(x,d[f"{bc}_pipc"],"--",lw=1.6,label="PIPC")
        ax.plot(x,d[f"{bc}_cl_pielm"],":",lw=2,label="PIELM")
        ax.plot(x,d[f"{bc}_pinn_seed_{seed}"],"-.",lw=1.4,label=f"PINN (seed {seed})")
        ax.set_title(bc);ax.set_xlabel("x");ax.grid(alpha=.2)
    axs[0].set_ylabel("deflection w");axs[-1].legend(fontsize=7,loc="best");fig.tight_layout();save(fig,out,"fig03_beam_fields")


def _panel_triangulation(points, triangles, shape, values):
    tri = mtri.Triangulation(points[:, 0], points[:, 1], triangles)
    mask = np.zeros(len(tri.triangles), dtype=bool)
    if shape is not None:
        mask |= domain_triangle_mask(tri, shape)
    zt = np.asarray(values)[tri.triangles]
    mask |= (~np.isfinite(zt)).any(axis=1)
    tri.set_mask(mask)
    return tri


def field_comparison_figure(rows, figsize):
    """Draw three solutions and their absolute errors with two colorbars per row."""
    fig = plt.figure(figsize=figsize, constrained_layout=True)
    grid = fig.add_gridspec(
        len(rows), 8,
        width_ratios=(1, 1, 1, 0.055, 1, 1, 1, 0.055),
        wspace=0.035,
    )
    result_titles = ("PIPC result", "PIELM result", "PINN result")
    error_titles = ("PIPC absolute error", "PIELM absolute error", "PINN absolute error")
    for i, row in enumerate(rows):
        points = row["points"]
        triangles = row.get("triangles")
        if triangles is None:
            triangles = mtri.Triangulation(points[:, 0], points[:, 1]).triangles
        reference = row["reference"]
        values = row["values"]
        errors = [absolute_error(value, reference) for value in values]
        result_lo, result_hi = shared_limits(values)
        error_lo, error_hi = shared_limits(errors, zero_min=True)
        result_levels = np.linspace(result_lo, result_hi, 25)
        error_levels = np.linspace(error_lo, error_hi, 25)
        result_axes = [fig.add_subplot(grid[i, j]) for j in range(3)]
        result_cax = fig.add_subplot(grid[i, 3])
        error_axes = [fig.add_subplot(grid[i, j]) for j in range(4, 7)]
        error_cax = fig.add_subplot(grid[i, 7])
        result_artist = error_artist = None
        method_name = row["method_name"]
        current_result_titles = tuple(
            title.replace("PIELM", method_name) for title in result_titles
        )
        current_error_titles = tuple(
            title.replace("PIELM", method_name) for title in error_titles
        )
        for j, (ax, value, title) in enumerate(zip(result_axes, values, current_result_titles)):
            tri = _panel_triangulation(points, triangles, row.get("shape"), value)
            result_artist = ax.tricontourf(tri, value, levels=result_levels, cmap=RESULT_CMAP)
            ax.set_aspect("equal")
            ax.set_xticks([]); ax.set_yticks([])
            if i == 0:
                ax.set_title(title, fontsize=11.5)
            if j == 0:
                ax.set_ylabel(row["label"], fontsize=10.5)
        for ax, error, title in zip(error_axes, errors, current_error_titles):
            tri = _panel_triangulation(points, triangles, row.get("shape"), error)
            error_artist = ax.tricontourf(tri, error, levels=error_levels, cmap=ERROR_CMAP)
            ax.set_aspect("equal")
            ax.set_xticks([]); ax.set_yticks([])
            if i == 0:
                ax.set_title(title, fontsize=11.5)
        add_three_tick_colorbar(fig, result_artist, result_cax, result_lo, result_hi, fontsize=9.5)
        add_three_tick_colorbar(fig, error_artist, error_cax, error_lo, error_hi, fontsize=9.5)
    return fig


def heat_fig(folder,out):
    p,d=load_pair(folder,"heat");rows=[]
    for dom in DOMAINS:
        seed=median_seed(p,"nonlinear_heat",dom)
        rows.append({
            "label": dom.replace("_", " "),
            "points": d[f"{dom}_nodes"],
            "triangles": d[f"{dom}_triangles"],
            "reference": d[f"{dom}_reference"],
            "values": [d[f"{dom}_pipc"], d[f"{dom}_cl_pielm"], d[f"{dom}_pinn_seed_{seed}"]],
            "method_name": "CL-PIELM",
        })
    save(field_comparison_figure(rows, (16.0, 7.7)),out,"fig04_heat_fields")
    fig,axs=plt.subplots(1,3,figsize=(10.8,3.2))
    for ax,key,label in zip(axs,("relative_l2","audit_residual_rms","dense_boundary_linf"),(r"relative $L_2$","independent residual RMS","dense boundary trace")):
        x=np.arange(3);width=.23
        for k,m in enumerate(("PIPC","CL-PIELM","PINN")):
            means=[];errs=[]
            for dom in DOMAINS:
                rr=[r for r in p["records"] if r["domain"]==dom and r["method"]==m]
                a=np.array([r[key] for r in rr]);means.append(a.mean());errs.append(a.std())
            ax.bar(x+(k-1)*width,means,width,label=m,yerr=errs if m=="PINN" else None,capsize=2)
        ax.set_yscale("log");ax.set_xticks(x,("square","triangle","snowflake"),rotation=15);ax.set_ylabel(label);ax.grid(axis="y",alpha=.2)
    axs[0].legend(fontsize=8);fig.tight_layout();save(fig,out,"fig05_heat_metrics")


def plate_fig(folder,out,stem="plate",linear=False):
    p,d=load_pair(folder,stem);problem="linear_reissner_mindlin_plate" if linear else "von_karman_plate";method_key="pielm" if linear else "cl_pielm"
    rows=[]
    for dom in ("square","star"):
        pts_all=d[f"{dom}_points" if linear else f"{dom}_eval_points"]
        seed=median_seed(p,problem,dom)
        reference=d[f"{dom}_fem"]
        values=[d[f"{dom}_pipc"],d[f"{dom}_{method_key}"],d[f"{dom}_pinn_seed_{seed}"]]
        if not all(len(value) == len(pts_all) for value in [reference, *values]):
            keep=d[f"{dom}_keep"] if f"{dom}_keep" in d.files else None
            if keep is None or not all(len(value) == int(np.sum(keep)) for value in [reference, *values]):
                raise ValueError(f"incompatible plate field sizes for {dom}")
            pts_all=pts_all[keep]
        rows.append({
            "label": dom,
            "points": pts_all,
            "reference": reference,
            "values": values,
            "method_name": "PIELM" if linear else "CL-PIELM",
            "shape": dom,
        })
    save(field_comparison_figure(rows, (16.0, 5.35)),out,
         "fig06_plate_linear_fields" if linear else "fig07_plate_nonlinear_fields")


def convergence_fig(folders,out):
    fig,axs=plt.subplots(1,3,figsize=(10.8,3.2));spec=[("beam",folders[0],"euler_bernoulli_beam","SS"),("heat",folders[1],"nonlinear_heat","square"),("plate",folders[2],"von_karman_plate","square")]
    for ax,(stem,folder,problem,domain) in zip(axs,spec):
        p,_=load_pair(folder,stem);seed=median_seed(p,problem,domain);r=next(x for x in p["records"] if x["method"]=="PINN" and x["domain"]==domain and x["seed"]==seed)
        hist=[x for x in r["history"] if "loss" in x];ax.semilogy(np.arange(len(hist)),[x["loss"] for x in hist],lw=1.6);ax.set_title(f"{stem}: {domain} (seed {seed})");ax.set_xlabel("saved checkpoint");ax.grid(alpha=.2)
    axs[0].set_ylabel("normalized training objective");fig.tight_layout();save(fig,out,"figA1_pinn_convergence")


def accuracy_cost_fig(linear_folder, vk_folder, out):
    """Accuracy-cost map (Figure 8): end-to-end wall time vs relative L2 error.

    Uses only persisted JSON records; no new computations.
    """
    p_lin, _ = load_pair(linear_folder, "plate_linear")
    p_vk, _ = load_pair(vk_folder, "plate")
    styles = {"PIPC": ("o", "tab:blue"), "PIELM": ("s", "tab:orange"),
              "CL-PIELM": ("s", "tab:orange"), "PINN": ("^", "tab:green")}
    fig, axs = plt.subplots(1, 2, figsize=(10.8, 4.0))
    panels = ((p_lin, "linear_reissner_mindlin_plate", "Linear Reissner--Mindlin plates"),
              (p_vk, "von_karman_plate", "Nonlinear von K\u00e1rm\u00e1n plates"))
    for ax, (payload, problem, title) in zip(axs, panels):
        for method, (marker, color) in styles.items():
            rr = [r for r in payload["records"] if r["problem"] == problem and r["method"] == method]
            if not rr:
                continue
            for dom in ("square", "star"):
                g = [r for r in rr if r["domain"] == dom]
                if not g:
                    continue
                tm = float(np.mean([r["end_to_end_time_s"] for r in g]))
                em = float(np.mean([r["relative_l2"] for r in g]))
                es = float(np.std([r["relative_l2"] for r in g]))
                ax.semilogy(tm, em, marker, color=color, ms=7, mec="k", mew=0.5,
                            label=method if dom == "square" else None)
                if len(g) > 1:
                    ax.errorbar(tm, em, yerr=es, fmt="none", color=color, capsize=2)
                ax.annotate(dom, (tm, em), textcoords="offset points",
                            xytext=(7, 5), fontsize=7, color=color)
        ax.set_xscale("log"); ax.set_yscale("log")
        ax.set_xlabel("wall time (s)"); ax.set_ylabel(r"relative $L_2$ error")
        ax.set_title(title); ax.grid(alpha=.2, which="both")
        ax.legend(fontsize=8, loc="lower left")
    fig.tight_layout(); save(fig, out, "fig08_accuracy_cost")


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--beam",type=Path,required=True);p.add_argument("--heat",type=Path,required=True);p.add_argument("--plate",type=Path,required=True);p.add_argument("--linear-plate",type=Path,required=True);p.add_argument("--output",type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    beam_fig(a.beam,a.output);heat_fig(a.heat,a.output);plate_fig(a.linear_plate,a.output,"plate_linear",True);plate_fig(a.plate,a.output);convergence_fig((a.beam,a.heat,a.plate),a.output);accuracy_cost_fig(a.linear_plate,a.plate,a.output)


if __name__=="__main__":main()
