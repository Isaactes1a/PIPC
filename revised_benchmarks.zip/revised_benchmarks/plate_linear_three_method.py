"""Linear Reissner--Mindlin plate: PIPC, PIELM, PINN, and FEM."""

from __future__ import annotations

import argparse
import importlib.util
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
from scipy.linalg import null_space

from common import MethodRecord, SEEDS, summarize_stochastic, write_results
import phs_rbf_fd as PHS

HERE = Path(__file__).resolve().parent
LEGACY = HERE.parent / "ablation_pielm"
if str(LEGACY) not in sys.path:
    sys.path.insert(0, str(LEGACY))


def _load(name, filename):
    spec = importlib.util.spec_from_file_location(name, LEGACY / filename)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


R = _load("audited_plate_rm", "plate_rm.py")
torch.set_default_dtype(torch.float64)


def dense_boundary(shape, n):
    if shape == "star":
        th = np.linspace(0, 2 * np.pi, n, endpoint=False)
        rr = 1 + 0.3 * np.sin(5 * th)
        return np.column_stack([rr * np.cos(th), rr * np.sin(th)])
    m = max(n // 4, 2)
    t = np.linspace(-1, 1, m, endpoint=False)
    return np.vstack((np.c_[t, -np.ones(m)], np.c_[np.ones(m), t],
                      np.c_[-t, np.ones(m)], np.c_[-np.ones(m), -t]))


def eval_points(shape, n):
    x = np.linspace(-1, 1, n)
    X, Y = np.meshgrid(x, x, indexing="xy")
    pts = np.c_[X.ravel(), Y.ravel()]
    mask = np.ones(len(pts), bool) if shape == "square" else R.inside_star(pts)
    return pts[mask]


def metrics(pred, ref):
    keep = np.isfinite(pred) & np.isfinite(ref)
    pred, ref = np.asarray(pred)[keep], np.asarray(ref)[keep]
    e = pred - ref
    return dict(relative_l2=float(np.linalg.norm(e) / max(np.linalg.norm(ref), 1e-30)),
                mse=float(np.mean(e * e)), linf=float(np.max(np.abs(e))))


def gaussian_ops(points, centers, sigma):
    d = points[:, None, :] - centers[None, :, :]
    x, y = d[..., 0], d[..., 1]
    s2 = sigma * sigma
    p = np.exp(-(x * x + y * y) / (2 * s2))
    px, py = -x / s2 * p, -y / s2 * p
    pxx = (x * x / s2**2 - 1 / s2) * p
    pyy = (y * y / s2**2 - 1 / s2) * p
    pxy = x * y / s2**2 * p
    return p, px, py, pxx, pyy, pxy


def spacing(points):
    d = np.linalg.norm(points[:, None] - points[None, :], axis=2)
    d[d == 0] = np.inf
    return float(np.median(np.min(d, axis=1)))


def normalized_lstsq(A, rhs):
    scale = np.linalg.norm(A, axis=1)
    scale[scale == 0] = 1
    As, bs = A / scale[:, None], rhs / scale
    if As.shape[0] * As.shape[1] > 24_000_000:
        # Large dense Gaussian systems (e.g. the 8-field star cloud) are solved
        # with the same iterative least-squares path used by PIPC.
        from scipy.sparse.linalg import lsqr
        x = lsqr(As, bs, atol=1e-12, btol=1e-12, iter_lim=2000)[0]
        rms = float(np.sqrt(np.mean((As @ x - bs) ** 2)))
        return x, None, float("inf"), rms
    s = np.linalg.svd(As, compute_uv=False)
    cond = float(s[0] / s[-1]) if s[-1] > 0 else float("inf")
    x, _, rank, _ = np.linalg.lstsq(As, bs, rcond=1e-12)
    return x, int(rank), cond, float(np.sqrt(np.mean((As @ x - bs) ** 2)))


def assemble_pielm(solver, sigma):
    pts, ii, bi = solver.pts, solver.idx_int, solver.idx_bnd
    Pi, Px, Py, Pxx, Pyy, Pxy = gaussian_ops(pts[ii], pts, sigma)
    Pb, Bx, By, _, _, _ = gaussian_ops(pts[bi], pts, sigma)
    n, ni, nb = len(pts), len(ii), len(bi)
    A = np.zeros((3 * ni + 3 * nb, 3 * n)); rhs = np.zeros(len(A))
    D, Cs, nu = solver.D, solver.Cs, solver.nu
    A[:ni, :n] = -Cs * Px
    A[:ni, n:2*n] = D * (Pxx + 0.5 * (1-nu) * Pyy) - Cs * Pi
    A[:ni, 2*n:] = 0.5 * D * (1+nu) * Pxy
    A[ni:2*ni, :n] = -Cs * Py
    A[ni:2*ni, n:2*n] = 0.5 * D * (1+nu) * Pxy
    A[ni:2*ni, 2*n:] = D * (Pyy + 0.5 * (1-nu) * Pxx) - Cs * Pi
    A[2*ni:3*ni, :n] = Cs * (Pxx + Pyy)
    A[2*ni:3*ni, n:2*n] = Cs * Px
    A[2*ni:3*ni, 2*n:] = Cs * Py
    rhs[2*ni:3*ni] = -solver.cfg["q0"]
    row = 3 * ni
    A[row:row+nb, :n] = Pb
    normals = R.boundary_normals(solver.shape, pts[bi]); nx, ny = normals[:, :1], normals[:, 1:]
    A[row+nb:row+2*nb, n:2*n] = D * (nx**2 * Bx + nu*ny**2 * Bx + (1-nu)*nx*ny*By)
    A[row+nb:row+2*nb, 2*n:] = D * (nu*nx**2 * By + ny**2 * By + (1-nu)*nx*ny*Bx)
    A[row+2*nb:, n:2*n] = D*(1-nu)*(-nx*ny*Bx + 0.5*(nx**2-ny**2)*By)
    A[row+2*nb:, 2*n:] = D*(1-nu)*(nx*ny*By + 0.5*(nx**2-ny**2)*Bx)
    return A, rhs


def assemble_pielm8(solver, sigma):
    """First-order 8-field mixed form with Gaussian features.

    Unknowns per node: w, beta_x, beta_y, Mxx, Myy, Mxy, Qx, Qy. Only first
    derivatives of the Gaussian features enter, matching the PIPC formulation
    of Eq. (8) so the baseline is compared on the same governing equations.
    """
    pts, ii, bi = solver.pts, solver.idx_int, solver.idx_bnd
    G, Gx, Gy, _, _, _ = gaussian_ops(pts, pts, sigma)
    Gb, Bx, By, _, _, _ = gaussian_ops(pts[bi], pts, sigma)
    N, nb, n = len(pts), len(bi), len(pts)
    D, Cs, nu = solver.D, solver.Cs, solver.nu
    A = np.zeros((8 * N + 3 * nb, 8 * n)); rhs = np.zeros(8 * N + 3 * nb)
    w, bx, by = 0, n, 2 * n
    mxx, myy, mxy = 3 * n, 4 * n, 5 * n
    qx, qy = 6 * n, 7 * n
    # constitutive moment relations at all nodes
    A[0:N, mxx:mxx + n] = G
    A[0:N, bx:bx + n] = -D * Gx
    A[0:N, by:by + n] = -D * nu * Gy
    A[N:2 * N, myy:myy + n] = G
    A[N:2 * N, bx:bx + n] = -D * nu * Gx
    A[N:2 * N, by:by + n] = -D * Gy
    A[2 * N:3 * N, mxy:mxy + n] = G
    A[2 * N:3 * N, bx:bx + n] = -D * (1 - nu) / 2 * Gy
    A[2 * N:3 * N, by:by + n] = -D * (1 - nu) / 2 * Gx
    # constitutive shear relations at all nodes
    A[3 * N:4 * N, qx:qx + n] = G
    A[3 * N:4 * N, bx:bx + n] = -Cs * G
    A[3 * N:4 * N, w:w + n] = -Cs * Gx
    A[4 * N:5 * N, qy:qy + n] = G
    A[4 * N:5 * N, by:by + n] = -Cs * G
    A[4 * N:5 * N, w:w + n] = -Cs * Gy
    # equilibrium at all nodes
    A[5 * N:6 * N, mxx:mxx + n] = Gx
    A[5 * N:6 * N, mxy:mxy + n] = Gy
    A[5 * N:6 * N, qx:qx + n] = -G
    A[6 * N:7 * N, mxy:mxy + n] = Gx
    A[6 * N:7 * N, myy:myy + n] = Gy
    A[6 * N:7 * N, qy:qy + n] = -G
    A[7 * N:8 * N, qx:qx + n] = Gx
    A[7 * N:8 * N, qy:qy + n] = Gy
    rhs[7 * N:8 * N] = -solver.cfg["q0"]
    # boundary value rows: w = 0, Mnn = 0, Mns = 0
    r0 = 8 * N
    normals = R.boundary_normals(solver.shape, pts[bi]); nx, ny = normals[:, :1], normals[:, 1:]
    A[r0:r0 + nb, w:w + n] = Gb
    A[r0 + nb:r0 + 2 * nb, mxx:mxx + n] = nx ** 2 * Gb
    A[r0 + nb:r0 + 2 * nb, mxy:mxy + n] = 2 * nx * ny * Gb
    A[r0 + nb:r0 + 2 * nb, myy:myy + n] = ny ** 2 * Gb
    A[r0 + 2 * nb:r0 + 3 * nb, mxx:mxx + n] = -nx * ny * Gb
    A[r0 + 2 * nb:r0 + 3 * nb, mxy:mxy + n] = 0.5 * (ny ** 2 - nx ** 2) * Gb
    A[r0 + 2 * nb:r0 + 3 * nb, myy:myy + n] = nx * ny * Gb
    return A, rhs


def solve_pipc(shape, quick, eval_xy, fem_w):
    if shape == "square":
        pts, is_bnd = PHS.square_cloud(11 if quick else 21)
        pcfg = {"stencil": 19 if quick else 31, "poly_degree": 2 if quick else 3,
                "phs_order": 3, "second_operators": False}
    else:
        pts, is_bnd = PHS.star_cloud(80 if quick else 200, 0.14 if quick else 0.045)
        pcfg = {"stencil": 19 if quick else 31, "poly_degree": 2, "phs_order": 3,
                "second_operators": False}
    solver = PHS.RBFDPlateSolver(shape, pcfg, quick=quick, pts=pts, is_bnd=is_bnd)
    rec, _, pred = PHS.solve_linear_rm_pipc(
        solver, eval_xy, fem_w, quick,
        dense_boundary(shape, 100 if quick else 400))
    return rec, pred, solver


def solve_pielm(solver, eval_xy, fem_w, quick):
    started = time.perf_counter(); h0 = spacing(solver.pts); choices = []
    for factor in (0.75, 1.0, 1.5, 2.0):
        sigma = factor * h0; A, rhs = assemble_pielm8(solver, sigma)
        c, rank, cond, rms = normalized_lstsq(A, rhs)
        choices.append((cond > 1e12, rms, cond, sigma, factor, c, rank))
    _, _, cond, sigma, factor, coeff, rank = min(choices, key=lambda z: (z[0], z[1]))
    P, *_ = gaussian_ops(eval_xy, solver.pts, sigma); n = len(solver.pts); pred = P @ coeff[:n]
    A, rhs = assemble_pielm8(solver, sigma); residual = A @ coeff - rhs
    bd = dense_boundary(solver.shape, 100 if quick else 400); Pb, *_ = gaussian_ops(bd, solver.pts, sigma)
    rec = MethodRecord("PIELM", "linear_reissner_mindlin_plate", solver.shape, None, "completed",
        **metrics(pred, fem_w), audit_residual_rms=float(np.sqrt(np.mean(residual**2))),
        constraint_bc_linf=None, dense_boundary_linf=float(np.max(np.abs(Pb @ coeff[:n]))),
        end_to_end_time_s=time.perf_counter()-started, stage_times_s={"svd_lstsq": time.perf_counter()-started},
        counts={"linear_solves": 1, "rank": rank}, history=[],
        details={"basis": "Gaussian fixed features", "form": "first-order 8-field mixed",
                 "sigma_over_h": factor, "condition_number": cond, "rcond": 1e-12,
                 "width_candidates": [{"sigma_over_h":x[4],"residual":x[1],"condition":x[2]} for x in choices]})
    return rec, pred


class RMNet8(torch.nn.Module):
    def __init__(self, ws, D, Cs):
        super().__init__(); self.sw = ws; self.sm = D * ws; self.sq = Cs * ws
        self.net = torch.nn.Sequential(torch.nn.Linear(2,128),torch.nn.Tanh(),torch.nn.Linear(128,128),torch.nn.Tanh(),torch.nn.Linear(128,8))
        for m in self.modules():
            if isinstance(m, torch.nn.Linear): torch.nn.init.xavier_normal_(m.weight); torch.nn.init.zeros_(m.bias)
    def forward(self, x):
        y = self.net(x)
        return (self.sw*y[:,:1], self.sw*y[:,1:2], self.sw*y[:,2:3],
                self.sm*y[:,3:4], self.sm*y[:,4:5], self.sm*y[:,5:6],
                self.sq*y[:,6:7], self.sq*y[:,7:])


def grad(f, x):
    return torch.autograd.grad(f, x, torch.ones_like(f), create_graph=True)[0]


def rm8_residual(model, x, solver):
    x = x.requires_grad_(True)
    w, bx, by, Mxx, Myy, Mxy, Qx, Qy = model(x)
    gw, gbx, gby = grad(w,x), grad(bx,x), grad(by,x)
    gMxx, gMyy, gMxy = grad(Mxx,x), grad(Myy,x), grad(Mxy,x)
    gQx, gQy = grad(Qx,x), grad(Qy,x)
    D, Cs, nu = solver.D, solver.Cs, solver.nu
    r1 = Mxx - D*(gbx[:,:1] + nu*gby[:,1:])
    r2 = Myy - D*(nu*gbx[:,:1] + gby[:,1:])
    r3 = Mxy - D*(1-nu)/2*(gbx[:,1:] + gby[:,:1])
    r4 = Qx - Cs*(bx + gw[:,:1])
    r5 = Qy - Cs*(by + gw[:,1:])
    r6 = gMxx[:,:1] + gMxy[:,1:] - Qx
    r7 = gMxy[:,:1] + gMyy[:,1:] - Qy
    r8 = gQx[:,:1] + gQy[:,1:] + solver.cfg["q0"]
    return (r1,r2,r3,r4,r5,r6,r7,r8,w,bx,by,Mxx,Myy,Mxy,Qx,Qy)


def solve_pinn(solver, seed, eval_xy, fem_w, quick):
    np.random.seed(seed); torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # q L^4 / D is a reference-free physical deflection scale.
    ws = solver.cfg["q0"] / solver.D
    sm = max(solver.D * ws, 1e-12); sq = max(solver.Cs * ws, 1e-12)
    model = RMNet8(ws, solver.D, solver.Cs).to(device=dev,dtype=torch.float64)
    xi=torch.as_tensor(solver.pts[solver.idx_int],device=dev); bpts=dense_boundary(solver.shape,80 if quick else 400); xb=torch.as_tensor(bpts,device=dev)
    normals=torch.as_tensor(R.boundary_normals(solver.shape,bpts),device=dev)
    def loss_parts():
        r1,r2,r3,r4,r5,r6,r7,r8,_,_,_,_,_,_,_,_ = rm8_residual(model,xi.clone(),solver)
        _,_,_,_,_,_,_,_,wb,_,_,Mbxx,Myyy,Mxyy,_,_ = rm8_residual(model,xb.clone(),solver)
        nx,ny=normals[:,:1],normals[:,1:]
        mnn=nx*nx*Mbxx + 2*nx*ny*Mxyy + ny*ny*Myyy
        mns=-nx*ny*Mbxx + 0.5*(ny*ny-nx*nx)*Mxyy + nx*ny*Myyy
        p=(torch.mean((r1/sm)**2)+torch.mean((r2/sm)**2)+torch.mean((r3/sm)**2)
           +torch.mean((r4/sq)**2)+torch.mean((r5/sq)**2)
           +torch.mean((r6/sm)**2)+torch.mean((r7/sm)**2)+torch.mean((r8/solver.cfg["q0"])**2))
        b=torch.mean((wb/ws)**2)+torch.mean((mnn/sm)**2)+torch.mean((mns/sm)**2)
        return p,b,p+b
    adam_steps,lb_steps=(80,15) if quick else (6000,2000); hist=[]; started=time.perf_counter(); opt=torch.optim.Adam(model.parameters(),lr=1e-3);t0=time.perf_counter()
    for step in range(adam_steps):
        opt.zero_grad();p,b,l=loss_parts();l.backward();opt.step()
        if step%max(adam_steps//40,1)==0 or step==adam_steps-1:hist.append({"phase":"adam","step":step,"loss":float(l.detach().cpu())})
    if dev.type=="cuda":torch.cuda.synchronize()
    at=time.perf_counter()-t0; calls={"n":0};t0=time.perf_counter();opt2=torch.optim.LBFGS(model.parameters(),lr=1,max_iter=lb_steps,line_search_fn="strong_wolfe",history_size=50,tolerance_grad=1e-12,tolerance_change=1e-12)
    def closure():opt2.zero_grad();_,_,l=loss_parts();l.backward();calls["n"]+=1;return l
    opt2.step(closure)
    if dev.type=="cuda":torch.cuda.synchronize()
    lt=time.perf_counter()-t0; xe=torch.as_tensor(eval_xy,device=dev);pred=model(xe)[0].detach().cpu().numpy()[:,0]
    rs=rm8_residual(model,xe.clone(),solver); wb=model(xb)[0]
    resid=torch.cat([rs[0],rs[1],rs[2],rs[3],rs[4],rs[5],rs[6],rs[7]])
    rec=MethodRecord("PINN","linear_reissner_mindlin_plate",solver.shape,seed,"budget_completed",**metrics(pred,fem_w),
        audit_residual_rms=float(torch.sqrt(torch.mean(resid**2)).detach().cpu()),constraint_bc_linf=None,
        dense_boundary_linf=float(torch.max(torch.abs(wb)).detach().cpu()),end_to_end_time_s=time.perf_counter()-started,
        stage_times_s={"adam":at,"lbfgs":lt},counts={"adam_steps":adam_steps,"lbfgs_closures":calls["n"]},history=hist,
        details={"network":"2x128 tanh","form":"first-order 8-field mixed","boundary":"soft normalized MSE","device":str(dev),"physical_w_scale":ws})
    return rec,pred


def run(output, quick, skip_pinn):
    output.mkdir(parents=True,exist_ok=True); records=[]; arrays={}
    for shape in ("square","star"):
        epts=eval_points(shape,41 if quick else 81);level=(2 if shape=="square" else 1) if quick else (5 if shape=="square" else 4)
        cp,cells,U,p2=R.fem_solve(shape,level,h=0.05);fem=R.fem_field(p2,cells,U,epts,cp)
        pipc,wp,solver=solve_pipc(shape,quick,epts,fem);pielm,we=solve_pielm(solver,epts,fem,quick);records.extend([pipc,pielm])
        arrays.update({f"{shape}_points":epts,f"{shape}_fem":fem,f"{shape}_pipc":wp,f"{shape}_pielm":we})
        if not skip_pinn:
            group=[]
            for seed in SEEDS:
                rec,w=solve_pinn(solver,seed,epts,fem,quick);records.append(rec);group.append(rec);arrays[f"{shape}_pinn_seed_{seed}"]=w
            arrays[f"{shape}_pinn_summary_json"]=np.array(json.dumps(summarize_stochastic(group)))
    write_results(output/"plate_linear_results.json",{"quick":quick,"seeds":list(SEEDS),"fem":"independent P2 Reissner--Mindlin","h":0.05},records)
    np.savez_compressed(output/"plate_linear_fields.npz",**arrays)
    return records


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--output",type=Path,default=HERE/"results"/"plate_linear");p.add_argument("--quick",action="store_true");p.add_argument("--skip-pinn",action="store_true");a=p.parse_args()
    rec=run(a.output,a.quick,a.skip_pinn);print(json.dumps([{"method":r.method,"domain":r.domain,"seed":r.seed,"rel_l2":r.relative_l2,"time":r.end_to_end_time_s} for r in rec],indent=2))


if __name__ == "__main__": main()
