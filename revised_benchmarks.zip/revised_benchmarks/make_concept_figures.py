"""Create the two editable vector concept figures for the revised manuscript."""

from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

from plot_style import configure_publication_style


HERE = Path(__file__).resolve().parent
FIGURES = HERE.parents[1] / "PIPC_LaTeX_Package" / "figures"

configure_publication_style()


def box(ax, xy, wh, title, subtitle, color):
    x, y = xy; w, h = wh
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.035",
                                facecolor=color + "18", edgecolor=color, linewidth=1.8))
    ax.text(x + w / 2, y + h * 0.62, title, ha="center", va="center", fontsize=11,
            weight="bold", color="#17324D")
    ax.text(x + w / 2, y + h * 0.30, subtitle, ha="center", va="center", fontsize=8.6,
            color="#43576A", linespacing=1.15)


def arrow(ax, start, end, color="#4777A8"):
    ax.add_patch(FancyArrowPatch(start, end, arrowstyle="-|>", mutation_scale=13,
                                linewidth=1.8, color=color, shrinkA=2, shrinkB=2))


def workflow():
    fig, ax = plt.subplots(figsize=(13.2, 3.2))
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    titles = ["Governing PDE", "Mixed-variable\nreformulation", "Deterministic\nRBF prior",
              "Admissible\ncoefficient space", "Full nonlinear\nrefinement", "Continuous\nsolution"]
    subs = [r"$\mathcal{N}(u;\mu)=f$" + "\n" + r"$\mathcal{B}(u)=g$",
            "high-order operator\n$\\rightarrow$ low-order system",
            "preassembled algebraic\ndifferential operators",
            r"$\lambda=\lambda_p+Tz$" + "\n" + r"$CT=0$",
            r"$z^{(0)}\rightarrow z^*$" + "\nTRF + analytic Jacobian",
            r"$u^*(x)=\Phi(x)\lambda^*$"]
    colors = ["#2E6FBB", "#287D8E", "#2A9D8F", "#7A5CC7", "#D97706", "#B33A3A"]
    xs = [0.015, 0.18, 0.345, 0.51, 0.675, 0.84]
    for i, (x, title, sub, color) in enumerate(zip(xs, titles, subs, colors)):
        box(ax, (x, 0.30), (0.145, 0.42), title, sub, color)
        if i < len(xs) - 1:
            arrow(ax, (x + 0.145, 0.51), (xs[i + 1], 0.51))
    ax.text(0.5, 0.89, "Physics-Informed Prior Collocation (PIPC)", ha="center", va="center",
            fontsize=16, weight="bold", color="#17324D")
    ax.text(0.5, 0.10,
            "deterministic prior  +  discrete hard admissibility  +  algebraic differentiation  +  full nonlinear refinement",
            ha="center", va="center", fontsize=10.5, color="#315B7D")
    return fig


def route(ax, y, name, color, nodes, note):
    ax.text(0.04, y, name, ha="left", va="center", fontsize=12, weight="bold", color=color)
    xs = [0.18, 0.38, 0.60, 0.82]
    for i, (x, text) in enumerate(zip(xs, nodes)):
        ax.add_patch(FancyBboxPatch((x, y - 0.075), 0.15, 0.15,
                                    boxstyle="round,pad=0.012,rounding_size=0.025",
                                    facecolor=color + "12", edgecolor=color, linewidth=1.5))
        ax.text(x + 0.075, y, text, ha="center", va="center", fontsize=9, color="#25384A")
        if i < 3: arrow(ax, (x + 0.15, y), (xs[i + 1], y), color)
    ax.text(0.895, y - 0.108, note, ha="center", va="center", fontsize=8.0,
            color="#52677A", style="italic")


def comparison():
    fig, ax = plt.subplots(figsize=(12.8, 5.0))
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    ax.text(0.5, 0.93, "Three physics-informed PDE solution pathways", ha="center",
            fontsize=15, weight="bold", color="#17324D")
    route(ax, 0.72, "PINN", "#B33A3A",
          ["PDE + BC", "NN $u_\\theta$\n(random init.)", "automatic\ndifferentiation", "full-parameter\noptimization"],
          "learn the full solution")
    route(ax, 0.47, "CL-PIELM", "#2E6FBB",
          ["PDE + BC", "fixed RBF\nfeatures", "curriculum\nstate", "quasilinear\nalgebraic solves"],
          "progressively linearize")
    route(ax, 0.22, "PIPC", "#2A9D8F",
          ["PDE + BC", "constrained\nRBF prior", "$z^{(0)}$\nphysical state", "full nonlinear\nresidual solve"],
          "compute a prior and refine")
    return fig


def save(fig, stem):
    FIGURES.mkdir(parents=True, exist_ok=True)
    for suffix in ("svg", "pdf", "png"):
        kwargs = {"dpi": 300} if suffix == "png" else {}
        fig.savefig(FIGURES / f"{stem}.{suffix}", bbox_inches="tight", facecolor="white", **kwargs)
    plt.close(fig)


if __name__ == "__main__":
    save(workflow(), "fig01_pipc_workflow")
    save(comparison(), "fig02_three_pathways")
    print(FIGURES)
