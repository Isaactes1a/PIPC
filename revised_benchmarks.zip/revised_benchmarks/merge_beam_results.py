"""Merge the audited deterministic beam discretization with completed PINN runs."""
from __future__ import annotations
import argparse,json
from pathlib import Path
import numpy as np

def main():
    p=argparse.ArgumentParser();p.add_argument("--deterministic",type=Path,required=True);p.add_argument("--full",type=Path,required=True);p.add_argument("--output",type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    det=json.loads((a.deterministic/"beam_results.json").read_text(encoding="utf-8"));full=json.loads((a.full/"beam_results.json").read_text(encoding="utf-8"))
    records=det["records"]+[r for r in full["records"] if r["method"]=="PINN"]
    payload={"schema_version":"pipc-revised-benchmark-v1","metadata":{**full["metadata"],"deterministic_centres":31,"merge":"full PINN budgets plus audited deterministic discretization"},"records":records}
    (a.output/"beam_results.json").write_text(json.dumps(payload,indent=2),encoding="utf-8")
    dd=np.load(a.deterministic/"beam_fields.npz");ff=np.load(a.full/"beam_fields.npz");arrays={k:ff[k] for k in ff.files}
    for k in dd.files:
        if "pinn" not in k:arrays[k]=dd[k]
    np.savez_compressed(a.output/"beam_fields.npz",**arrays)
if __name__=="__main__":main()
