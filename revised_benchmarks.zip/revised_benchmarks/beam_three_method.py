"""Three-method Euler--Bernoulli beam benchmark for the revised manuscript."""

from __future__ import annotations

import argparse
import importlib.util
import json
import math
import sys
import time
from pathlib import Path

import numpy as np
import torch

from common import MethodRecord, SEEDS, summarize_stochastic, write_results


HERE = Path(__file__).resolve().parent
LEGACY = HERE.parent / "ablation_pielm" / "beam_ablation_pielm.py"
DEFAULT_OUTPUT = HERE / "results" / "beam"


def load_module():
    spec = importlib.util.spec_from_file_location("audited_beam", LEGACY)
    module = importlib.util.module_from_spec(spec); sys.modules[spec.name] = module
    assert spec.loader is not None; spec.loader.exec_module(module)
    return module


B = load_module()
# The audited 31-centre discretization keeps the global MQ system within the
# accuracy range where discrete support constraints remain below 1e-10.  The
# linear PIELM uses the same feature count.
B.N_PTS = 31
torch.set_default_dtype(torch.float64)
BCS = ("SS", "CC", "CF")


def derivatives_gaussian(x: np.ndarray, centers: np.ndarray, sigma: float):
    d = x[:, None] - centers[None, :]
    s2 = sigma**2
    phi = np.exp(-d**2 / (2 * s2))
    p1 = -(d / s2) * phi
    p2 = (d**2 / s2**2 - 1 / s2) * phi
    return phi, p1, p2


def constraint_rows(bc, phi0, phiL, p10, p1L):
    if bc == "SS":
        return [(0, 0, phi0), (0, 0, phiL), (1, 0, phi0), (1, 0, phiL)]
    if bc == "CC":
        return [(0, 0, phi0), (0, 1, p10), (0, 0, phiL), (0, 1, p1L)]
    return [(0, 0, phi0), (0, 1, p10), (1, 0, phiL), (1, 1, p1L)]


def solve_gaussian_pielm(bc: str, x_res: np.ndarray, centers: np.ndarray):
    h = float(np.median(np.diff(np.sort(centers))))
    candidates = []
    for factor in (0.75, 1.0, 1.5, 2.0):
        sigma = factor * h
        phi, p1, p2 = derivatives_gaussian(x_res, centers, sigma)
        phi0, p10, _ = derivatives_gaussian(np.array([0.0]), centers, sigma)
        phiL, p1L, _ = derivatives_gaussian(np.array([B.L]), centers, sigma)
        a1 = np.hstack([B.EI * p2, phi]); a2 = np.hstack([np.zeros_like(p2), p2])
        rows = [a1 / (abs(B.Q0) * math.sqrt(len(x_res))), a2 / (abs(B.Q0) * math.sqrt(len(x_res)))]
        rhs = [np.zeros(len(x_res)), -np.ones(len(x_res))]
        wscale = abs(B.Q0) * B.L**4 / B.EI
        mscale = abs(B.Q0) * B.L**2
        for field, order, row in constraint_rows(bc, phi0, phiL, p10, p1L):
            physical_scale = (wscale if field == 0 else mscale) / B.L**order
            assembled = np.hstack([row, np.zeros_like(row)]) if field == 0 else np.hstack([np.zeros_like(row), row])
            rows.append(assembled / physical_scale)
            rhs.append(np.zeros(1))
        a = np.vstack(rows); b = np.concatenate(rhs)
        coeff, _, rank, singular = np.linalg.lstsq(a, b, rcond=1e-12)
        cond = float(singular[0] / singular[-1]) if singular[-1] > 0 else math.inf
        rms = float(np.sqrt(np.mean((a @ coeff - b)**2)))
        candidates.append((rms, cond, sigma, factor, coeff, int(rank)))
    feasible = [item for item in candidates if item[1] <= 1e12]
    chosen = min(feasible or candidates, key=lambda item: item[0])
    return chosen, [{"linear_rms": a, "condition": b, "sigma": c, "sigma_over_h": d, "rank": f}
                    for a, b, c, d, _, f in candidates]


def bc_residuals_numpy(bc, w0, w1, w2, w3, m0, m1):
    if bc == "SS": return np.array([w0[0], w0[-1], m0[0], m0[-1]])
    if bc == "CC": return np.array([w0[0], w1[0], w0[-1], w1[-1]])
    return np.array([w0[0], w1[0], m0[-1], m1[-1]])


def method_metrics(bc, x, w, w2, m, m2):
    ref = B.exact_solution(bc, x[:, None]).ravel()
    err = w - ref
    rel = float(np.linalg.norm(err) / np.linalg.norm(ref))
    mse = float(np.mean(err**2)); linf = float(np.max(np.abs(err)))
    residual = np.concatenate([B.EI * w2 + m, m2 + B.Q0])
    return {"relative_l2": rel, "mse": mse, "linf": linf,
            "audit_residual_rms": float(np.sqrt(np.mean(residual**2)))}


def run_deterministic(bc, pts, phi, p1, p2, prior, pipc, x_eval):
    started = time.perf_counter()
    fields = B.eval_mq_mixed(pipc[bc], pts[:, None], x_eval[:, None])
    lam_w = pipc[bc]["Z_w"] @ pipc[bc]["alpha"][:pipc[bc]["Z_w"].shape[1]]
    lam_m = pipc[bc]["Z_M"] @ pipc[bc]["alpha"][pipc[bc]["Z_w"].shape[1]:]
    # Remove floating-point drift normal to the discrete admissible spaces.
    # This is an orthogonal projection of the already constrained coefficient
    # vectors, not an added penalty or a change to the governing residual.
    phi0,phiL=phi[[0,-1]];p10,p1L=p1[[0,-1]]
    for field in (0,1):
        rows=[row for f,_order,row in constraint_rows(bc,phi0,phiL,p10,p1L) if f==field]
        if rows:
            C=np.vstack(rows);lam=lam_w if field==0 else lam_m
            lam-=C.T@np.linalg.lstsq(C@C.T,C@lam,rcond=None)[0]
    phie, p1e, p2e = B.rbf_ops_cross(x_eval[:, None], pts[:, None]) if hasattr(B, "rbf_ops_cross") else (None, None, None)
    if phie is None:
        d = x_eval[:, None] - pts[None, :]
        phie = np.sqrt(d**2 + B.C**2); p1e = d / phie; p2e = B.C**2 / (d**2 + B.C**2)**1.5
    w, m = phie @ lam_w, phie @ lam_m
    w1, w2, m1, m2 = p1e @ lam_w, p2e @ lam_w, p1e @ lam_m, p2e @ lam_m
    metrics = method_metrics(bc, x_eval, w, w2, m, m2)
    bcvals = bc_residuals_numpy(bc, w, w1, w2, np.zeros_like(w), m, m1)
    info = pipc[bc]
    record = MethodRecord("PIPC", "euler_bernoulli_beam", bc, None,
                          "converged" if info["success"] else f"status_{info['status']}",
                          **metrics, constraint_bc_linf=float(np.max(np.abs(bcvals))),
                          dense_boundary_linf=float(np.max(np.abs(bcvals))),
                          end_to_end_time_s=float(prior[bc]["elapsed"] + info["elapsed"]),
                          stage_times_s={"prior": float(prior[bc]["elapsed"]), "refinement": float(info["elapsed"])},
                          counts={"nfev": info["iters"], "njev": info["njev"], "stages": 1},
                          history=[{"initial_cost": info["initial_cost"], "final_cost": info["final_cost"]}],
                          details={"basis": "MQ-RBF", "centers": B.N_PTS, "boundary": "affine null space"})
    return record, w


def run_pielm(bc, x_res, centers, x_eval):
    # For this linear benchmark CL-PIELM reduces to the published PIELM
    # backbone; no curriculum is introduced solely to relabel a linear solve.
    started = time.perf_counter()
    model = B.solve_pielm(centers[:, None], np.arange(1, len(centers) - 1))[bc]
    W, bias, coeff = model["W"], model["b"], model["theta"]
    z = np.tanh(x_eval[:, None] @ W.T + bias.T)
    p1 = W.T * (1.0 - z**2)
    p2 = -2.0 * W.T**2 * z * (1.0 - z**2)
    n = W.shape[0]
    w, m = z @ coeff[:n], z @ coeff[n:]
    w1, w2, m1, m2 = p1 @ coeff[:n], p2 @ coeff[:n], p1 @ coeff[n:], p2 @ coeff[n:]
    metrics = method_metrics(bc, x_eval, w, w2, m, m2)
    bcvals = bc_residuals_numpy(bc, w, w1, w2, np.zeros_like(w), m, m1)
    record = MethodRecord("PIELM", "euler_bernoulli_beam", bc, None, "completed",
                          **metrics, constraint_bc_linf=None,
                          dense_boundary_linf=float(np.max(np.abs(bcvals))),
                          end_to_end_time_s=time.perf_counter() - started,
                          stage_times_s={"single_linear_solve": time.perf_counter() - started},
                          counts={"linear_solves": 1, "rank": None, "stages": 1}, history=[],
                          details={"basis": "single-hidden-layer tanh PIELM fixed features",
                                   "hidden_features": int(n), "seed": B.SEED,
                                   "curriculum": "not required for a linear problem"})
    return record, w


class BeamPINN(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.net = torch.nn.Sequential(torch.nn.Linear(1, 128), torch.nn.Tanh(),
                                       torch.nn.Linear(128, 128), torch.nn.Tanh(),
                                       torch.nn.Linear(128, 1))
        for layer in self.modules():
            if isinstance(layer, torch.nn.Linear):
                torch.nn.init.xavier_normal_(layer.weight); torch.nn.init.zeros_(layer.bias)
    def forward(self, x): return (B.Q0 * B.L**4 / B.EI) * self.net(2 * x / B.L - 1)


def grad(y, x, n):
    for _ in range(n): y = torch.autograd.grad(y, x, torch.ones_like(y), create_graph=True)[0]
    return y


def train_pinn(bc, seed, x_res, x_eval, quick):
    B.set_seed(seed); device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = BeamPINN().to(device=device, dtype=torch.float64)
    xi = torch.as_tensor(x_res[:, None], dtype=torch.float64, device=device).requires_grad_(True)
    x0 = torch.tensor([[0.0]], dtype=torch.float64, device=device, requires_grad=True)
    xL = torch.tensor([[B.L]], dtype=torch.float64, device=device, requires_grad=True)
    wscale = B.Q0 * B.L**4 / B.EI
    adam_steps, lbfgs_steps = ((250, 50) if quick else (10000, 5000)); history = []
    def parts():
        wi = model(xi); pde = torch.mean(((B.EI * grad(wi, xi, 4) - B.Q0) / B.Q0)**2)
        w0, wL = model(x0), model(xL)
        if bc == "SS": vals = [w0/wscale, wL/wscale, grad(w0,x0,2)/(wscale/B.L**2), grad(wL,xL,2)/(wscale/B.L**2)]
        elif bc == "CC": vals = [w0/wscale, grad(w0,x0,1)/(wscale/B.L), wL/wscale, grad(wL,xL,1)/(wscale/B.L)]
        else: vals = [w0/wscale, grad(w0,x0,1)/(wscale/B.L), grad(wL,xL,2)/(wscale/B.L**2), grad(wL,xL,3)/(wscale/B.L**3)]
        bcloss = torch.mean(torch.cat(vals)**2); return pde, bcloss, pde + bcloss
    started=time.perf_counter(); a0=time.perf_counter(); opt=torch.optim.Adam(model.parameters(),lr=1e-3)
    for step in range(adam_steps):
        opt.zero_grad(); p,b,l=parts(); l.backward(); opt.step()
        if step % max(adam_steps//50,1)==0 or step==adam_steps-1: history.append({"phase":"adam","step":step,"loss":float(l.detach().cpu()),"pde":float(p.detach().cpu()),"bc":float(b.detach().cpu())})
    if device.type=="cuda": torch.cuda.synchronize()
    at=time.perf_counter()-a0; calls={"n":0}; l0=time.perf_counter(); lb=torch.optim.LBFGS(model.parameters(),lr=1,max_iter=lbfgs_steps,tolerance_grad=1e-12,tolerance_change=1e-12,history_size=50,line_search_fn="strong_wolfe")
    def closure():
        lb.zero_grad(); p,b,l=parts(); l.backward(); calls["n"]+=1
        if calls["n"] % max(lbfgs_steps//25,1)==0: history.append({"phase":"lbfgs","closure":calls["n"],"loss":float(l.detach().cpu()),"pde":float(p.detach().cpu()),"bc":float(b.detach().cpu())})
        return l
    lb.step(closure)
    if device.type=="cuda": torch.cuda.synchronize()
    lt=time.perf_counter()-l0
    xe=torch.as_tensor(x_eval[:,None],dtype=torch.float64,device=device).requires_grad_(True); w=model(xe); w1=grad(w,xe,1); w2=grad(w,xe,2); w3=grad(w,xe,3); w4=grad(w,xe,4)
    wn=w.detach().cpu().numpy()[:,0]; w1n=w1.detach().cpu().numpy()[:,0]; w2n=w2.detach().cpu().numpy()[:,0]; w3n=w3.detach().cpu().numpy()[:,0]
    ref=B.exact_solution(bc,x_eval[:,None]).ravel(); err=wn-ref; pde=(B.EI*w4.detach().cpu().numpy()[:,0]-B.Q0)
    bcvals=bc_residuals_numpy(bc,wn,w1n,w2n,w3n,-B.EI*w2n,-B.EI*w3n)
    rec=MethodRecord("PINN","euler_bernoulli_beam",bc,seed,"budget_completed",
                     relative_l2=float(np.linalg.norm(err)/np.linalg.norm(ref)),mse=float(np.mean(err**2)),linf=float(np.max(np.abs(err))),
                     audit_residual_rms=float(np.sqrt(np.mean(pde**2))),constraint_bc_linf=None,dense_boundary_linf=float(np.max(np.abs(bcvals))),
                     end_to_end_time_s=time.perf_counter()-started,stage_times_s={"adam":at,"lbfgs":lt},
                     counts={"adam_steps":adam_steps,"lbfgs_closures":calls["n"]},history=history,
                     details={"network":"2x128 tanh","form":"direct fourth-order strong form","boundary":"soft normalized MSE","device":str(device)})
    return rec,wn


def run(output: Path, quick: bool, skip_pinn: bool):
    pts=B.cheb_pts(B.L,B.N_PTS).ravel(); phi,p1,p2=B.rbf_ops(pts[:,None]); prior=B.solve_pipc_prior(pts[:,None],phi,p2); pipc=B.solve_pipc_cpi(pts[:,None],phi,p2,prior)
    x_res=np.linspace(0,B.L,159)[1:-1]; x_eval=np.linspace(0,B.L,B.EVAL_N); records=[]; arrays={"x":x_eval}
    for bc in BCS:
        pr,w=run_deterministic(bc,pts,phi,p1,p2,prior,pipc,x_eval); cr,cw=run_pielm(bc,x_res,pts,x_eval); records.extend([pr,cr]); arrays[f"{bc}_reference"]=B.exact_solution(bc,x_eval[:,None]).ravel(); arrays[f"{bc}_pipc"]=w; arrays[f"{bc}_cl_pielm"]=cw
        if not skip_pinn:
            stochastic=[]
            for seed in SEEDS:
                rec,field=train_pinn(bc,seed,x_res,x_eval,quick); stochastic.append(rec); records.append(rec); arrays[f"{bc}_pinn_seed_{seed}"]=field
            arrays[f"{bc}_pinn_summary_json"]=np.array(json.dumps(summarize_stochastic(stochastic)))
    write_results(output/"beam_results.json",{"quick":quick,"seeds":list(SEEDS),"supports":list(BCS)},records); np.savez_compressed(output/"beam_fields.npz",**arrays); return records


def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument("--output",type=Path,default=DEFAULT_OUTPUT); p.add_argument("--quick",action="store_true"); p.add_argument("--skip-pinn",action="store_true"); a=p.parse_args(); a.output.mkdir(parents=True,exist_ok=True)
    records=run(a.output,a.quick,a.skip_pinn); print(json.dumps([{"method":r.method,"domain":r.domain,"seed":r.seed,"rel_l2":r.relative_l2,"time":r.end_to_end_time_s} for r in records],indent=2))


if __name__=="__main__": main()
