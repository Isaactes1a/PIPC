"""Create LaTeX tables from validated benchmark JSON; never recomputes solutions."""

from __future__ import annotations
import argparse,json,math
from pathlib import Path
import numpy as np


def read(path):
    d=json.loads(path.read_text(encoding="utf-8"))
    if d.get("schema_version")!="pipc-revised-benchmark-v1":raise ValueError(f"bad schema: {path}")
    return d["records"]


def fnum(x):
    if x is None:return "--"
    x=float(x)
    if 1e-2<=abs(x)<1e3:
        return f"{x:.3f}"
    if x == 0.0:
        return "0.00"
    m,e=f"{x:.2e}".split("e")
    return f"${m}\\times10^{{{int(e)}}}$"


def cell(rows,key):
    a=np.array([r[key] for r in rows],float)
    return f"{fnum(a.mean())} $\\pm$ {fnum(a.std())}" if len(a)>1 else fnum(a[0])


def work(r):
    c=r[0]["counts"]
    for k,label in (("nfev","nfev"),("linear_solves","linear solves"),("adam_steps","Adam steps")):
        if k in c:
            vals=[x["counts"].get(k,0) for x in r]
            n=int(np.mean(vals))
            if k=="linear_solves":
                label="linear solve" if n==1 else "linear solves"
            if k=="adam_steps" and "lbfgs_closures" in c:
                m=int(np.mean([x["counts"].get("lbfgs_closures",0) for x in r]))
                return f"{n} Adam + {m} L-BFGS closures"
            return f"{n} {label}"
    return "--"


def ablation_table(path):
    d=json.loads(path.read_text(encoding="utf-8"))
    if d.get("schema_version")!="pipc-initialization-ablation-v1":raise ValueError(f"bad ablation schema: {path}")
    lines=["\\begin{table}[H]","\\centering","\\small",
           "\\caption{Matched PIPC initialization audit on the square von K\\'arm\\'an plate with the PHS-RBF-FD discretization. The deterministic prior and a seeded random start converge to the same discrete root; the zero start stalls within the evaluation budget. nfev counts trust-region residual/Jacobian evaluations.}",
           "\\label{tab:plate-ablation}",
           "\\begin{tabular}{llrrrr}","\\toprule",
           "Initialization & status & nfev & time (s) & final residual RMS & $w_{\\max}$ (m) \\\\","\\midrule"]
    for r in d["records"]:
        status = "converged" if r.get("status") == "converged" else "stalled"
        lines.append(f"{r['initialization'].replace('_',' ')} & {status} & {r['nfev']} & {fnum(r['time_s'])} & {fnum(r['final_residual_rms'])} & {fnum(r['w_max'])} \\\\")
    lines += ["\\bottomrule","\\end{tabular}","\\end{table}",""]
    return "\n".join(lines)


def table(records,domains,methods,caption,label):
    lines=["\\begin{table}[H]","\\centering","\\small",f"\\caption{{{caption}}}",f"\\label{{{label}}}","\\begin{adjustbox}{max width=\\linewidth}","\\begin{tabular}{llrrrrrl}","\\toprule","Domain & Method & $\\relL$ & residual RMS & discrete BC error & dense boundary error & wall time (s) & work count \\\\","\\midrule"]
    for di,domain in enumerate(domains):
        for method in methods:
            rr=[r for r in records if r["domain"]==domain and r["method"]==method]
            if not rr:continue
            constraint="--" if all(r["constraint_bc_linf"] is None for r in rr) else cell([{**r,"v":r["constraint_bc_linf"]} for r in rr],"v")
            lines.append(f"{domain.replace('_',' ')} & {method} & {cell(rr,'relative_l2')} & {cell(rr,'audit_residual_rms')} & {constraint} & {cell(rr,'dense_boundary_linf')} & {cell(rr,'end_to_end_time_s')} & {work(rr)} \\\\")
        if di<len(domains)-1:lines.append("\\addlinespace")
    lines += ["\\bottomrule","\\end{tabular}","\\end{adjustbox}","\\end{table}",""]
    return "\n".join(lines)


def cost_table(linear_records, vk_records):
    """Wall time and method-specific work counters for the plate benchmarks."""
    lines = ["\\begin{table}[H]", "\\centering", "\\small",
             "\\caption{Computational cost on the plate benchmarks. Wall time is end-to-end (operator/feature construction plus solve, excluding reference generation); PINN values are the mean over three seeds. Work counters are method-specific and not interchangeable: linear solves for PIELM/CL-PIELM, trust-region residual/Jacobian evaluations (nfev) for PIPC, and optimizer steps with L-BFGS closure counts for PINN.}",
             "\\label{tab:plate-cost}",
             "\\begin{adjustbox}{max width=\\linewidth}",
             "\\begin{tabular}{llllll}", "\\toprule",
             "Problem & Domain & Method & $\\relL$ & wall time (s) & work \\\\", "\\midrule"]
    panels = (("linear RM", linear_records, "linear_reissner_mindlin_plate"),
              ("von K\\'arm\\'an", vk_records, "von_karman_plate"))
    for pi, (label, records, problem) in enumerate(panels):
        for di, domain in enumerate(("square", "star")):
            first = True
            for method in ("PIPC", "PIELM", "CL-PIELM", "PINN"):
                rr = [r for r in records if r["problem"] == problem and r["domain"] == domain
                      and r["method"] == method]
                if not rr:
                    continue
                rel = cell(rr, "relative_l2")
                t = cell(rr, "end_to_end_time_s")
                if method == "PINN":
                    a = int(np.mean([r["counts"]["adam_steps"] for r in rr]))
                    b = int(np.mean([r["counts"]["lbfgs_closures"] for r in rr]))
                    work = f"{a} Adam + {b} L-BFGS closures"
                elif "nfev" in rr[0]["counts"]:
                    work = f"{rr[0]['counts']['nfev']} nfev"
                elif "linear_solves" in rr[0]["counts"]:
                    n = rr[0]["counts"]["linear_solves"]
                    work = f"{n} linear solve" + ("" if n == 1 else "s")
                else:
                    work = "--"
                prob = label if first else ""
                dom = domain if first else ""
                lines.append(f"{prob} & {dom} & {method} & {rel} & {t} & {work} \\\\")
                first = False
            if di == 0:
                lines.append("\\addlinespace")
        if pi < len(panels) - 1:
            lines.append("\\midrule")
    lines += ["\\bottomrule", "\\end{tabular}", "\\end{adjustbox}", "\\end{table}", ""]
    return "\n".join(lines)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--beam",type=Path,required=True);p.add_argument("--heat",type=Path,required=True);p.add_argument("--plate",type=Path,required=True);p.add_argument("--linear-plate",type=Path,required=True);p.add_argument("--output",type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    jobs=[("beam_table.tex",read(a.beam/"beam_results.json"),("SS","CC","CF"),("PIPC","PIELM","PINN"),"Euler--Bernoulli beam results. PINN values are mean $\\pm$ standard deviation over three seeds. Residual RMS is evaluated on the dimensional mixed equations of Eq.~(2) without division by the reference load; the PIPC solver internally scales these rows by the characteristic load during assembly.","tab:beam"),
          ("heat_table.tex",read(a.heat/"heat_results.json"),("square","equilateral_triangle","snowflake"),("PIPC","CL-PIELM","PINN"),"Nonlinear heat results against independent FEM. PINN values are mean $\\pm$ standard deviation.","tab:heat"),
          ("plate_linear_table.tex",read(a.linear_plate/"plate_linear_results.json"),("square","star"),("PIPC","PIELM","PINN"),"Linear Reissner--Mindlin plate results against P2 FEM.","tab:plate-linear"),
          ("plate_nonlinear_table.tex",read(a.plate/"plate_results.json"),("square","star"),("PIPC","CL-PIELM","PINN"),"Nonlinear von K\\'arm\\'an plate results against independent FEM.","tab:plate-nonlinear")]
    for name,rr,dom,methods,cap,label in jobs:(a.output/name).write_text(table(rr,dom,methods,cap,label),encoding="utf-8")
    # The original one-load ablation is retained only for backward-compatible
    # result directories.  The manuscript now uses the separate multi-load
    # initialization-robustness table generated by make_enhancement_outputs.py.
    old_ablation = a.plate/"plate_initialization_ablation.json"
    if old_ablation.exists():
        (a.output/"plate_ablation_table.tex").write_text(ablation_table(old_ablation),encoding="utf-8")
    (a.output/"plate_cost_table.tex").write_text(cost_table(read(a.linear_plate/"plate_linear_results.json"),
                                                            read(a.plate/"plate_results.json")), encoding="utf-8")


if __name__=="__main__":main()
