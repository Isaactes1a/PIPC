"""Self-contained PHS-RBF-FD operators and plate node clouds for PIPC.

Ported from the reference workflow in
``PIPC-Theory/three_case_manuscript_code/common/rbf_fd.py`` and extended with
(i) a local PHS+polynomial interpolation helper for evaluating fields at
arbitrary points and (ii) square/star node-cloud builders used by the PIPC
plate solvers.

Numerical stability rules followed throughout:
  * stencil weights are obtained with ``numpy.linalg.lstsq`` (never a direct
    solve of the potentially ill-conditioned augmented system);
  * each local system is scaled by the local stencil radius ``h``;
  * the PHS order is an odd integer >= 3 and the polynomial augmentation
    degree is at least 2 for second-order operators;
  * differentiation matrices are assembled as sparse CSR matrices;
  * operator condition estimates are exposed for validation.
"""

from __future__ import annotations

import time
from functools import lru_cache
from itertools import product
from math import factorial
from typing import Iterable

import numpy as np
import scipy.linalg as la
import sympy as sp
from scipy.sparse import csr_matrix
from scipy.sparse import bmat, diags, eye, lil_matrix
from scipy.sparse.linalg import LinearOperator, onenormest, splu
from scipy.interpolate import griddata
from scipy.spatial import cKDTree


def monomial_exponents(dim: int, degree: int) -> list[tuple[int, ...]]:
    exps: list[tuple[int, ...]] = []

    def recurse(prefix: tuple[int, ...], remaining_dim: int, remaining_degree: int):
        if remaining_dim == 1:
            exps.append(prefix + (remaining_degree,))
            return
        for e in range(remaining_degree + 1):
            recurse(prefix + (e,), remaining_dim - 1, remaining_degree - e)

    for total in range(degree + 1):
        recurse((), dim, total)
    return exps


@lru_cache(maxsize=None)
def _kernel_lambdified(kind: str, dim: int, order: tuple[int, ...], shape: float):
    xs = sp.symbols("d0:" + str(dim), real=True)
    r2 = sum(v ** 2 for v in xs)
    if kind.startswith("phs"):
        exponent = int(kind[3:])
        if exponent % 2 != 1 or exponent < 3:
            raise ValueError(f"PHS order must be an odd integer >= 3, got {exponent}")
        expr = r2 ** sp.Rational(exponent, 2)
    else:
        raise ValueError(kind)
    for axis, degree in enumerate(order):
        if degree:
            expr = sp.diff(expr, xs[axis], degree)
    return sp.lambdify(xs, expr, modules="numpy")


def kernel_derivative(kind: str, deltas: np.ndarray, order: tuple[int, ...],
                      shape: float = 0.25) -> np.ndarray:
    deltas = np.asarray(deltas, dtype=float)
    dim = deltas.shape[-1]
    if sum(order) == 0:
        if kind.startswith("phs"):
            exponent = int(kind[3:])
            out = np.sum(deltas ** 2, axis=-1) ** (0.5 * exponent)
        else:
            raise ValueError(kind)
        return out
    fn = _kernel_lambdified(kind, dim, tuple(order), float(shape))
    args = [deltas[..., j] for j in range(dim)]
    with np.errstate(divide="ignore", invalid="ignore", over="ignore"):
        out = np.asarray(fn(*args), dtype=float)
    if out.ndim == 0:
        out = np.full(deltas.shape[:-1], float(out))
    out[~np.isfinite(out)] = 0.0
    return out


def _poly_matrix(relative_points: np.ndarray, exponents: list[tuple[int, ...]]) -> np.ndarray:
    P = np.ones((relative_points.shape[0], len(exponents)), dtype=float)
    for col, exponent in enumerate(exponents):
        val = np.ones(relative_points.shape[0], dtype=float)
        for axis, power in enumerate(exponent):
            if power:
                val *= relative_points[:, axis] ** power
        P[:, col] = val
    return P


def _poly_derivative_at_origin(exponents: list[tuple[int, ...]], order: tuple[int, ...]) -> np.ndarray:
    rhs = np.zeros(len(exponents), dtype=float)
    for j, exponent in enumerate(exponents):
        if tuple(exponent) == tuple(order):
            val = 1.0
            for e in exponent:
                val *= factorial(e)
            rhs[j] = val
    return rhs


def _poly_values_at_origin(exponents: list[tuple[int, ...]]) -> np.ndarray:
    rhs = np.zeros(len(exponents), dtype=float)
    rhs[0] = 1.0
    return rhs


def _segment_inside(p, q, inside, n_samples: int = 19) -> bool:
    t = np.linspace(0.05, 0.95, n_samples)
    pts = p[None, :] + t[:, None] * (q - p)[None, :]
    return bool(np.all(inside(pts)))


def _local_system(rel: np.ndarray, kind: str, poly_degree: int,
                  exponents: list[tuple[int, ...]]) -> np.ndarray:
    pair_delta = rel[:, None, :] - rel[None, :, :]
    A = kernel_derivative(kind, pair_delta, (0,) * rel.shape[1])
    P = _poly_matrix(rel, exponents)
    top = np.hstack((A, P))
    bottom = np.hstack((P.T, np.zeros((P.shape[1], P.shape[1]))))
    return np.vstack((top, bottom))


class PHSRBFFDOps:
    """Local PHS-RBF-FD differentiation matrices with polynomial augmentation."""

    def __init__(self, points: np.ndarray, orders: Iterable[tuple[int, ...]],
                 stencil_size: int = 19, poly_degree: int = 3, phs_order: int = 7,
                 inside=None):
        self.points = np.asarray(points, dtype=float)
        self.n, self.dim = self.points.shape
        self.orders = tuple(dict.fromkeys(tuple(o) for o in orders))
        self.stencil_size = min(int(stencil_size), self.n)
        self.poly_degree = int(poly_degree)
        self.phs_kind = f"phs{int(phs_order)}"
        self.exponents = monomial_exponents(self.dim, self.poly_degree)
        min_size = len(self.exponents) + 3
        if self.stencil_size < min_size:
            raise ValueError(
                f"stencil_size={self.stencil_size} too small for dim={self.dim}, "
                f"degree={self.poly_degree}; need at least {min_size}."
            )
        self.tree = cKDTree(self.points)
        self.neighbors = self.tree.query(self.points, k=self.stencil_size)[1]
        if inside is not None:
            self.neighbors = self._visibility_filter(inside)
        self._local_data = self._prepare_local_systems()
        self.matrices = {order: self._assemble(order) for order in self.orders}

    def _prepare_local_systems(self):
        """Build each scaled stencil system once and retain condition audits."""
        data = []
        condition = np.empty(self.n, dtype=float)
        for i in range(self.n):
            nbr = np.asarray(self.neighbors[i], dtype=int)
            rel_physical = self.points[nbr] - self.points[i]
            h = max(float(np.max(np.linalg.norm(rel_physical, axis=1))), 1.0e-12)
            rel = rel_physical / h
            system = _local_system(rel, self.phs_kind, self.poly_degree, self.exponents)
            condition[i] = float(np.linalg.cond(system))
            data.append((nbr, h, rel, system))
        self.local_condition_numbers = condition
        finite = condition[np.isfinite(condition)]
        self.local_condition_stats = {
            "median": float(np.median(finite)) if len(finite) else float("inf"),
            "p95": float(np.percentile(finite, 95)) if len(finite) else float("inf"),
            "maximum": float(np.max(finite)) if len(finite) else float("inf"),
            "nonfinite": int(np.count_nonzero(~np.isfinite(condition))),
        }
        return data

    def _visibility_filter(self, inside):
        filtered = []
        for i in range(self.n):
            idx = np.asarray(self.neighbors[i], dtype=int)
            keep = []
            for j in idx:
                if len(keep) >= self.stencil_size:
                    break
                if j == i or _segment_inside(self.points[i], self.points[j], inside):
                    keep.append(j)
            if len(keep) < self.stencil_size:
                # fall back to raw kNN if the domain is locally too narrow
                keep = idx.tolist()[: self.stencil_size]
            filtered.append(np.asarray(keep, dtype=int))
        return filtered

    def _assemble(self, order: tuple[int, ...]) -> csr_matrix:
        rows, cols, vals = [], [], []
        order_total = sum(order)
        for i in range(self.n):
            nbr, h, rel, system = self._local_data[i]
            delta = -rel[None, :, :]
            rhs_kernel = kernel_derivative(self.phs_kind, delta, order)[0] / (h ** order_total)
            rhs_poly = _poly_derivative_at_origin(self.exponents, order) / (h ** order_total)
            rhs = np.concatenate((rhs_kernel, rhs_poly))
            # lstsq is used instead of a direct solve: PHS systems are
            # frequently ill-conditioned on structured clouds and lstsq keeps
            # the operators usable without warning spam.
            w = la.lstsq(system, rhs)[0][: self.stencil_size]
            rows.extend([i] * self.stencil_size)
            cols.extend(nbr.tolist())
            vals.extend(w.tolist())
        return csr_matrix((vals, (rows, cols)), shape=(self.n, self.n))

    def derivative(self, values: np.ndarray, order: tuple[int, ...]) -> np.ndarray:
        return np.asarray(self.matrices[tuple(order)] @ np.asarray(values, dtype=float)).reshape(-1)


def build_operators_2d(points, stencil_size=19, poly_degree=2, phs_power=3, second=True,
                       inside=None):
    orders = [(1, 0), (0, 1)]
    if second:
        orders += [(2, 0), (0, 2), (1, 1)]
    ops = PHSRBFFDOps(np.asarray(points, dtype=float), orders,
                      stencil_size=stencil_size, poly_degree=poly_degree, phs_order=phs_power,
                      inside=inside)
    out = {"Dx": ops.matrices[(1, 0)], "Dy": ops.matrices[(0, 1)]}
    if second:
        out.update({"Dxx": ops.matrices[(2, 0)], "Dyy": ops.matrices[(0, 2)],
                    "Dxy": ops.matrices[(1, 1)]})
    return out


def interpolate_points(points: np.ndarray, values: np.ndarray, query: np.ndarray,
                       stencil_size=19, poly_degree=2, phs_order=3, inside=None) -> np.ndarray:
    """Local PHS+polynomial interpolation of a nodal field at arbitrary points.

    Each query point uses its ``stencil_size`` nearest nodes, the local system
    is scaled by the query-to-neighbor radius, and only the function-value
    weights are applied to the nodal values (polynomial augmentation is used
    for reproduction, not for a polynomial drift term).
    """
    points = np.asarray(points, dtype=float)
    values = np.asarray(values, dtype=float)
    query = np.asarray(query, dtype=float)
    kind = f"phs{int(phs_order)}"
    exponents = monomial_exponents(points.shape[1], int(poly_degree))
    tree = cKDTree(points)
    k = min(int(stencil_size), len(points))
    _, nbr = tree.query(query, k=k)
    nbr = np.atleast_2d(nbr)
    out = np.zeros(len(query), dtype=float)
    for i, q in enumerate(query):
        idx = np.asarray(nbr[i], dtype=int)
        if inside is not None:
            vis = [j for j in idx if j == i or _segment_inside(q, points[j], inside)]
            if len(vis) >= 3:
                idx = np.asarray(vis[:k], dtype=int)
        rel = (points[idx] - q)
        h = float(np.max(np.linalg.norm(rel, axis=1)))
        h = max(h, 1.0e-12)
        rel = rel / h
        system = _local_system(rel, kind, int(poly_degree), exponents)
        rhs = np.concatenate((
            kernel_derivative(kind, -rel[None, :, :], (0,) * points.shape[1])[0],
            _poly_values_at_origin(exponents),
        ))
        w = la.lstsq(system, rhs)[0][: len(idx)]
        out[i] = float(np.dot(w, values[idx]))
    return out


def inside_star(points: np.ndarray, tol: float = 1e-12) -> np.ndarray:
    r = np.hypot(points[:, 0], points[:, 1])
    th = np.arctan2(points[:, 1], points[:, 0])
    return r <= 1 + 0.3 * np.sin(5 * th) + tol


def inside_square(points: np.ndarray, tol: float = 1e-12) -> np.ndarray:
    return (np.abs(points[:, 0]) <= 1 + tol) & (np.abs(points[:, 1]) <= 1 + tol)


def star_boundary(n_bnd: int) -> np.ndarray:
    th = np.linspace(0, 2 * np.pi, int(n_bnd), endpoint=False)
    R = 1 + 0.3 * np.sin(5 * th)
    return np.column_stack([R * np.cos(th), R * np.sin(th)])


def square_cloud(n_grid: int):
    x = np.linspace(-1, 1, int(n_grid))
    X, Y = np.meshgrid(x, x, indexing="xy")
    pts = np.column_stack([X.ravel(), Y.ravel()])
    tol = 1e-7
    is_bnd = (np.abs(np.abs(pts[:, 0]) - 1.0) < tol) | (np.abs(np.abs(pts[:, 1]) - 1.0) < tol)
    return pts, is_bnd


def star_cloud(n_bnd: int = 200, spacing: float = 0.06):
    pts_bnd = star_boundary(n_bnd)
    extent = 1.35
    xs = np.arange(-extent, extent + 0.5 * spacing, spacing)
    X, Y = np.meshgrid(xs, xs, indexing="xy")
    pts = np.column_stack([X.ravel(), Y.ravel()])
    keep = inside_star(pts, tol=0.0)
    # keep interior points with a small clearance from the boundary so that
    # near-boundary stencils contain boundary nodes rather than duplicating
    # the boundary curve.
    r = np.hypot(pts[:, 0], pts[:, 1])
    th = np.arctan2(pts[:, 1], pts[:, 0])
    keep &= r <= 1 + 0.3 * np.sin(5 * th) - 0.5 * spacing
    interior = pts[keep]
    all_pts = np.vstack([pts_bnd, interior])
    is_bnd = np.zeros(len(all_pts), dtype=bool)
    is_bnd[: len(pts_bnd)] = True
    return all_pts, is_bnd


def build_cloud(shape: str, quick: bool):
    if shape == "square":
        return square_cloud(11 if quick else 21)
    return star_cloud(80 if quick else 200, 0.14 if quick else 0.06)


def operator_condition(ops: PHSRBFFDOps, order: tuple[int, ...]) -> float:
    M = ops.matrices[tuple(order)]
    s = la.svd(M.toarray(), compute_uv=False)
    s = s[s > 0]
    return float(s[0] / s[-1])


class RBFDPlateSolver:
    """Geometry + PHS-RBF-FD operators for the plate benchmarks.

    Exposes the attributes consumed by the unchanged PIELM/CL-PIELM branches
    (``pts``, ``idx_int``, ``idx_bnd``, ``cfg``, ``D``, ``Cs``, ``nu``,
    ``shape``) so the benchmark scripts only replace the PIPC branch.
    """

    def __init__(self, shape: str, cfg: dict | None = None, quick: bool = False,
                 pts: np.ndarray | None = None, is_bnd: np.ndarray | None = None):
        default = {
            "E": 1e5, "nu": 0.3, "h": 0.05, "q0": 0.005,
            "stencil": 19 if quick else 19, "poly_degree": 3 if not quick else 2,
            "phs_order": 3, "rcond": 1e-12,
        }
        default.update(cfg or {})
        self.cfg = default
        self.shape = shape
        if pts is None or is_bnd is None:
            pts, is_bnd = build_cloud(shape, quick)
        pts = np.asarray(pts, dtype=float)
        is_bnd = np.asarray(is_bnd, dtype=bool)
        self.pts = pts
        self.is_bnd = is_bnd
        self.idx_bnd = np.where(is_bnd)[0]
        self.idx_int = np.where(~is_bnd)[0]
        self.N = len(pts)
        self.N_int = len(self.idx_int)
        self.E = default["E"]
        self.nu = default["nu"]
        self.h = default["h"]
        self.D = self.E * self.h ** 3 / (12 * (1 - self.nu ** 2))
        self.G = self.E / (2 * (1 + self.nu))
        self.Cs = (5.0 / 6.0) * self.G * self.h
        self.stencil = int(default["stencil"])
        self.poly_degree = int(default["poly_degree"])
        self.phs_order = int(default["phs_order"])
        orders = [(1, 0), (0, 1)]
        if bool(default.get("second_operators", True)):
            orders += [(2, 0), (0, 2), (1, 1)]
        builder = PHSRBFFDOps(
            pts, orders, self.stencil, self.poly_degree, self.phs_order,
            inside=(inside_star if shape == "star" else None))
        sparse = {"Dx": builder.matrices[(1, 0)], "Dy": builder.matrices[(0, 1)]}
        if (2, 0) in builder.matrices:
            sparse.update({"Dxx": builder.matrices[(2, 0)],
                           "Dyy": builder.matrices[(0, 2)],
                           "Dxy": builder.matrices[(1, 1)]})
        self.operator_builder = builder
        self.local_condition_stats = dict(builder.local_condition_stats)
        self.sparse_ops = sparse
        self.ops = {k: v for k, v in sparse.items()}
        self._build_reduced()

    def _build_reduced(self):
        n_int = self.N_int
        rows = self.idx_int
        cols = np.arange(n_int)
        E = csr_matrix((np.ones(n_int), (rows, cols)), shape=(self.N, n_int))
        self.E_map = E
        self.r = {}
        for key in self.ops:
            M = self.ops[key]
            self.r[f"{key}_r"] = (M @ E).tocsr()
        if "Dxx_r" in self.r:
            self.r["Lap_r"] = (self.r["Dxx_r"] + self.r["Dyy_r"]).tocsr()


def boundary_normals(shape: str, pts_bnd: np.ndarray) -> np.ndarray:
    """Outward unit normals at the boundary points (ported from plate_rm.py)."""
    if shape == "square":
        n = np.zeros_like(pts_bnd)
        tol = 1e-7
        n[pts_bnd[:, 0] > 1 - tol, 0] = 1.0
        n[pts_bnd[:, 0] < -1 + tol, 0] = -1.0
        n[pts_bnd[:, 1] > 1 - tol, 1] = 1.0
        n[pts_bnd[:, 1] < -1 + tol, 1] = -1.0
        return n
    t = np.roll(pts_bnd, -1, axis=0) - pts_bnd
    t = t / np.linalg.norm(t, axis=1, keepdims=True)
    n = np.column_stack([-t[:, 1], t[:, 0]])
    mid = 0.5 * (pts_bnd + np.roll(pts_bnd, -1, axis=0))
    if np.mean(n[:, 0] * mid[:, 0] + n[:, 1] * mid[:, 1]) < 0:
        n = -n
    return n


def dense_boundary(shape: str, n: int = 400) -> np.ndarray:
    if shape == "star":
        th = np.linspace(0, 2 * np.pi, n, endpoint=False)
        rr = 1 + 0.3 * np.sin(5 * th)
        return np.column_stack([rr * np.cos(th), rr * np.sin(th)])
    m = max(n // 4, 2)
    t = np.linspace(-1, 1, m, endpoint=False)
    return np.vstack((np.c_[t, -np.ones(m)], np.c_[np.ones(m), t],
                      np.c_[-t, np.ones(m)], np.c_[-np.ones(m), -t]))


def _griddata_fill(nodes: np.ndarray, values: np.ndarray, query: np.ndarray) -> np.ndarray:
    out = griddata(nodes, values, query, method="linear")
    out = np.asarray(out, dtype=float)
    bad = ~np.isfinite(out)
    if bad.any():
        tree = cKDTree(nodes)
        _, idx = tree.query(query[bad])
        out[bad] = values[idx]
    return out


def _row_normalize(A):
    A = A.tocsr()
    nrm = np.asarray(A.multiply(A).sum(axis=1)).ravel()
    nrm = np.sqrt(nrm)
    nrm[nrm == 0] = 1.0
    Dinv = diags(1.0 / nrm)
    return (Dinv @ A).tocsr()


def _cond_estimate(A):
    """Condition estimate: dense SVD for small systems, 1-norm estimate otherwise."""
    A = A.tocsr()
    if A.shape[0] * A.shape[1] <= 24_000_000:
        s = np.linalg.svd(A.toarray(), compute_uv=False)
        s = s[s > 0]
        return float(s[0] / s[-1])
    if A.shape[0] != A.shape[1]:
        return float("inf")
    n1 = float(onenormest(A))
    try:
        lu = splu(A.tocsc())
        Ainv = LinearOperator(A.shape, matvec=lambda v: lu.solve(v),
                              rmatvec=lambda v: lu.solve(v, trans="T"))
        n1_inv = float(onenormest(Ainv))
    except Exception:
        return float("inf")
    return n1 * n1_inv


def solve_linear_rm_pipc(solver: RBFDPlateSolver, epts: np.ndarray, fem_w: np.ndarray,
                         quick: bool, boundary_pts: np.ndarray):
    """PIPC for the linear Reissner--Mindlin plate (first-order 8-field form).

    Unknowns per node: w, beta_x, beta_y, Mxx, Myy, Mxy, Qx, Qy. Only first
    derivatives of the PHS-RBF-FD operators enter, which keeps the local
    systems well conditioned on non-convex clouds. w is reduced exactly on the
    boundary; the moment boundary conditions are value constraints appended as
    rows. Returns (record, w_nodes, pred).
    """
    from common import MethodRecord

    started = time.perf_counter()
    ii, b = solver.idx_int, solver.idx_bnd
    nb, N, n = len(b), solver.N, solver.N_int
    D, Cs, nu, q0 = solver.D, solver.Cs, solver.nu, solver.cfg["q0"]
    Dx, Dy = solver.ops["Dx"], solver.ops["Dy"]
    Dxr = (Dx @ solver.E_map).tocsr()
    Dyr = (Dy @ solver.E_map).tocsr()
    rows = 8 * N + 3 * nb
    cols = n + 7 * N
    A = lil_matrix((rows, cols))
    rhs = np.zeros(rows)
    I = eye(N, format="csr")
    bx, by = n, n + N
    mxx, myy, mxy = n + 2 * N, n + 3 * N, n + 4 * N
    qx, qy = n + 5 * N, n + 6 * N
    # constitutive relations at all nodes
    A[0:N, mxx:mxx + N] = I
    A[0:N, bx:bx + N] = -D * Dx
    A[0:N, by:by + N] = -D * nu * Dy
    A[N:2 * N, myy:myy + N] = I
    A[N:2 * N, bx:bx + N] = -D * nu * Dx
    A[N:2 * N, by:by + N] = -D * Dy
    A[2 * N:3 * N, mxy:mxy + N] = I
    A[2 * N:3 * N, bx:bx + N] = -D * (1 - nu) / 2 * Dy
    A[2 * N:3 * N, by:by + N] = -D * (1 - nu) / 2 * Dx
    # shear constitutive relations at all nodes
    A[3 * N:4 * N, qx:qx + N] = I
    A[3 * N:4 * N, bx:bx + N] = -Cs * I
    A[3 * N:4 * N, 0:n] = -Cs * Dxr
    A[4 * N:5 * N, qy:qy + N] = I
    A[4 * N:5 * N, by:by + N] = -Cs * I
    A[4 * N:5 * N, 0:n] = -Cs * Dyr
    # equilibrium at all nodes
    A[5 * N:6 * N, mxx:mxx + N] = Dx
    A[5 * N:6 * N, mxy:mxy + N] = Dy
    A[5 * N:6 * N, qx:qx + N] = -I
    A[6 * N:7 * N, mxy:mxy + N] = Dx
    A[6 * N:7 * N, myy:myy + N] = Dy
    A[6 * N:7 * N, qy:qy + N] = -I
    A[7 * N:8 * N, qx:qx + N] = Dx
    A[7 * N:8 * N, qy:qy + N] = Dy
    rhs[7 * N:8 * N] = -q0
    # boundary value rows: Mnn = 0 and Mns = 0 (w = 0 is reduced exactly)
    r0 = 8 * N
    nm = boundary_normals(solver.shape, solver.pts[b])
    nx, ny = nm[:, :1], nm[:, 1:]
    Ib = I[b]
    nx2 = diags(nx.ravel() ** 2)
    ny2 = diags(ny.ravel() ** 2)
    nxny = diags((nx * ny).ravel())
    A[r0:r0 + nb, mxx:mxx + N] = nx2 @ Ib
    A[r0:r0 + nb, mxy:mxy + N] = 2 * nxny @ Ib
    A[r0:r0 + nb, myy:myy + N] = ny2 @ Ib
    A[r0 + nb:r0 + 2 * nb, mxx:mxx + N] = -nxny @ Ib
    A[r0 + nb:r0 + 2 * nb, mxy:mxy + N] = (ny2 - nx2) / 2 @ Ib
    A[r0 + nb:r0 + 2 * nb, myy:myy + N] = nxny @ Ib

    A = A.tocsr()
    An = _row_normalize(A)
    rn = np.sqrt(np.asarray(A.multiply(A).sum(axis=1)).ravel())
    rn[rn == 0] = 1.0
    bn = rhs / rn
    t0 = time.perf_counter()
    if An.shape[0] * An.shape[1] <= 24_000_000:
        x, *_ = np.linalg.lstsq(An.toarray(), bn, rcond=solver.cfg["rcond"])
    else:
        from scipy.sparse.linalg import lsqr

        x = lsqr(An, bn, atol=solver.cfg["rcond"], btol=solver.cfg["rcond"])[0]
    solve_time = time.perf_counter() - t0
    w_nodes = solver.E_map @ x[:n]
    pred = interpolate_points(
        solver.pts, w_nodes, epts, solver.stencil, solver.poly_degree,
        solver.phs_order, inside=(inside_star if solver.shape == "star" else None))
    keep = np.isfinite(pred) & np.isfinite(fem_w)
    err = pred[keep] - np.asarray(fem_w)[keep]
    ref_kept = np.asarray(fem_w)[keep]
    rel = float(np.linalg.norm(err) / max(np.linalg.norm(ref_kept), 1e-30))
    mse = float(np.mean(err * err))
    linf = float(np.max(np.abs(err)))
    raw_res = A @ x - rhs
    dense = float(np.max(np.abs(interpolate_points(
        solver.pts, w_nodes, boundary_pts, solver.stencil, solver.poly_degree,
        solver.phs_order, inside=(inside_star if solver.shape == "star" else None)))))
    constraint = float(np.max(np.abs(w_nodes[solver.idx_bnd])))
    cond = _cond_estimate(An)
    record = MethodRecord(
        "PIPC", "linear_reissner_mindlin_plate", solver.shape, None, "completed",
        relative_l2=rel, mse=mse, linf=linf,
        audit_residual_rms=float(np.sqrt(np.mean(raw_res ** 2))),
        constraint_bc_linf=constraint, dense_boundary_linf=dense,
        end_to_end_time_s=time.perf_counter() - started,
        stage_times_s={"linear_solve": solve_time}, counts={"linear_solves": 1},
        history=[], details={
            "basis": "PHS-RBF-FD", "form": "first-order 8-field mixed",
            "stencil": solver.stencil, "poly_degree": solver.poly_degree,
            "phs_order": solver.phs_order, "n_nodes": solver.N,
            "n_int": solver.N_int, "n_bnd": nb,
            "rcond": solver.cfg["rcond"], "condition_number": cond,
            "local_condition_stats": solver.local_condition_stats,
            "normalized_residual_rms": float(np.sqrt(np.mean((An @ x - bn) ** 2))),
            "constraint": "hard nodal reduction for w",
        },
    )
    return record, w_nodes, pred


class VKRBFDSolver(RBFDPlateSolver):
    """Four-field (w, M_w, psi, M_psi) von Karman plate on PHS-RBF-FD nodes."""

    def __init__(self, shape: str, cfg: dict | None = None, quick: bool = False,
                 pts: np.ndarray | None = None, is_bnd: np.ndarray | None = None):
        base = {"E": 1e5, "nu": 0.3, "h": 0.01, "q0": 0.005,
                "stencil": 19 if quick else 31, "poly_degree": 3 if not quick else 2,
                "phs_order": 3, "rcond": 1e-12}
        base.update(cfg or {})
        super().__init__(shape, base, quick=quick, pts=pts, is_bnd=is_bnd)

    def reduced_ops(self):
        ii = self.idx_int
        out = {
            "Lap": self.r["Lap_r"][ii].tocsr(),
            "Dxx": self.r["Dxx_r"][ii].tocsr(),
            "Dyy": self.r["Dyy_r"][ii].tocsr(),
            "Dxy": self.r["Dxy_r"][ii].tocsr(),
            "n": self.N_int,
        }
        return out

    def linear_prior(self):
        o = self.reduced_ops()
        n = o["n"]
        A = bmat([[self.D * o["Lap"], eye(n)], [None, o["Lap"]]], format="csr")
        rhs = np.concatenate([np.zeros(n), -np.full(n, self.cfg["q0"])])
        try:
            lam = splu(A.tocsc()).solve(rhs)
        except Exception:
            lam, *_ = np.linalg.lstsq(A.toarray(), rhs, rcond=self.cfg["rcond"])
        return lam

    def residual_and_jac(self, alpha):
        o = self.reduced_ops()
        n = o["n"]
        aw, aM, apsi, aMpsi = alpha[0:n], alpha[n:2 * n], alpha[2 * n:3 * n], alpha[3 * n:]
        w_xx, w_yy, w_xy = o["Dxx"] @ aw, o["Dyy"] @ aw, o["Dxy"] @ aw
        psi_xx, psi_yy, psi_xy = o["Dxx"] @ apsi, o["Dyy"] @ apsi, o["Dxy"] @ apsi
        r0 = self.D * (o["Lap"] @ aw) + aM
        r1 = o["Lap"] @ aM + self.cfg["q0"] + self.cfg["h"] * (
            psi_yy * w_xx + psi_xx * w_yy - 2 * psi_xy * w_xy)
        r2 = o["Lap"] @ apsi + aMpsi
        r3 = (1.0 / self.cfg["E"]) * (o["Lap"] @ aMpsi) + (w_xy ** 2 - w_xx * w_yy)
        r = np.concatenate([r0, r1, r2, r3])
        J = lil_matrix((4 * n, 4 * n))
        J[0:n, 0:n] = self.D * o["Lap"]
        J[0:n, n:2 * n] = eye(n)
        J[n:2 * n, n:2 * n] = o["Lap"]
        J[n:2 * n, 0:n] = self.cfg["h"] * (
            diags(psi_yy) @ o["Dxx"] + diags(psi_xx) @ o["Dyy"] - 2 * diags(psi_xy) @ o["Dxy"])
        J[n:2 * n, 2 * n:3 * n] = self.cfg["h"] * (
            diags(w_xx) @ o["Dyy"] + diags(w_yy) @ o["Dxx"] - 2 * diags(w_xy) @ o["Dxy"])
        J[2 * n:3 * n, 2 * n:3 * n] = o["Lap"]
        J[2 * n:3 * n, 3 * n:4 * n] = eye(n)
        J[3 * n:4 * n, 3 * n:4 * n] = (1.0 / self.cfg["E"]) * o["Lap"]
        J[3 * n:4 * n, 0:n] = 2 * diags(w_xy) @ o["Dxy"] \
            - diags(w_xx) @ o["Dyy"] - diags(w_yy) @ o["Dxx"]
        return r, J.tocsr()

    def residual_row_scales(self, alpha):
        """Return Jacobian infinity row norms for a reusable residual scaling."""
        J = abs(self.residual_and_jac(alpha)[1])
        scales = np.asarray(J.max(axis=1).toarray()).ravel()
        return np.maximum(scales, 1e-30)

    def solve_trf(self, alpha0, max_nfev=2000, xtol=1e-14,
                  row_scales=None, tr_solver="exact", tr_options=None):
        from scipy.optimize import least_squares

        t0 = time.perf_counter()
        # Row scales are fixed at the initial iterate using the Jacobian row
        # norms. For a square system this leaves the root unchanged while
        # giving every physical block a comparable weight in the least-squares
        # objective (the four-field residual mixes units that differ by orders
        # of magnitude, e.g. the bending block vs. the Airy block).
        scales = (self.residual_row_scales(alpha0) if row_scales is None
                  else np.asarray(row_scales, dtype=float).reshape(-1))
        if len(scales) != 4 * self.N_int or np.any(scales <= 0):
            raise ValueError("row_scales must contain one positive value per residual row")
        sparse_trf = tr_solver == "lsmr"

        def fun(a):
            return self.residual_and_jac(a)[0] / scales

        def jac(a):
            J = self.residual_and_jac(a)[1]
            if sparse_trf:
                return J.multiply(1.0 / scales[:, None])
            return J.toarray() / scales[:, None]

        if sparse_trf and tr_options is None:
            tr_options = {"atol": 1e-12, "btol": 1e-12, "conlim": 1e14,
                          "maxiter": min(5000, 4 * self.N_int)}
        sol = least_squares(fun, alpha0, jac=jac, method="trf", tr_solver=tr_solver,
                            tr_options=tr_options,
                            x_scale="jac",
                            ftol=xtol, xtol=xtol, gtol=xtol, max_nfev=max_nfev)
        return sol, time.perf_counter() - t0

    def solve_newton(self, alpha0, max_iter=50, tol=1e-10):
        t0 = time.perf_counter()
        alpha = alpha0.copy()
        it = 0
        for it in range(1, max_iter + 1):
            r, J = self.residual_and_jac(alpha)
            try:
                d = splu(J.tocsc()).solve(-r)
            except Exception:
                d = np.linalg.lstsq(J.toarray(), -r, rcond=None)[0]
            step = d
            rn = self.residual_and_jac(alpha + step)[0]
            ns = 0
            while np.linalg.norm(rn) > np.linalg.norm(r) and ns < 20:
                step = 0.5 * step
                rn = self.residual_and_jac(alpha + step)[0]
                ns += 1
            alpha = alpha + step
            if np.linalg.norm(step) < tol * (np.linalg.norm(alpha) + 1e-12):
                break
        return alpha, time.perf_counter() - t0, it


def solve_vk_pipc(shape: str, cfg: dict | None, fem: dict, epts: np.ndarray, quick: bool,
                  pts: np.ndarray | None = None, is_bnd: np.ndarray | None = None):
    """PIPC for the nonlinear von Karman plate (four-field nodal unknowns)."""
    from common import MethodRecord

    started = time.perf_counter()
    solver = VKRBFDSolver(shape, cfg, quick=quick, pts=pts, is_bnd=is_bnd)
    n = solver.N_int
    linear = solver.linear_prior()
    alpha0 = np.concatenate([linear[:n], linear[n:], np.zeros(2 * n)])
    initial = solver.residual_and_jac(alpha0)[0]
    direction = np.random.default_rng(42).normal(size=len(alpha0))
    direction /= np.linalg.norm(direction)
    eps = 1e-6
    fd = (solver.residual_and_jac(alpha0 + eps * direction)[0]
          - solver.residual_and_jac(alpha0 - eps * direction)[0]) / (2 * eps)
    analytic = solver.residual_and_jac(alpha0)[1] @ direction
    jacerr = float(np.linalg.norm(fd - analytic) / max(np.linalg.norm(analytic), 1e-30))
    max_nfev = 100 if quick else 2000
    xtol = 1e-11 if quick else 1e-14
    sol, solve_time = solver.solve_trf(alpha0, max_nfev=max_nfev, xtol=xtol)
    newton_alpha, newton_time, newton_iters = solver.solve_newton(alpha0, max_iter=20 if quick else 50, tol=1e-10)
    w_nodes = solver.E_map @ sol.x[:n]
    w_newton = solver.E_map @ newton_alpha[:n]
    newton_rel = float(np.linalg.norm(w_nodes - w_newton) / max(np.linalg.norm(w_newton), 1e-30))
    pred = interpolate_points(
        solver.pts, w_nodes, epts, solver.stencil, solver.poly_degree,
        solver.phs_order, inside=(inside_star if shape == "star" else None))
    ref = (np.asarray(fem["eval_w"], dtype=float)
           if "eval_w" in fem else griddata(fem["pts"], fem["w"], epts, method="linear"))
    keep = np.isfinite(pred) & np.isfinite(ref)
    p, r = pred[keep], ref[keep]
    e = p - r
    metrics = {
        "relative_l2": float(np.linalg.norm(e) / max(np.linalg.norm(r), 1e-30)),
        "mse": float(np.mean(e ** 2)), "linf": float(np.max(np.abs(e))),
    }
    residual = solver.residual_and_jac(sol.x)[0]
    bpts = dense_boundary(shape, 100 if quick else 400)
    dense = float(np.max(np.abs(interpolate_points(
        solver.pts, w_nodes, bpts, solver.stencil, solver.poly_degree,
        solver.phs_order, inside=(inside_star if shape == "star" else None)))))
    constraint = float(np.max(np.abs(w_nodes[solver.idx_bnd])))
    J = solver.residual_and_jac(sol.x)[1]
    cond = _cond_estimate(J)
    record = MethodRecord(
        "PIPC", "von_karman_plate", shape, None,
        "converged" if sol.success else f"status_{sol.status}",
        **metrics, audit_residual_rms=float(np.sqrt(np.mean(residual ** 2))),
        constraint_bc_linf=constraint, dense_boundary_linf=dense,
        end_to_end_time_s=time.perf_counter() - started,
        stage_times_s={"full_nonlinear_trf": solve_time,
                       "same_discretization_newton_audit": newton_time},
        counts={"nfev": int(sol.nfev), "njev": int(sol.njev or 0), "stages": 1,
                "newton_audit_iterations": int(newton_iters)},
        history=[{"initial_residual_rms": float(np.sqrt(np.mean(initial ** 2))),
                  "final_residual_rms": float(np.sqrt(np.mean(residual ** 2)))}],
        details={"basis": "PHS-RBF-FD", "prior": "linear four-field plate",
                 "stencil": solver.stencil, "poly_degree": solver.poly_degree,
                 "phs_order": solver.phs_order, "n_nodes": solver.N, "n_int": n,
                  "rcond": solver.cfg["rcond"], "condition_number": cond,
                  "local_condition_stats": solver.local_condition_stats,
                 "jacobian_directional_error": jacerr,
                 "same_discretization_newton_relative_l2": newton_rel,
                 "curved_boundary_caveat": shape == "star"},
    )
    return record, solver, sol.x, pred, ref, keep
