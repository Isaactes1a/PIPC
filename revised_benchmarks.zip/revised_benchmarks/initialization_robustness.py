"""Load-by-initialization robustness audit for the square von Karman plate."""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path

import numpy as np

import phs_rbf_fd as PHS

HERE = Path(__file__).resolve().parent
DEFAULT_OUTPUT = HERE / "results" / "initialization_robustness"
BASE_LOAD = 0.005
FULL_GAMMAS = (0.25, 0.5, 1.0, 2.0, 4.0, 8.0)
FULL_SEEDS = tuple(range(1001, 1021))


def rms(values):
    values = np.asarray(values, dtype=float)
    return float(np.sqrt(np.mean(values * values)))


def smooth_random_field(points, rng, modes=3):
    """Low-frequency random sine field satisfying zero square-boundary data."""
    x, y = points[:, 0], points[:, 1]
    field = np.zeros(len(points), dtype=float)
    coefficients = rng.normal(size=(modes, modes))
    for m in range(1, modes + 1):
        for n in range(1, modes + 1):
            field += coefficients[m - 1, n - 1] * np.sin(m * np.pi * (x + 1) / 2) \
                * np.sin(n * np.pi * (y + 1) / 2)
    return field / max(rms(field), 1e-30)


def random_start(solver, linear, seed):
    n = solver.N_int
    w_scale = max(rms(linear[:n]), 1e-12)
    moment_scale = max(rms(linear[n:]), solver.D * w_scale, 1e-12)
    airy_scale = max(solver.cfg["E"] * w_scale * w_scale, 1e-12)
    scales = (w_scale, moment_scale, airy_scale, airy_scale)
    rng = np.random.default_rng(seed)
    fields = [smooth_random_field(solver.pts[solver.idx_int], rng) * scale
              for scale in scales]
    return np.concatenate(fields), scales


def solve_record(solver, name, seed, start, row_scales, branch_w, max_nfev):
    initial = solver.residual_and_jac(start)[0]
    sol, elapsed = solver.solve_trf(
        start, max_nfev=max_nfev, xtol=1e-14, row_scales=row_scales,
        tr_solver="exact")
    final = solver.residual_and_jac(sol.x)[0]
    w = np.asarray(solver.E_map @ sol.x[:solver.N_int]).ravel()
    normalized_rms = rms(final / row_scales)
    branch_relative_l2 = float(np.linalg.norm(w - branch_w) /
                               max(np.linalg.norm(branch_w), 1e-30))
    accepted = bool(sol.success and normalized_rms <= 1e-8 and
                    branch_relative_l2 <= 1e-5)
    return {
        "initialization": name, "seed": seed,
        "optimizer_success": bool(sol.success), "optimizer_status": int(sol.status),
        "accepted_convergence": accepted, "nfev": int(sol.nfev),
        "njev": int(sol.njev or 0), "time_s": float(elapsed),
        "initial_residual_rms": rms(initial), "final_residual_rms": rms(final),
        "final_normalized_residual_rms": normalized_rms,
        "branch_relative_l2": branch_relative_l2,
        "w_max": float(np.max(np.abs(w))),
    }


def solve_case_worker(gamma, name, seed, branch_w, max_nfev, quick):
    """Construct an isolated solver so Jacobian assembly can run in a process."""
    points, boundary = PHS.square_cloud(11 if quick else 21)
    solver = PHS.VKRBFDSolver(
        "square", {"q0": gamma * BASE_LOAD,
                   "stencil": 19 if quick else 31,
                   "poly_degree": 2 if quick else 4, "phs_order": 3},
        quick=quick, pts=points, is_bnd=boundary)
    n = solver.N_int
    linear = solver.linear_prior()
    prior = np.r_[linear[:n], linear[n:], np.zeros(2 * n)]
    row_scales = solver.residual_row_scales(prior)
    physical_scales = None
    if name == "deterministic_prior":
        start = prior
    elif name == "zero":
        start = np.zeros(4 * n)
    else:
        start, physical_scales = random_start(solver, linear, seed)
    record = solve_record(
        solver, name, seed, start, row_scales, np.asarray(branch_w), max_nfev)
    record.update({
        "load_factor": gamma, "q": gamma * BASE_LOAD,
        "row_scale_sha256": hashlib.sha256(row_scales.tobytes()).hexdigest(),
        "random_physical_scales": (list(physical_scales)
                                   if physical_scales is not None else None),
    })
    return record


def summarize(records, gammas):
    rows = []
    for gamma in gammas:
        for name in ("deterministic_prior", "zero", "smooth_random"):
            group = [r for r in records if r["load_factor"] == gamma and
                     r["initialization"] == name]
            successful = [r for r in group if r["accepted_convergence"]]
            rows.append({
                "load_factor": gamma, "initialization": name,
                "runs": len(group), "successes": len(successful),
                "success_probability": len(successful) / max(len(group), 1),
                "median_nfev_success": (float(np.median([r["nfev"] for r in successful]))
                                        if successful else None),
                "median_time_s_success": (float(np.median([r["time_s"] for r in successful]))
                                           if successful else None),
            })
    return rows


def run(output, quick=False, workers=2, resume=True):
    gammas = (0.5, 1.0) if quick else FULL_GAMMAS
    seeds = (1001, 1002, 1003) if quick else FULL_SEEDS
    max_nfev = 50 if quick else 250
    grid = 11 if quick else 21
    pts, is_bnd = PHS.square_cloud(grid)
    output.mkdir(parents=True, exist_ok=True)
    partial_path = output / "initialization_robustness.partial.json"
    records, arrays = [], {}
    if resume and partial_path.exists():
        records = json.loads(partial_path.read_text(encoding="utf-8")).get("records", [])
        print(json.dumps({"resumed_records": len(records)}), flush=True)
    continuation = None
    common_scale_hashes = {}
    for gamma in gammas:
        solver = PHS.VKRBFDSolver(
            "square", {"q0": gamma * BASE_LOAD,
                       "stencil": 19 if quick else 31,
                       "poly_degree": 2 if quick else 4, "phs_order": 3},
            quick=quick, pts=pts, is_bnd=is_bnd)
        n = solver.N_int
        linear = solver.linear_prior()
        prior = np.r_[linear[:n], linear[n:], np.zeros(2 * n)]
        row_scales = solver.residual_row_scales(prior)
        scale_hash = hashlib.sha256(row_scales.tobytes()).hexdigest()
        common_scale_hashes[str(gamma)] = scale_hash

        audit_start = prior if continuation is None else continuation
        audit, _ = solver.solve_trf(
            audit_start, max_nfev=max_nfev, xtol=1e-14,
            row_scales=row_scales, tr_solver="exact")
        continuation = audit.x
        branch_w = np.asarray(solver.E_map @ continuation[:n]).ravel()
        arrays[f"branch_w_gamma_{gamma:g}"] = branch_w

        starts = [("deterministic_prior", None), ("zero", None)]
        starts.extend(("smooth_random", seed) for seed in seeds)
        completed = {(r["initialization"], r["seed"]) for r in records
                     if r["load_factor"] == gamma}
        starts = [item for item in starts if item not in completed]
        pending = {}
        with ProcessPoolExecutor(max_workers=max(1, workers)) as pool:
            for name, seed in starts:
                future = pool.submit(solve_case_worker, gamma, name, seed,
                                     branch_w, max_nfev, quick)
                pending[future] = (name, seed)
            gamma_records = []
            for future in as_completed(pending):
                name, seed = pending[future]
                record = future.result()
                if record["row_scale_sha256"] != scale_hash:
                    raise RuntimeError("worker did not reproduce the common row scaling")
                gamma_records.append(record)
                checkpoint_records = records + gamma_records
                partial_path.write_text(
                    json.dumps({
                        "schema_version": "pipc-initialization-robustness-v1-partial",
                        "completed_load_factors": sorted({r["load_factor"]
                                                          for r in checkpoint_records}),
                        "records": checkpoint_records,
                    }, indent=2), encoding="utf-8")
                print(json.dumps({"load_factor": gamma, "initialization": name,
                                  "seed": seed, "accepted": record["accepted_convergence"],
                                  "nfev": record["nfev"]}), flush=True)
        gamma_records.sort(key=lambda item: (
            {"deterministic_prior": 0, "zero": 1, "smooth_random": 2}[item["initialization"]],
            -1 if item["seed"] is None else item["seed"]))
        records.extend(gamma_records)
        partial_path.write_text(
            json.dumps({"schema_version": "pipc-initialization-robustness-v1-partial",
                        "completed_load_factors": sorted({r["load_factor"] for r in records}),
                        "records": records}, indent=2), encoding="utf-8")

    payload = {
        "schema_version": "pipc-initialization-robustness-v1",
        "problem": "square_von_karman_plate", "base_load": BASE_LOAD,
        "load_factors": list(gammas), "random_seeds": list(seeds),
        "max_nfev": max_nfev,
        "success_criterion": {"optimizer_success": True,
                              "normalized_residual_rms_lte": 1e-8,
                              "branch_relative_l2_lte": 1e-5},
        "common_row_scale_hashes": common_scale_hashes,
        "random_initialization": "3x3 sine modes with blockwise physical RMS scales",
        "records": records, "summary": summarize(records, gammas),
    }
    (output / "initialization_robustness.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8")
    np.savez_compressed(output / "initialization_robustness_fields.npz", **arrays)
    return payload


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--no-resume", action="store_true")
    args = parser.parse_args()
    result = run(args.output, args.quick, args.workers, not args.no_resume)
    print(json.dumps(result["summary"], indent=2))


if __name__ == "__main__":
    main()
