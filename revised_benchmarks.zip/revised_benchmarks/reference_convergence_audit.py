"""Persist mesh-convergence audits and exact P2 evaluation fields for FEM references."""
from __future__ import annotations

import argparse
import importlib.util
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
LEGACY = HERE.parent / "ablation_pielm"
if str(LEGACY) not in sys.path:
    sys.path.insert(0, str(LEGACY))


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, LEGACY / filename)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


H = load("audit_heat", "nonlinear_heat_2d_mq_rbf.py")
R = load("audit_rm", "plate_rm.py")
V = load("audit_vk", "plate_vk_fem.py")


def rel(a, b):
    keep = np.isfinite(a) & np.isfinite(b)
    return float(np.linalg.norm(a[keep] - b[keep]) /
                 max(np.linalg.norm(b[keep]), 1e-30))


def points(shape, n=81):
    x = np.linspace(-1, 1, n)
    X, Y = np.meshgrid(x, x, indexing="xy")
    p = np.c_[X.ravel(), Y.ravel()]
    if shape == "star":
        p = p[R.inside_star(p)]
    return p


def heat_audit():
    out = {}
    for key in H.GEOMETRIES:
        coarse = H.solve_fem(key, "coarse", 1.0, False)
        fine = H.solve_fem(key, "fine", 1.0, False)
        co = H.interpolate_tri(coarse, fine["nodes"])
        weights = H.lumped_area_weights(fine["nodes"], fine["triangles"])
        out[key] = {"coarse": H.serializable_fem(coarse),
                    "fine": H.serializable_fem(fine),
                    "coarse_to_fine": H.field_metrics(co, fine["u"], weights)}
    return out


def linear_audit(quick=False):
    result, arrays = {}, {}
    level_map = (("square", (3, 4) if quick else (3, 4, 5)),
                 ("star", (1, 2) if quick else (2, 3, 4)))
    for shape, levels in level_map:
        eval_points = points(shape, 41 if quick else 81)
        arrays[f"linear_{shape}_eval_points"] = eval_points
        previous = None
        rows = []
        for level in levels:
            corner, cells, U, p2 = R.fem_solve(shape, level, h=.05)
            field = R.fem_field(p2, cells, U, eval_points, corner, fill_value=np.nan)
            boundary = R.p2_topological_boundary_nodes(cells[:, :3], cells)
            rows.append({
                "level": level, "p2_nodes": len(p2), "p2_cells": len(cells),
                "boundary_nodes": len(boundary),
                "w_max": float(np.nanmax(np.abs(field))),
                "relative_change_from_previous": None if previous is None else rel(previous, field),
                "evaluation": "elementwise P2 barycentric interpolation",
            })
            arrays[f"linear_{shape}_level_{level}"] = field
            previous = field
        result[shape] = rows
    return result, arrays


def nonlinear_audit(quick=False):
    result, arrays = {}, {}
    level_map = (("square", (2, 3) if quick else (2, 3, 4, 5)),
                 ("star", (1,) if quick else (1, 2, 3, 4)))
    for shape, levels in level_map:
        eval_points = points(shape, 41 if quick else 81)
        arrays[f"nonlinear_{shape}_eval_points"] = eval_points
        previous = None
        rows = []
        for level in levels:
            fem = V.vk_fem(shape, level, max_iter=40, tol=1e-11)
            # The legacy FEM routine uses the opposite transverse-load sign
            # convention from the active RBF-FD plate equations.
            field = R.fem_field(fem["pts"], fem["cells"], -fem["w"], eval_points,
                                fem["corner_pts"], fill_value=np.nan)
            rows.append({
                "level": level, "nodes": len(fem["pts"]), "p2_cells": len(fem["cells"]),
                "boundary_nodes": len(fem["boundary_nodes"]),
                "w_max": float(np.nanmax(np.abs(field))),
                "relative_change_from_previous": None if previous is None else rel(previous, field),
                "newton_iterations": int(fem["iters"]),
                "newton_residual_l2": float(fem["residual"]),
                "evaluation": "elementwise P2 barycentric interpolation",
            })
            arrays[f"nonlinear_{shape}_level_{level}"] = field
            previous = field
        result[shape] = rows
    return result, arrays


def extend_nonlinear_square(output_path):
    """Append level 6 without recomputing the already persisted FEM hierarchy."""
    if not output_path.exists():
        raise FileNotFoundError("run the full reference audit before --extend-square")
    npz_path = output_path.with_name("reference_convergence_fields.npz")
    payload = json.loads(output_path.read_text(encoding="utf-8"))
    stored = np.load(npz_path)
    arrays = {key: stored[key] for key in stored.files}
    eval_points = arrays["nonlinear_square_eval_points"]
    previous = arrays["nonlinear_square_level_5"]
    fem = V.vk_fem("square", 6, max_iter=40, tol=1e-11)
    field = R.fem_field(fem["pts"], fem["cells"], -fem["w"], eval_points,
                        fem["corner_pts"], fill_value=np.nan)
    row = {
        "level": 6, "nodes": len(fem["pts"]), "p2_cells": len(fem["cells"]),
        "boundary_nodes": len(fem["boundary_nodes"]),
        "w_max": float(np.nanmax(np.abs(field))),
        "relative_change_from_previous": rel(previous, field),
        "newton_iterations": int(fem["iters"]),
        "newton_residual_l2": float(fem["residual"]),
        "evaluation": "elementwise P2 barycentric interpolation",
    }
    rows = [item for item in payload["nonlinear_von_karman"]["square"]
            if item["level"] != 6]
    rows.append(row)
    payload["nonlinear_von_karman"]["square"] = sorted(rows, key=lambda item: item["level"])
    arrays["nonlinear_square_level_6"] = field
    output_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    np.savez_compressed(npz_path, **arrays)
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--plate-only", action="store_true")
    parser.add_argument("--extend-square", action="store_true",
                        help="append nonlinear square level 6 to an existing full audit")
    parser.add_argument("--output", type=Path,
                        default=HERE / "results" / "reference_convergence_audit.json")
    args = parser.parse_args()
    if args.extend_square:
        print(json.dumps(extend_nonlinear_square(args.output), indent=2))
        return
    existing = {}
    if args.plate_only and args.output.exists():
        existing = json.loads(args.output.read_text(encoding="utf-8"))
    linear, linear_arrays = linear_audit(args.quick)
    nonlinear, nonlinear_arrays = nonlinear_audit(args.quick)
    output = {
        "schema_version": "pipc-reference-audit-v2",
        "acceptance_relative_change": 0.005,
        "ideal_relative_change": 0.002,
        "heat": existing.get("heat") if args.plate_only else heat_audit(),
        "linear_reissner_mindlin": linear,
        "nonlinear_von_karman": nonlinear,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2), encoding="utf-8")
    npz_path = args.output.with_name("reference_convergence_fields.npz")
    np.savez_compressed(npz_path, **linear_arrays, **nonlinear_arrays)
    print(json.dumps({"json": str(args.output), "fields": str(npz_path),
                      "nonlinear": nonlinear}, indent=2))


if __name__ == "__main__":
    main()
