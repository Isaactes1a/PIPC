"""Reproduce the plate-contradiction diagnostics reported in Section 3.4.

Two questions are quantified here:
  1. why the single-shot Gaussian PIELM returns an essentially zero deflection
     on the linear Reissner--Mindlin plate (load shadowing / near-singular
     deflection branch of the three-field strong form), and
  2. why PIPC and CL-PIELM order differently on the nonlinear von Karman star
     (genuine nodal discretization error for PIPC vs a smoother interior
     representation for CL-PIELM).
The audit writes a versioned JSON with the same numbers cited in the paper and
does not modify any benchmark result.
"""

from __future__ import annotations

import importlib.util
import json
import sys
import time
from pathlib import Path

import numpy as np
from scipy.interpolate import griddata
from scipy.spatial import Delaunay

import phs_rbf_fd as PHS

HERE = Path(__file__).resolve().parent
LEGACY = HERE.parent / "ablation_pielm"
if str(LEGACY) not in sys.path:
    sys.path.insert(0, str(LEGACY))


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, filename)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def rel_l2(pred, ref, keep=None):
    if keep is None:
        keep = np.isfinite(pred) & np.isfinite(ref)
    return float(np.linalg.norm(pred[keep] - ref[keep]) / max(np.linalg.norm(ref[keep]), 1e-30))


def linear_pielm_diagnostics(shape, cfg, spacing_star=None, sigma_factor=1.0):
    """Load-row magnitude, singular-value ratio, and solution deflection."""
    lpm = load("audited_linear_pielm", HERE / "plate_linear_three_method.py")
    if shape == "square":
        pts, is_bnd = PHS.square_cloud(21)
    else:
        pts, is_bnd = PHS.star_cloud(200, spacing_star)
    solver = PHS.RBFDPlateSolver(shape, cfg, quick=False, pts=pts, is_bnd=is_bnd)
    sigma = sigma_factor * lpm.spacing(solver.pts)
    A, rhs = lpm.assemble_pielm(solver, sigma)
    scale = np.linalg.norm(A, axis=1)
    scale[scale == 0] = 1.0
    As, bs = A / scale[:, None], rhs / scale
    coeff, _, _, _ = lpm.normalized_lstsq(A, rhs)
    P, *_ = lpm.gaussian_ops(solver.pts, solver.pts, sigma)
    w_nodes = P @ coeff[: len(solver.pts)]
    s = np.linalg.svd(As, compute_uv=False)
    ni = len(solver.idx_int)
    load_rows = slice(2 * ni, 3 * ni)
    return {
        "domain": shape,
        "sigma_over_h": sigma_factor,
        "condition_number": float(s[0] / s[-1]),
        "sigma_ratio_min_over_max": float(s[-1] / s[0]),
        "load_row_norm_median": float(np.median(scale[load_rows])),
        "normalized_load_relative": float(np.max(np.abs(rhs[load_rows]) / scale[load_rows])),
        "normalized_residual_rms": float(np.sqrt(np.mean((As @ coeff - bs) ** 2))),
        "max_abs_w_at_nodes": float(np.max(np.abs(w_nodes))),
        "n_nodes": int(solver.N),
    }


def vk_star_diagnostics():
    """Nodal vs evaluation error, near/far split, and CL-PIELM comparison."""
    ptm = load("audited_vk_benchmark", HERE / "plate_three_method.py")
    FEM = load("audited_plate_fem", LEGACY / "plate_vk_fem.py")
    vkf = np.load(HERE / "results" / "plate_full" / "plate_fields.npz")

    x = np.linspace(-1, 1, 81)
    X, Y = np.meshgrid(x, x, indexing="xy")
    all_pts = np.column_stack([X.ravel(), Y.ravel()])
    r = np.hypot(all_pts[:, 0], all_pts[:, 1])
    th = np.arctan2(all_pts[:, 1], all_pts[:, 0])
    epts = all_pts[r <= 1 + 0.3 * np.sin(5 * th) + 1e-12]

    fem = dict(FEM.vk_fem("star", 3, max_iter=40, tol=1e-11))
    fem["w"] = -np.asarray(fem["w"])
    pts, is_bnd = PHS.star_cloud(200, 0.06)
    cfg = {"stencil": 31, "poly_degree": 4, "phs_order": 3}
    rec, solver, alpha, pred, ref, keep = PHS.solve_vk_pipc(
        "star", cfg, fem, epts, False, pts=pts, is_bnd=is_bnd)
    w_nodes = solver.E_map @ alpha[: solver.N_int]
    fem_at_nodes = griddata(fem["pts"], fem["w"], solver.pts, method="linear")
    ok = np.isfinite(fem_at_nodes)
    ref_e = griddata(fem["pts"], fem["w"], epts, method="linear")
    p_grid = griddata(solver.pts, w_nodes, epts, method="linear")
    p_phs = PHS.interpolate_points(
        solver.pts, w_nodes, epts, solver.stencil, solver.poly_degree,
        solver.phs_order, inside=PHS.inside_star)
    cl = vkf["star_cl_pielm"]
    dist_bnd = np.min(np.linalg.norm(
        epts[:, None, :] - PHS.dense_boundary("star", 800)[None, :, :], axis=2), axis=1)
    near = dist_bnd < 0.04
    far = ~near
    keep_all = np.isfinite(ref_e) & np.isfinite(p_grid)
    out = {
        "reported_relative_l2": rec.relative_l2,
        "nodal_relative_l2": rel_l2(w_nodes[ok], fem_at_nodes[ok]),
        "griddata_relative_l2": rel_l2(p_grid, ref_e),
        "phs_relative_l2": rel_l2(p_phs, ref_e),
        "cl_pielm_relative_l2": rel_l2(cl, ref_e),
        "griddata_near_boundary_relative_l2": rel_l2(p_grid, ref_e, near & keep_all),
        "griddata_interior_relative_l2": rel_l2(p_grid, ref_e, far & keep_all),
        "phs_near_boundary_relative_l2": rel_l2(p_phs, ref_e, near & np.isfinite(p_phs) & np.isfinite(ref_e)),
        "phs_interior_relative_l2": rel_l2(p_phs, ref_e, far & np.isfinite(p_phs) & np.isfinite(ref_e)),
        "cl_near_boundary_relative_l2": rel_l2(cl, ref_e, near & np.isfinite(cl) & np.isfinite(ref_e)),
        "cl_interior_relative_l2": rel_l2(cl, ref_e, far & np.isfinite(cl) & np.isfinite(ref_e)),
        "newton_relative_l2": rec.details["same_discretization_newton_relative_l2"],
        "n_nodes": int(solver.N),
        "n_int": int(solver.N_int),
    }
    tri = Delaunay(solver.pts)
    tri_idx = tri.find_simplex(epts)
    valid = tri_idx >= 0
    cx = tri.points[tri.simplices[tri_idx[valid]]][:, :, 0].mean(axis=1)
    cy = tri.points[tri.simplices[tri_idx[valid]]][:, :, 1].mean(axis=1)
    rr = np.hypot(cx, cy)
    tt = np.arctan2(cy, cx)
    masked = np.zeros(len(epts), bool)
    masked[valid] = rr <= 1 + 0.3 * np.sin(5 * tt) + 1e-10
    out["masked_eval_fraction"] = float(masked.sum() / len(epts))
    out["griddata_masked_relative_l2"] = rel_l2(p_grid, ref_e, masked)
    return out


def consistent_format_summary():
    """Extract the format-consistent plate results from the persisted records."""
    lin = json.loads((HERE / "results" / "plate_linear_full_rerun"
                      / "plate_linear_results.json").read_text(encoding="utf-8"))
    vk = json.loads((HERE / "results" / "plate_full" / "plate_results.json").read_text(encoding="utf-8"))

    def digest(records):
        out = {}
        for r in records:
            key = (r["domain"], r["method"])
            out.setdefault(key, []).append(r)
        return {f"{dom}_{m}": {
            "relative_l2": float(np.mean([x["relative_l2"] for x in rr])),
            "audit_residual_rms": float(np.mean([x["audit_residual_rms"] for x in rr])),
            "end_to_end_time_s": float(np.mean([x["end_to_end_time_s"] for x in rr])),
            "form": rr[0]["details"].get("form", "n/a"),
        } for (dom, m), rr in sorted(out.items())}

    return {"linear_plate": digest(lin["records"]), "vk_plate": digest(vk["records"])}


def main():
    audit = {
        "schema_version": "pipc-plate-contradiction-audit-v2",
        "linear_pielm": [
            linear_pielm_diagnostics("square", {"stencil": 31, "poly_degree": 3, "phs_order": 3},
                                     sigma_factor=0.75),
            linear_pielm_diagnostics("star", {"stencil": 31, "poly_degree": 2, "phs_order": 3},
                                     spacing_star=0.045, sigma_factor=1.0),
        ],
        "vk_star": vk_star_diagnostics(),
        "consistent_format_plates": consistent_format_summary(),
    }
    out = HERE / "results" / "plate_contradiction_audit.json"
    out.write_text(json.dumps(audit, indent=2), encoding="utf-8")
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
