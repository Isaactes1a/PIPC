"""Validate revised records, derivative checks, terminology, and manuscript assets."""

from __future__ import annotations
import argparse,json,math,re
from pathlib import Path
import numpy as np
from common import REQUIRED_FIELDS,SEEDS,validate_record
import phs_rbf_fd

FORBIDDEN=("PNI","PIPC-CPI","PIPC-PNI","Burgers","anchor loss","field-space inheritance")


def fd_weights(nodes,order):
    # sum_j w_j f(jh) approximates the requested derivative in unit spacing.
    A=np.vstack([nodes**k for k in range(len(nodes))]);b=np.zeros(len(nodes));b[order]=math.factorial(order)
    return np.linalg.solve(A,b)


def derivative_check():
    z,c=.37,.61;r=math.sqrt(z*z+c*c)
    exact=(z/r,c*c/r**3,-3*c*c*z/r**5,3*c*c*(4*z*z-c*c)/r**7);errors={}
    nodes=np.arange(-5,6,dtype=float)
    for order,target in enumerate(exact,1):
        h=3e-2
        vals=np.sqrt((z+nodes*h)**2+c*c);approx=float(fd_weights(nodes,order)@vals/h**order)
        errors[f"mq_d{order}"]=abs(approx-target)/max(abs(target),1e-30)
    rng=np.random.default_rng(42);L=rng.normal(size=(11,7));G=rng.normal(size=(11,7));a=rng.normal(size=7);v=rng.normal(size=7);beta=.8
    def res(x):return L@x+beta*(G@x)**2
    J=L+2*beta*(G@a)[:,None]*G;eps=1e-6;fd=(res(a+eps*v)-res(a-eps*v))/(2*eps)
    errors["cl_quasilinear_directional"]=float(np.linalg.norm(fd-J@v)/np.linalg.norm(J@v))
    B=rng.normal(size=(5,7));fd=(B@(a+eps*v)-B@(a-eps*v))/(2*eps)
    errors["boundary_row_directional"]=float(np.linalg.norm(fd-B@v)/np.linalg.norm(B@v))
    return errors


def phs_operator_check():
    """PHS-RBF-FD operators must reproduce polynomials up to the augmentation
    degree exactly on a node cloud, and the assembled matrices must stay
    well conditioned."""
    rng = np.random.default_rng(7)
    pts = np.column_stack([rng.uniform(-1, 1, 250), rng.uniform(-1, 1, 250)])
    ops = phs_rbf_fd.build_operators_2d(pts, stencil_size=31, poly_degree=4,
                                        phs_power=3, second=True)
    x, y = pts[:, 0], pts[:, 1]
    checks = {
        "Dx[x]=1": (ops["Dx"] @ x, 1.0), "Dx[y]=0": (ops["Dx"] @ y, 0.0),
        "Dy[y]=1": (ops["Dy"] @ y, 1.0), "Dxx[x^2]=2": (ops["Dxx"] @ (x * x), 2.0),
        "Dyy[y^2]=2": (ops["Dyy"] @ (y * y), 2.0),
        "Dxy[xy]=1": (ops["Dxy"] @ (x * y), 1.0),
        "Lap[x^2+y^2]=4": ((ops["Dxx"] + ops["Dyy"]) @ (x * x + y * y), 4.0),
    }
    errors = {}
    for name, (got, want) in checks.items():
        err = float(np.max(np.abs(got - want)))
        errors[name] = err
        if err >= 1e-6:
            raise AssertionError(f"{name} reproduction failed: {err}")
    return errors


def condition_check(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    bad = []
    for r in data["records"]:
        if r["method"] != "PIPC":
            continue
        cond = r.get("details", {}).get("condition_number")
        if cond is not None and math.isfinite(float(cond)) and float(cond) >= 1e10:
            bad.append((r["method"], r["problem"], r["domain"], cond))
    if bad:
        raise AssertionError(f"PIPC condition number above 1e10: {bad}")
    return bad


def validate_json(path):
    data=json.loads(path.read_text(encoding="utf-8"));assert data["schema_version"]=="pipc-revised-benchmark-v1"
    for r in data["records"]:validate_record(r)
    for r in data["records"]:
        err=r.get("details",{}).get("jacobian_directional_error")
        if err is not None:
            assert float(err)<1e-6,(path,r["problem"],r["domain"],err)
    groups={(r["problem"],r["domain"]) for r in data["records"] if r["method"]=="PINN"}
    for g in groups:
        got={r["seed"] for r in data["records"] if r["method"]=="PINN" and (r["problem"],r["domain"])==g}
        assert got==set(SEEDS),(path,g,got)
    for r in data["records"]:
        if r["method"]=="PIPC" and r["constraint_bc_linf"] is not None:
            assert r["constraint_bc_linf"]<1e-10,(path,r["domain"],r["constraint_bc_linf"])
    condition_check(path)
    return len(data["records"])


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--root",type=Path,required=True);p.add_argument("--json",type=Path,nargs="+",required=True);p.add_argument("--report",type=Path,required=True);a=p.parse_args();counts={str(x):validate_json(x) for x in a.json};errs=derivative_check();phs_errs=phs_operator_check()
    if max(errs.values())>=1e-6:raise AssertionError(errs)
    active=[a.root/"PIPC_LaTeX_Package"/"main.tex"]+list((a.root/"PIPC_LaTeX_Package"/"generated_tables").glob("*.tex"))
    hits={}
    for path in active:
        text=path.read_text(encoding="utf-8",errors="replace")
        for term in FORBIDDEN:
            if term.lower() in text.lower():hits.setdefault(term,[]).append(str(path))
    if hits:raise AssertionError({"forbidden_terms":hits})
    required=[f"fig{i:02d}" for i in range(1,9)]
    figs=list((a.root/"PIPC_LaTeX_Package"/"figures").glob("*.pdf"));missing=[x for x in required if not any(f.name.startswith(x) for f in figs)]
    if missing:raise AssertionError({"missing_figures":missing})
    report={"status":"passed","json_record_counts":counts,"directional_checks":errs,
            "phs_operator_checks":phs_errs,"forbidden_terms":hits,"figure_count":len(figs)}
    a.report.parent.mkdir(parents=True,exist_ok=True);a.report.write_text(json.dumps(report,indent=2),encoding="utf-8");print(json.dumps(report,indent=2))


if __name__=="__main__":main()
