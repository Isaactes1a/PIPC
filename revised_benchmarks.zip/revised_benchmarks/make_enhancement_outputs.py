"""Generate the robustness/convergence figures and LaTeX tables from JSON only."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from plot_style import configure_publication_style, inward_ticks

HERE = Path(__file__).resolve().parent

configure_publication_style()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save_figure(fig, output, stem):
    output.mkdir(parents=True, exist_ok=True)
    for ax in fig.axes:
        inward_ticks(ax)
    fig.savefig(output / f"{stem}.pdf", bbox_inches="tight")
    fig.savefig(output / f"{stem}.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


def robustness_figure(payload, output):
    records = payload["records"]
    gammas = np.asarray(payload["load_factors"], dtype=float)
    styles = {"deterministic_prior": ("o", "tab:blue", "deterministic prior"),
              "zero": ("s", "tab:orange", "zero"),
              "smooth_random": ("^", "tab:green", "smooth random")}
    fig, axes = plt.subplots(1, 3, figsize=(11.2, 3.4), constrained_layout=True)
    for name, (marker, color, label) in styles.items():
        probability = []
        for gamma in gammas:
            group = [r for r in records if r["initialization"] == name and
                     r["load_factor"] == gamma]
            probability.append(np.mean([r["accepted_convergence"] for r in group]))
        axes[0].plot(gammas, probability, marker=marker, color=color, label=label)
    axes[0].set_ylim(-0.04, 1.04)
    axes[0].set_ylabel("Accepted fraction")
    axes[0].legend(fontsize=7)

    positions = np.arange(len(gammas))
    for ax, key, ylabel in ((axes[1], "nfev", "residual/Jacobian evaluations"),
                            (axes[2], "time_s", "wall time per run (s)")):
        random_values = [[r[key] for r in records
                          if r["initialization"] == "smooth_random" and
                          r["load_factor"] == gamma] for gamma in gammas]
        ax.boxplot(random_values, positions=positions, widths=.52, showfliers=False,
                   patch_artist=True,
                   boxprops={"facecolor": "#9bd59b", "alpha": .65},
                   medianprops={"color": "black"})
        for name, (marker, color, label) in list(styles.items())[:2]:
            values = [next(r[key] for r in records if r["initialization"] == name and
                           r["load_factor"] == gamma) for gamma in gammas]
            ax.plot(positions, values, marker=marker, color=color,
                    label=label)
        ax.set_ylabel(ylabel)
        ax.set_xticks(positions, [f"{g:g}" for g in gammas])
        ax.grid(alpha=.2, axis="y")
    for ax in axes:
        ax.set_xlabel(r"load factor $\gamma_q$")
    axes[1].legend(fontsize=7)
    save_figure(fig, output, "fig09_initialization_robustness")


def convergence_figure(payload, output):
    fig, axes = plt.subplots(1, 2, figsize=(8.2, 3.5), constrained_layout=True)
    for problem, label, color, marker in (
            ("reissner_mindlin", "Reissner--Mindlin", "tab:blue", "o"),
            ("von_karman", "von K\u00e1rm\u00e1n", "tab:red", "s")):
        rows = sorted([r for r in payload["records"] if r["problem"] == problem],
                      key=lambda r: r["fill_distance"], reverse=True)
        h = np.asarray([r["fill_distance"] for r in rows])
        error = np.asarray([r["relative_l2"] for r in rows])
        cond = np.asarray([r["local_condition_stats"]["maximum"] for r in rows])
        axes[0].loglog(h, error, marker=marker, color=color, label=label)
        axes[1].loglog(h, cond, marker=marker, color=color, label=label)
        for ax, values in ((axes[0], error), (axes[1], cond)):
            for x, y, row in zip(h, values, rows):
                ax.annotate(str(row["n_nodes"]), (x, y), xytext=(4, 4),
                            textcoords="offset points", fontsize=6)
    axes[0].set_ylabel(r"relative $L_2$ field error")
    axes[1].set_ylabel("maximum local stencil condition number")
    for ax in axes:
        ax.set_xlabel("measured fill distance")
        ax.grid(alpha=.2, which="both")
        ax.invert_xaxis()
    axes[0].legend(fontsize=8)
    save_figure(fig, output, "fig10_rbffd_convergence")


def robustness_table(payload, output):
    lines = [r"\begin{table}[H]", r"\centering", r"\small",
             r"\caption{Initialization robustness on the square von K\'arm\'an plate. Random entries report accepted runs out of 20; the median nfev is computed over accepted random runs only.}",
             r"\label{tab:initialization-robustness}",
             r"\begin{tabular}{rrrrr}", r"\toprule",
             r"$\gamma_q$ & prior nfev & zero nfev & random success & random median nfev \\",
             r"\midrule"]
    summary = payload["summary"]
    for gamma in payload["load_factors"]:
        item = {r["initialization"]: r for r in summary if r["load_factor"] == gamma}
        random = item["smooth_random"]
        median = "--" if random["median_nfev_success"] is None else f'{random["median_nfev_success"]:.0f}'
        lines.append(f'{gamma:g} & {item["deterministic_prior"]["median_nfev_success"]:.0f} & '
                     f'{item["zero"]["median_nfev_success"]:.0f} & '
                     f'{random["successes"]}/20 & {median} \\\\')
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (output / "plate_robustness_table.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")


def sci(value) -> str:
    """Format a number as LaTeX scientific notation with a power of ten."""
    mantissa, exponent = f"{float(value):.3e}".split("e")
    mantissa = mantissa.rstrip("0").rstrip(".")
    return rf"${mantissa}\times10^{{{int(exponent)}}}$"


def convergence_table(payload, output):
    lines = [r"\begin{table}[H]", r"\centering", r"\small",
             r"\caption{Star-domain RBF-FD refinement study. The condition statistic is the maximum condition number of the scaled local augmented stencil systems.}",
             r"\label{tab:rbffd-convergence}",
             r"\begin{adjustbox}{max width=\linewidth}",
             r"\begin{tabular}{llrrrrrr}", r"\toprule",
             r"Problem & $N$ & fill distance & $e_{L_2}$ & residual RMS & boundary error & $\kappa_{\max}$ & time (s) \\",
             r"\midrule"]
    for problem in ("reissner_mindlin", "von_karman"):
        label = "RM" if problem == "reissner_mindlin" else "vK"
        rows = sorted([r for r in payload["records"] if r["problem"] == problem],
                      key=lambda r: r["fill_distance"], reverse=True)
        for row in rows:
            lines.append(f'{label} & {row["n_nodes"]} & {sci(row["fill_distance"])} & '
                         f'{sci(row["relative_l2"])} & {sci(row["residual_rms"])} & '
                         f'{sci(row["dense_boundary_linf"])} & '
                         f'{sci(row["local_condition_stats"]["maximum"])} & '
                         f'{row["time_s"]:.1f} \\\\')
        if problem == "reissner_mindlin":
            lines.append(r"\addlinespace")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{adjustbox}", r"\end{table}"]
    (output / "rbffd_convergence_table.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--robustness", type=Path,
                        default=HERE / "results" / "initialization_robustness" / "initialization_robustness.json")
    parser.add_argument("--convergence", type=Path,
                        default=HERE / "results" / "rbffd_convergence" / "rbffd_convergence.json")
    parser.add_argument("--figures", type=Path,
                        default=HERE.parent.parent / "PIPC_LaTeX_Package" / "figures")
    parser.add_argument("--tables", type=Path,
                        default=HERE.parent.parent / "PIPC_LaTeX_Package" / "generated_tables")
    args = parser.parse_args()
    robustness, convergence = read(args.robustness), read(args.convergence)
    args.tables.mkdir(parents=True, exist_ok=True)
    robustness_figure(robustness, args.figures)
    convergence_figure(convergence, args.figures)
    robustness_table(robustness, args.tables)
    convergence_table(convergence, args.tables)


if __name__ == "__main__":
    main()
