"""Tests for manuscript-wide styling and field/error colorbar invariants."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from plot_style import (  # noqa: E402
    absolute_error,
    add_three_tick_colorbar,
    configure_publication_style,
    scientific_exponent,
    shared_limits,
)


class FigureStyleTests(unittest.TestCase):
    def test_absolute_error_and_invalid_mask(self):
        reference = np.array([1.0, -2.0, np.nan])
        values = np.array([0.5, -3.0, 4.0])
        error = absolute_error(values, reference)
        np.testing.assert_allclose(error[:2], [0.5, 1.0])
        self.assertTrue(np.isnan(error[2]))

    def test_shared_solution_and_error_limits(self):
        fields = [np.array([-2.0, 1.0]), np.array([0.0, 3.0]), np.array([1.0, 2.0])]
        errors = [np.array([0.1, 0.3]), np.array([0.0, 0.8])]
        self.assertEqual(shared_limits(fields), (-2.0, 3.0))
        self.assertEqual(shared_limits(errors, zero_min=True), (0.0, 0.8))

    def test_three_ticks_and_scientific_multiplier(self):
        fig, ax = plt.subplots()
        image = ax.imshow([[0.0, 1e-3], [2e-3, 3e-3]], vmin=0.0, vmax=3e-3)
        cax = fig.add_axes([0.88, 0.1, 0.03, 0.8])
        colorbar = add_three_tick_colorbar(fig, image, cax, 0.0, 3e-3)
        self.assertEqual(len(colorbar.get_ticks()), 3)
        self.assertEqual(scientific_exponent(0.0, 3e-3), -3)
        self.assertIn(r"10^{-3}", colorbar.ax.get_title())
        plt.close(fig)

    def test_times_new_roman_and_inward_defaults(self):
        configure_publication_style()
        font_path = font_manager.findfont("Times New Roman", fallback_to_default=False)
        self.assertTrue(Path(font_path).exists())
        self.assertEqual(matplotlib.rcParams["font.family"], ["Times New Roman"])
        self.assertEqual(matplotlib.rcParams["xtick.direction"], "in")
        self.assertEqual(matplotlib.rcParams["ytick.direction"], "in")
        self.assertEqual(matplotlib.rcParams["mathtext.fontset"], "stix")


if __name__ == "__main__":
    unittest.main()
