"""RBF-FD h-refinement study for star RM and von Karman plates."""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
from scipy.spatial import cKDTree

import phs_rbf_fd as PHS

HERE = Path(__file__).resolve().parent
DEFAULT_REFERENCE = HERE / "results" / "reference_convergence_fields.npz"
DEFAULT_OUTPUT = HERE / "results" / "rbffd_convergence"
FULL_LEVELS = ((0.09, 133), (0.065, 185), (0.046, 261), (0.033, 364))


def dense_star_boundary(n=600):
    theta = np.linspace(0, 2 * np.pi, n, endpoint=False)
    radius = 1 + 0.3 * np.sin(5 * theta)
    return np.c_[radius * np.cos(theta), radius * np.sin(theta)]


def metrics(pred, ref):
    keep = np.isfinite(pred) & np.isfinite(ref)
    p, r = np.asarray(pred)[keep], np.asarray(ref)[keep]
    error = p - r
    return ({"relative_l2": float(np.linalg.norm(error) /
                                  max(np.linalg.norm(r), 1e-30)),
             "mse": float(np.mean(error * error)),
             "linf": float(np.max(np.abs(error)))}, keep)


def fill_distance(nodes, evaluation_points):
    distances = cKDTree(nodes).query(evaluation_points, k=1)[0]
    return float(np.max(distances)), float(np.median(distances))


def load_reference(path, problem):
    data = np.load(path)
    prefix = "linear_star" if problem == "rm" else "nonlinear_star"
    points = data[f"{prefix}_eval_points"]
    candidates = sorted(
        (int(key.rsplit("_", 1)[1]), key) for key in data.files
        if key.startswith(prefix + "_level_"))
    if not candidates:
        raise ValueError(f"no {prefix} reference levels in {path}")
    level, key = candidates[-1]
    field = data[key]
    keep = np.isfinite(field)
    return points[keep], field[keep], level


def solve_rm(spacing, n_boundary, eval_points, reference, quick=False):
    started = time.perf_counter()
    pts, is_bnd = PHS.star_cloud(n_boundary, spacing)
    solver = PHS.RBFDPlateSolver(
        "star", {"E": 1e5, "nu": 0.3, "h": 0.05, "q0": 0.005,
                 "stencil": 31, "poly_degree": 2, "phs_order": 3,
                 "second_operators": False},
        quick=quick, pts=pts, is_bnd=is_bnd)
    record, nodes_w, pred = PHS.solve_linear_rm_pipc(
        solver, eval_points, reference, quick, dense_star_boundary())
    hmax, hmedian = fill_distance(pts, eval_points)
    return {
        "problem": "reissner_mindlin", "nominal_spacing": spacing,
        "n_nodes": int(solver.N), "n_boundary": int(len(solver.idx_bnd)),
        "n_interior": int(solver.N_int), "fill_distance": hmax,
        "median_nearest_distance": hmedian, "relative_l2": record.relative_l2,
        "residual_rms": record.audit_residual_rms,
        "normalized_residual_rms": record.details["normalized_residual_rms"],
        "dense_boundary_linf": record.dense_boundary_linf,
        "w_max": float(np.max(np.abs(pred))),
        "time_s": float(time.perf_counter() - started),
        "stencil": 31, "poly_degree": 2, "phs_order": 3,
        "local_condition_stats": solver.local_condition_stats,
    }, pred


def solve_vk(spacing, n_boundary, eval_points, reference, quick=False):
    started = time.perf_counter()
    pts, is_bnd = PHS.star_cloud(n_boundary, spacing)
    solver = PHS.VKRBFDSolver(
        "star", {"q0": 0.005, "stencil": 31, "poly_degree": 4, "phs_order": 3},
        quick=quick, pts=pts, is_bnd=is_bnd)
    n = solver.N_int
    linear = solver.linear_prior()
    prior = np.r_[linear[:n], linear[n:], np.zeros(2 * n)]
    row_scales = solver.residual_row_scales(prior)
    solution, solve_time, iterations = solver.solve_newton(
        prior, max_iter=20 if quick else 50, tol=1e-10)
    nodes_w = np.asarray(solver.E_map @ solution[:n]).ravel()
    pred = PHS.interpolate_points(
        pts, nodes_w, eval_points, 31, 4, 3, inside=PHS.inside_star)
    error_metrics, _ = metrics(pred, reference)
    residual = solver.residual_and_jac(solution)[0]
    boundary = PHS.interpolate_points(
        pts, nodes_w, dense_star_boundary(), 31, 4, 3, inside=PHS.inside_star)
    hmax, hmedian = fill_distance(pts, eval_points)
    return {
        "problem": "von_karman", "nominal_spacing": spacing,
        "n_nodes": int(solver.N), "n_boundary": int(len(solver.idx_bnd)),
        "n_interior": int(solver.N_int), "fill_distance": hmax,
        "median_nearest_distance": hmedian, **error_metrics,
        "residual_rms": float(np.sqrt(np.mean(residual * residual))),
        "normalized_residual_rms": float(np.sqrt(np.mean((residual / row_scales) ** 2))),
        "dense_boundary_linf": float(np.max(np.abs(boundary))),
        "w_max": float(np.max(np.abs(pred))),
        "time_s": float(time.perf_counter() - started), "solve_time_s": float(solve_time),
        "solver": "sparse damped Newton", "optimizer_success": bool(
            np.sqrt(np.mean((residual / row_scales) ** 2)) <= 1e-8),
        "nfev": int(iterations),
        "stencil": 31, "poly_degree": 4, "phs_order": 3,
        "local_condition_stats": solver.local_condition_stats,
    }, pred


def dense_sparse_audit(quick=False):
    spacing, n_boundary = ((0.14, 80) if quick else (0.065, 185))
    pts, is_bnd = PHS.star_cloud(n_boundary, spacing)
    solver = PHS.VKRBFDSolver(
        "star", {"q0": 0.005, "stencil": 19 if quick else 31,
                 "poly_degree": 2 if quick else 4, "phs_order": 3},
        quick=quick, pts=pts, is_bnd=is_bnd)
    n = solver.N_int
    linear = solver.linear_prior()
    prior = np.r_[linear[:n], linear[n:], np.zeros(2 * n)]
    scales = solver.residual_row_scales(prior)
    dense, _ = solver.solve_trf(prior, max_nfev=100, xtol=1e-12,
                                row_scales=scales, tr_solver="exact")
    sparse, _ = solver.solve_trf(prior, max_nfev=100, xtol=1e-12,
                                 row_scales=scales, tr_solver="lsmr")
    newton, _, newton_iterations = solver.solve_newton(
        prior, max_iter=20 if quick else 50, tol=1e-10)
    wd = np.asarray(solver.E_map @ dense.x[:n]).ravel()
    ws = np.asarray(solver.E_map @ sparse.x[:n]).ravel()
    wn = np.asarray(solver.E_map @ newton[:n]).ravel()
    return {"n_nodes": int(solver.N), "dense_success": bool(dense.success),
            "sparse_success": bool(sparse.success),
            "lsmr_field_relative_l2": float(np.linalg.norm(wd - ws) /
                                            max(np.linalg.norm(wd), 1e-30)),
            "newton_iterations": int(newton_iterations),
            "newton_field_relative_l2": float(np.linalg.norm(wd - wn) /
                                               max(np.linalg.norm(wd), 1e-30)),
            "selected_sparse_path": "damped_newton"}


def run(reference_path, output, quick=False, resume=True):
    levels = ((0.14, 80), (0.09, 120)) if quick else FULL_LEVELS
    rm_points, rm_reference, rm_level = load_reference(reference_path, "rm")
    vk_points, vk_reference, vk_level = load_reference(reference_path, "vk")
    output.mkdir(parents=True, exist_ok=True)
    partial_json = output / "rbffd_convergence.partial.json"
    partial_npz = output / "rbffd_convergence.partial.npz"
    records, arrays = [], {"rm_eval_points": rm_points, "rm_reference": rm_reference,
                           "vk_eval_points": vk_points, "vk_reference": vk_reference}
    if resume and partial_json.exists() and partial_npz.exists():
        records = json.loads(partial_json.read_text(encoding="utf-8")).get("records", [])
        stored = np.load(partial_npz)
        arrays.update({key: stored[key] for key in stored.files})
        print(json.dumps({"resumed_records": len(records)}), flush=True)

    def checkpoint():
        partial_json.write_text(json.dumps({
            "schema_version": "pipc-rbffd-convergence-v1-partial",
            "records": records}, indent=2), encoding="utf-8")
        np.savez_compressed(partial_npz, **arrays)

    for spacing, n_boundary in levels:
        if not any(r["problem"] == "reissner_mindlin" and
                   r["nominal_spacing"] == spacing for r in records):
            rm, rm_field = solve_rm(spacing, n_boundary, rm_points, rm_reference, quick)
            records.append(rm)
            arrays[f"rm_spacing_{spacing:g}"] = rm_field
            checkpoint()
            print(json.dumps({"completed": "reissner_mindlin", "spacing": spacing,
                              "n_nodes": rm["n_nodes"], "relative_l2": rm["relative_l2"]}),
                  flush=True)
        if not any(r["problem"] == "von_karman" and
                   r["nominal_spacing"] == spacing for r in records):
            vk, vk_field = solve_vk(spacing, n_boundary, vk_points, vk_reference, quick)
            records.append(vk)
            arrays[f"vk_spacing_{spacing:g}"] = vk_field
            checkpoint()
            print(json.dumps({"completed": "von_karman", "spacing": spacing,
                              "n_nodes": vk["n_nodes"], "relative_l2": vk["relative_l2"]}),
                  flush=True)
    audit = dense_sparse_audit(quick)
    payload = {
        "schema_version": "pipc-rbffd-convergence-v1", "domain": "star",
        "reference_file": str(reference_path),
        "reference_levels": {"reissner_mindlin": rm_level, "von_karman": vk_level},
        "dense_sparse_solver_audit": audit, "records": records,
    }
    (output / "rbffd_convergence.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8")
    np.savez_compressed(output / "rbffd_convergence_fields.npz", **arrays)
    return payload


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", type=Path, default=DEFAULT_REFERENCE)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--no-resume", action="store_true")
    args = parser.parse_args()
    result = run(args.reference, args.output, args.quick, not args.no_resume)
    print(json.dumps({"dense_sparse": result["dense_sparse_solver_audit"],
                      "records": result["records"]}, indent=2))


if __name__ == "__main__":
    main()
