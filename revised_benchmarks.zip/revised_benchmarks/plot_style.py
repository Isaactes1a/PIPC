"""Shared publication plotting style and colorbar helpers."""

from __future__ import annotations

import math
from collections.abc import Iterable

import matplotlib as mpl
import numpy as np


RESULT_CMAP = "viridis"
ERROR_CMAP = "magma"


def configure_publication_style() -> None:
    """Apply the manuscript-wide Times and inward-tick style."""
    mpl.rcParams.update({
        "font.family": "Times New Roman",
        "font.size": 9,
        "axes.titlesize": 10,
        "axes.labelsize": 9,
        "legend.fontsize": 8,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "mathtext.fontset": "stix",
        "axes.formatter.use_mathtext": True,
        "axes.unicode_minus": False,
        "xtick.direction": "in",
        "ytick.direction": "in",
        "xtick.minor.visible": True,
        "ytick.minor.visible": True,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })


def inward_ticks(ax) -> None:
    """Enforce inward major/minor ticks on an axis or colorbar axis."""
    ax.tick_params(axis="both", which="both", direction="in")


def absolute_error(values: np.ndarray, reference: np.ndarray) -> np.ndarray:
    """Return pointwise absolute error while preserving invalid FEM points."""
    values = np.asarray(values, dtype=float)
    reference = np.asarray(reference, dtype=float)
    if values.shape != reference.shape:
        raise ValueError(f"field/reference shape mismatch: {values.shape} != {reference.shape}")
    valid = np.isfinite(values) & np.isfinite(reference)
    error = np.full(reference.shape, np.nan, dtype=float)
    error[valid] = np.abs(values[valid] - reference[valid])
    return error


def shared_limits(fields: Iterable[np.ndarray], *, zero_min: bool = False) -> tuple[float, float]:
    """Compute finite limits shared by a group of displayed fields."""
    arrays = [np.asarray(field, dtype=float) for field in fields]
    finite = [field[np.isfinite(field)] for field in arrays]
    finite = [field for field in finite if field.size]
    if not finite:
        raise ValueError("cannot compute color limits without finite values")
    lo = 0.0 if zero_min else min(float(np.min(field)) for field in finite)
    hi = max(float(np.max(field)) for field in finite)
    if hi <= lo:
        delta = max(abs(lo), 1.0) * 1e-12
        hi = lo + delta
    return lo, hi


def scientific_exponent(lo: float, hi: float) -> int:
    """Extract a base-10 multiplier for colorbar magnitudes below 1e-1."""
    magnitude = max(abs(float(lo)), abs(float(hi)))
    if not np.isfinite(magnitude) or magnitude == 0.0 or magnitude >= 1e-1:
        return 0
    return int(math.floor(math.log10(magnitude)))


def add_three_tick_colorbar(fig, mappable, cax, lo: float, hi: float, fontsize: float = 8):
    """Add a vertical colorbar with min/mid/max ticks and a Times-style exponent."""
    ticks = np.linspace(lo, hi, 3)
    exponent = scientific_exponent(lo, hi)
    scale = 10.0 ** exponent if exponent else 1.0
    labels = [f"{value / scale:.3g}" for value in ticks]
    colorbar = fig.colorbar(mappable, cax=cax, ticks=ticks)
    colorbar.ax.set_yticklabels(labels, fontname="Times New Roman", fontsize=fontsize)
    colorbar.ax.tick_params(which="both", direction="in")
    if exponent:
        colorbar.ax.set_title(
            rf"$\times 10^{{{exponent}}}$",
            fontname="Times New Roman",
            fontsize=fontsize,
            pad=4,
        )
    return colorbar
