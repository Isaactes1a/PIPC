"""Refresh plate metrics with locked P2 FEM references and native PHS evaluation.

Deterministic algebraic methods are rerun.  Persisted PINN fields are reused;
the neural networks are not retrained merely because the reference changed.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from common import MethodRecord, SEEDS, summarize_stochastic, write_results
import plate_linear_three_method as LINEAR
import plate_three_method as VK

HERE = Path(__file__).resolve().parent


def filtered_metrics(pred, reference):
    pred, reference = np.asarray(pred, dtype=float), np.asarray(reference, dtype=float)
    keep = np.isfinite(pred) & np.isfinite(reference)
    error = pred[keep] - reference[keep]
    return {"relative_l2": float(np.linalg.norm(error) /
                                 max(np.linalg.norm(reference[keep]), 1e-30)),
            "mse": float(np.mean(error * error)),
            "linf": float(np.max(np.abs(error)))}


def refresh_record(item, prediction, reference, note):
    item = dict(item)
    item.update(filtered_metrics(prediction, reference))
    item.setdefault("details", {})["reference_refresh"] = note
    return MethodRecord(**item)


def updated_pinn_records(old_json, old_npz, problem, references, point_keys,
                         field_prefix):
    payload = json.loads(Path(old_json).read_text(encoding="utf-8"))
    fields = np.load(old_npz)
    records, arrays = [], {}
    for item in payload["records"]:
        if item["problem"] != problem or item["method"] != "PINN":
            continue
        domain, seed = item["domain"], item["seed"]
        key = f"{domain}_pinn_seed_{seed}"
        prediction = np.asarray(fields[key], dtype=float)
        records.append(refresh_record(
            item, prediction, references[domain],
            "locked topology-correct P2 FEM; persisted PINN field reused"))
        arrays[key] = prediction
    return records, arrays


def run(reference_path, linear_old, vk_old, linear_output, vk_output):
    reference = np.load(reference_path)
    linear_old_payload = json.loads(
        (Path(linear_old) / "plate_linear_results.json").read_text(encoding="utf-8"))
    linear_old_fields = np.load(Path(linear_old) / "plate_linear_fields.npz")
    vk_old_payload = json.loads(
        (Path(vk_old) / "plate_results.json").read_text(encoding="utf-8"))
    vk_old_fields = np.load(Path(vk_old) / "plate_fields.npz")

    linear_records, linear_arrays = [], {}
    linear_refs = {}
    for shape, level in (("square", 5), ("star", 4)):
        points = reference[f"linear_{shape}_eval_points"]
        fem = reference[f"linear_{shape}_level_{level}"]
        linear_refs[shape] = fem
        pipc, wp, solver = LINEAR.solve_pipc(shape, False, points, fem)
        old = next(item for item in linear_old_payload["records"]
                   if item["domain"] == shape and item["method"] == "PIELM")
        we = np.asarray(linear_old_fields[f"{shape}_pielm"], dtype=float)
        pielm = refresh_record(
            old, we, fem, "locked topology-correct P2 FEM; persisted PIELM field reused")
        linear_records.extend((pipc, pielm))
        linear_arrays.update({f"{shape}_points": points, f"{shape}_fem": fem,
                              f"{shape}_pipc": wp, f"{shape}_pielm": we})
    reused, arrays = updated_pinn_records(
        Path(linear_old) / "plate_linear_results.json",
        Path(linear_old) / "plate_linear_fields.npz",
        "linear_reissner_mindlin_plate", linear_refs, None, None)
    linear_records.extend(reused)
    linear_arrays.update(arrays)
    for shape in ("square", "star"):
        group = [r for r in reused if r.domain == shape]
        linear_arrays[f"{shape}_pinn_summary_json"] = np.array(
            json.dumps(summarize_stochastic(group)))
    linear_output.mkdir(parents=True, exist_ok=True)
    write_results(linear_output / "plate_linear_results.json",
                  {"quick": False, "seeds": list(SEEDS),
                   "fem": "locked topology-correct P2 FEM",
                   "reference_file": str(reference_path)}, linear_records)
    np.savez_compressed(linear_output / "plate_linear_fields.npz", **linear_arrays)

    vk_records, vk_arrays, vk_refs = [], {}, {}
    for shape, level in (("square", 6), ("star", 4)):
        points = reference[f"nonlinear_{shape}_eval_points"]
        fem_field = reference[f"nonlinear_{shape}_level_{level}"]
        fem = {"eval_w": fem_field}
        vk_refs[shape] = fem_field
        pipc, solver, _, wp, ref, keep = VK.solve_pipc(shape, False, fem, points)
        old = next(item for item in vk_old_payload["records"]
                   if item["domain"] == shape and item["method"] == "CL-PIELM")
        wc = np.asarray(vk_old_fields[f"{shape}_cl_pielm"], dtype=float)
        cl = refresh_record(
            old, wc, fem_field,
            "locked topology-correct P2 FEM; persisted CL-PIELM field reused")
        vk_records.extend((pipc, cl))
        vk_arrays.update({f"{shape}_eval_points": points, f"{shape}_fem": fem_field,
                          f"{shape}_pipc": wp, f"{shape}_cl_pielm": wc,
                          f"{shape}_keep": np.isfinite(fem_field)})
    reused, arrays = updated_pinn_records(
        Path(vk_old) / "plate_results.json", Path(vk_old) / "plate_fields.npz",
        "von_karman_plate", vk_refs, None, None)
    vk_records.extend(reused)
    vk_arrays.update(arrays)
    for shape in ("square", "star"):
        group = [r for r in reused if r.domain == shape]
        vk_arrays[f"{shape}_pinn_summary_json"] = np.array(
            json.dumps(summarize_stochastic(group)))
    vk_output.mkdir(parents=True, exist_ok=True)
    write_results(vk_output / "plate_results.json",
                  {"quick": False, "seeds": list(SEEDS),
                   "fem": "locked topology-correct P2 FEM",
                   "reference_file": str(reference_path),
                   "pinn_fields": "persisted fields; metrics refreshed only"}, vk_records)
    np.savez_compressed(vk_output / "plate_fields.npz", **vk_arrays)
    return linear_records, vk_records


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", type=Path,
                        default=HERE / "results" / "reference_convergence_fields.npz")
    parser.add_argument("--linear-old", type=Path,
                        default=HERE / "results" / "plate_linear_full_rerun")
    parser.add_argument("--vk-old", type=Path, default=HERE / "results" / "plate_full")
    parser.add_argument("--linear-output", type=Path,
                        default=HERE / "results" / "plate_linear_enhanced")
    parser.add_argument("--vk-output", type=Path,
                        default=HERE / "results" / "plate_enhanced")
    args = parser.parse_args()
    linear, vk = run(args.reference, args.linear_old, args.vk_old,
                     args.linear_output, args.vk_output)
    print(json.dumps({
        "linear": [{"method": r.method, "domain": r.domain,
                    "seed": r.seed, "relative_l2": r.relative_l2} for r in linear],
        "von_karman": [{"method": r.method, "domain": r.domain,
                        "seed": r.seed, "relative_l2": r.relative_l2} for r in vk],
    }, indent=2))


if __name__ == "__main__":
    main()
