"""Shared records, metrics, and validation for the revised PIPC benchmarks."""

from __future__ import annotations

import json
import math
import platform
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import numpy as np


SEEDS = (42, 2024, 7)
REQUIRED_FIELDS = {
    "method", "problem", "domain", "seed", "status", "relative_l2",
    "mse", "linf", "audit_residual_rms", "constraint_bc_linf",
    "dense_boundary_linf", "end_to_end_time_s", "stage_times_s",
    "counts", "history", "environment",
}


def environment_record() -> dict[str, Any]:
    record: dict[str, Any] = {
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
    }
    try:
        import scipy

        record["scipy"] = scipy.__version__
    except ImportError:
        pass
    try:
        import torch

        record.update({
            "torch": torch.__version__,
            "cuda_available": bool(torch.cuda.is_available()),
            "device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu",
            "dtype": "float64",
        })
    except ImportError:
        pass
    return record


def weighted_metrics(pred: np.ndarray, ref: np.ndarray, weights: np.ndarray) -> dict[str, float]:
    pred = np.asarray(pred, dtype=float).ravel()
    ref = np.asarray(ref, dtype=float).ravel()
    weights = np.asarray(weights, dtype=float).ravel()
    weights = weights / np.sum(weights)
    error = pred - ref
    denom = math.sqrt(float(np.sum(weights * ref**2)))
    return {
        "relative_l2": math.sqrt(float(np.sum(weights * error**2))) / max(denom, 1e-30),
        "mse": float(np.sum(weights * error**2)),
        "linf": float(np.max(np.abs(error))),
    }


@dataclass
class MethodRecord:
    method: str
    problem: str
    domain: str
    seed: int | None
    status: str
    relative_l2: float
    mse: float
    linf: float
    audit_residual_rms: float
    constraint_bc_linf: float | None
    dense_boundary_linf: float
    end_to_end_time_s: float
    stage_times_s: dict[str, float]
    counts: dict[str, int | float | None]
    history: list[dict[str, Any]] = field(default_factory=list)
    environment: dict[str, Any] = field(default_factory=environment_record)
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def validate_record(record: dict[str, Any]) -> None:
    missing = REQUIRED_FIELDS - set(record)
    if missing:
        raise ValueError(f"record missing fields: {sorted(missing)}")
    for key in ("relative_l2", "mse", "linf", "audit_residual_rms", "dense_boundary_linf", "end_to_end_time_s"):
        value = record[key]
        if not isinstance(value, (int, float)) or not math.isfinite(float(value)):
            raise ValueError(f"{record.get('method')} has invalid {key}: {value!r}")
    if record["seed"] is not None and record["seed"] not in SEEDS:
        raise ValueError(f"unexpected seed {record['seed']}")


def write_results(path: Path, metadata: dict[str, Any], records: list[MethodRecord]) -> None:
    payload = {"schema_version": "pipc-revised-benchmark-v1", "metadata": metadata,
               "records": [record.to_dict() for record in records]}
    for record in payload["records"]:
        validate_record(record)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def summarize_stochastic(records: list[MethodRecord]) -> dict[str, dict[str, float]]:
    if {record.seed for record in records} != set(SEEDS):
        raise ValueError("stochastic summary requires exactly seeds 42, 2024, and 7")
    result: dict[str, dict[str, float]] = {}
    for key in ("relative_l2", "mse", "linf", "audit_residual_rms", "dense_boundary_linf", "end_to_end_time_s"):
        values = np.asarray([getattr(record, key) for record in records], dtype=float)
        result[key] = {"mean": float(np.mean(values)), "std": float(np.std(values))}
    return result

