"""PIPC, CL-PIELM, and soft-boundary PINN for nonlinear 2-D heat conduction.

The independent FEM meshes and the geometry constructors are imported from the
audited legacy recomputation.  No PNI field, anchor loss, or supervised prior
projection is used here.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import math
import sys
import time
from pathlib import Path

import numpy as np
import torch
from scipy.optimize import least_squares

from common import MethodRecord, SEEDS, summarize_stochastic, weighted_metrics, write_results


HERE = Path(__file__).resolve().parent
LEGACY = HERE.parent / "ablation_pielm" / "nonlinear_heat_2d_mq_rbf.py"
DEFAULT_OUTPUT = HERE / "results" / "heat"


def load_heat_module():
    spec = importlib.util.spec_from_file_location("audited_heat", LEGACY)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


H = load_heat_module()
torch.set_default_dtype(torch.float64)


def gaussian_operators(points: np.ndarray, centers: np.ndarray, sigma: float):
    delta = points[:, None, :] - centers[None, :, :]
    dx, dy = delta[..., 0], delta[..., 1]
    s2 = sigma**2
    phi = np.exp(-(dx**2 + dy**2) / (2.0 * s2))
    px = -(dx / s2) * phi
    py = -(dy / s2) * phi
    pxx = (dx**2 / s2**2 - 1.0 / s2) * phi
    pyy = (dy**2 / s2**2 - 1.0 / s2) * phi
    return phi, px, py, pxx + pyy


def median_spacing(centers: np.ndarray) -> float:
    d = np.linalg.norm(centers[:, None] - centers[None, :], axis=2)
    d[d == 0.0] = np.inf
    return float(np.median(np.min(d, axis=1)))


def block_lstsq(a_pde, b_pde, a_bc, b_bc):
    pde_scale = max(float(np.sqrt(np.mean(b_pde**2))), 1.0)
    bc_scale = max(float(np.sqrt(np.mean(b_bc**2))), 1.0)
    a = np.vstack([a_pde / (pde_scale * math.sqrt(len(b_pde))),
                   a_bc / (bc_scale * math.sqrt(len(b_bc)))])
    b = np.concatenate([b_pde / (pde_scale * math.sqrt(len(b_pde))),
                        b_bc / (bc_scale * math.sqrt(len(b_bc)))])
    coeff, _, rank, singular = np.linalg.lstsq(a, b, rcond=1e-12)
    cond = float(singular[0] / singular[-1]) if len(singular) and singular[-1] > 0 else math.inf
    return coeff, int(rank), cond


def select_sigma(prior: dict, boundary_points: np.ndarray):
    centers = prior["centers"]
    h = median_spacing(centers)
    q = prior["q"]
    g = H.boundary_value(prior["key"], boundary_points)
    candidates = []
    for factor in (0.75, 1.0, 1.5, 2.0):
        sigma = factor * h
        _, _, _, lap = gaussian_operators(prior["residual_points"], centers, sigma)
        phi_b, _, _, _ = gaussian_operators(boundary_points, centers, sigma)
        coeff, rank, cond = block_lstsq(-lap, q, phi_b, g)
        residual = np.concatenate([-lap @ coeff - q, phi_b @ coeff - g])
        candidates.append({"factor": factor, "sigma": sigma, "rank": rank,
                           "condition": cond, "linear_rms": float(np.sqrt(np.mean(residual**2))),
                           "coeff": coeff})
    feasible = [item for item in candidates if item["condition"] <= 1e12]
    chosen = min(feasible or candidates, key=lambda item: item["linear_rms"])
    return chosen, [{k: v for k, v in item.items() if k != "coeff"} for item in candidates]


def full_heat_residual(values, ux, uy, lap, q, beta=1.0):
    return -(1.0 + beta * values**2) * lap - 2.0 * beta * values * (ux**2 + uy**2) - q


def solve_pipc(key: str, prior: dict, nodes, ref, weights, audit_points, boundary_points):
    started = time.perf_counter()
    rf, jf = H.nonlinear_rbf_functions(prior, 1.0)
    initial = prior["alpha_prior"].copy()
    direction = np.random.default_rng(42).normal(size=len(initial)); direction /= np.linalg.norm(direction)
    eps = 1e-6
    jac_error = float(np.linalg.norm((rf(initial + eps * direction) - rf(initial - eps * direction)) / (2 * eps) - jf(initial) @ direction) /
                      max(np.linalg.norm(jf(initial) @ direction), 1e-30))
    solve_started = time.perf_counter()
    sol = least_squares(rf, initial, jac=jf, method="trf", x_scale="jac",
                        ftol=2e-11, xtol=2e-11, gtol=2e-11, max_nfev=1000)
    solve_time = time.perf_counter() - solve_started
    lam = prior["lambda_p"] + prior["Z"] @ sol.x
    pred = H.eval_mq(prior, nodes, lam)
    metrics = weighted_metrics(pred, ref, weights)
    phi_a, px_a, py_a, lap_a = H.mq_operators(audit_points, prior["centers"], prior["shape"])
    audit = full_heat_residual(phi_a @ lam, px_a @ lam, py_a @ lam, lap_a @ lam,
                               H.source_value(key, audit_points))
    phi_b, _, _, _ = H.mq_operators(boundary_points, prior["centers"], prior["shape"])
    dense_bc = float(np.max(np.abs(phi_b @ lam - H.boundary_value(key, boundary_points))))
    constraint = float(np.max(np.abs(prior["boundary_matrix"] @ lam - H.boundary_value(
        key, prior["centers"][prior["boundary_indices"]]))))
    record = MethodRecord("PIPC", "nonlinear_heat", key, None,
                          "converged" if sol.success else f"status_{sol.status}",
                          **metrics, audit_residual_rms=float(np.sqrt(np.mean(audit**2))),
                          constraint_bc_linf=constraint, dense_boundary_linf=dense_bc,
                          end_to_end_time_s=time.perf_counter() - started,
                          stage_times_s={"full_nonlinear_trf": solve_time},
                          counts={"nfev": int(sol.nfev), "njev": int(sol.njev or 0), "stages": 1},
                          history=[{"stage": "beta=1", "nfev": int(sol.nfev), "cost": float(sol.cost)}],
                          details={"prior": "beta=0 deterministic MQ-RBF", "jacobian_directional_error": jac_error,
                                   "continuation_used": False})
    return record, pred, lam


def solve_cl_pielm(key: str, prior: dict, nodes, ref, weights, audit_points, boundary_points):
    started = time.perf_counter()
    selected, candidates = select_sigma(prior, boundary_points)
    sigma, coeff = selected["sigma"], selected["coeff"].copy()
    centers = prior["centers"]
    phi, px, py, lap = gaussian_operators(prior["residual_points"], centers, sigma)
    phi_b, _, _, _ = gaussian_operators(boundary_points, centers, sigma)
    q, g = prior["q"], H.boundary_value(key, boundary_points)
    history, ranks, conditions = [], [], []
    solve_started = time.perf_counter()
    for beta in (0.0, 0.25, 0.5, 0.75, 1.0):
        u, ux, uy = phi @ coeff, px @ coeff, py @ coeff
        a_pde = -(1.0 + beta * u**2)[:, None] * lap - (2.0 * beta * u)[:, None] * (
            ux[:, None] * px + uy[:, None] * py)
        coeff, rank, cond = block_lstsq(a_pde, q, phi_b, g)
        residual = full_heat_residual(phi @ coeff, px @ coeff, py @ coeff, lap @ coeff, q, beta)
        history.append({"beta": beta, "linear_rank": rank, "condition": cond,
                        "full_residual_rms": float(np.sqrt(np.mean(residual**2)))})
        ranks.append(rank); conditions.append(cond)
    solve_time = time.perf_counter() - solve_started
    phi_n, _, _, _ = gaussian_operators(nodes, centers, sigma)
    pred = phi_n @ coeff
    metrics = weighted_metrics(pred, ref, weights)
    phi_a, px_a, py_a, lap_a = gaussian_operators(audit_points, centers, sigma)
    audit = full_heat_residual(phi_a @ coeff, px_a @ coeff, py_a @ coeff, lap_a @ coeff,
                               H.source_value(key, audit_points))
    dense_bc = float(np.max(np.abs(phi_b @ coeff - g)))
    record = MethodRecord("CL-PIELM", "nonlinear_heat", key, None, "completed",
                          **metrics, audit_residual_rms=float(np.sqrt(np.mean(audit**2))),
                          constraint_bc_linf=None, dense_boundary_linf=dense_bc,
                          end_to_end_time_s=time.perf_counter() - started,
                          stage_times_s={"feature_selection_and_curriculum": solve_time},
                          counts={"linear_solves": 5, "stages": 5, "rank": min(ranks)},
                          history=history,
                          details={"basis": "Gaussian RBF fixed features", "sigma": sigma,
                                   "sigma_over_h": selected["factor"], "max_condition": max(conditions),
                                   "sigma_candidates": candidates, "adaptation": "steady quasilinear curriculum"})
    return record, pred


class SoftHeatPINN(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.net = torch.nn.Sequential(torch.nn.Linear(2, 128), torch.nn.Tanh(),
                                       torch.nn.Linear(128, 128), torch.nn.Tanh(),
                                       torch.nn.Linear(128, 1))
        for layer in self.modules():
            if isinstance(layer, torch.nn.Linear):
                torch.nn.init.xavier_normal_(layer.weight); torch.nn.init.zeros_(layer.bias)

    def forward(self, xy):
        return self.net(xy)


def torch_residual(model, xy, key):
    xy = xy.requires_grad_(True)
    u = model(xy)
    grad = torch.autograd.grad(u, xy, torch.ones_like(u), create_graph=True)[0]
    ux, uy = grad[:, :1], grad[:, 1:]
    uxx = torch.autograd.grad(ux, xy, torch.ones_like(ux), create_graph=True)[0][:, :1]
    uyy = torch.autograd.grad(uy, xy, torch.ones_like(uy), create_graph=True)[0][:, 1:]
    q = H.source_torch(key, xy).reshape(-1, 1)
    return -(1.0 + u**2) * (uxx + uyy) - 2.0 * u * (ux**2 + uy**2) - q


def eval_model(model, points, device, batch=4096):
    values = []
    with torch.no_grad():
        for start in range(0, len(points), batch):
            values.append(model(torch.as_tensor(points[start:start + batch], dtype=torch.float64, device=device)).cpu().numpy()[:, 0])
    return np.concatenate(values)


def solve_pinn(key: str, seed: int, prior: dict, nodes, ref, weights, audit_points,
               boundary_points, quick: bool):
    H.set_seed(seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = SoftHeatPINN().to(device=device, dtype=torch.float64)
    x_int = torch.as_tensor(prior["residual_points"], dtype=torch.float64, device=device)
    x_bnd = torch.as_tensor(boundary_points, dtype=torch.float64, device=device)
    g_bnd = torch.as_tensor(H.boundary_value(key, boundary_points)[:, None], dtype=torch.float64, device=device)
    qscale = max(float(np.max(np.abs(prior["q"]))), 1.0)
    hscale = max(float(np.max(np.abs(H.boundary_value(key, boundary_points)))), 1.0)
    adam_steps, lbfgs_steps = ((250, 50) if quick else (5000, 1000))
    history = []

    def loss_parts():
        pde = torch.mean((torch_residual(model, x_int.clone(), key) / qscale) ** 2)
        bc = torch.mean(((model(x_bnd) - g_bnd) / hscale) ** 2)
        return pde, bc, pde + bc

    started = time.perf_counter()
    adam_started = time.perf_counter()
    adam = torch.optim.Adam(model.parameters(), lr=5e-4)
    for step in range(adam_steps):
        adam.zero_grad(); pde, bc, loss = loss_parts(); loss.backward(); adam.step()
        if step % max(adam_steps // 50, 1) == 0 or step == adam_steps - 1:
            history.append({"phase": "adam", "step": step, "loss": float(loss.detach().cpu()),
                            "pde": float(pde.detach().cpu()), "bc": float(bc.detach().cpu())})
    if device.type == "cuda": torch.cuda.synchronize()
    adam_time = time.perf_counter() - adam_started
    calls = {"n": 0}
    lbfgs_started = time.perf_counter()
    opt = torch.optim.LBFGS(model.parameters(), lr=1.0, max_iter=lbfgs_steps,
                            tolerance_grad=1e-12, tolerance_change=1e-12,
                            history_size=50, line_search_fn="strong_wolfe")
    def closure():
        opt.zero_grad(); pde, bc, loss = loss_parts(); loss.backward(); calls["n"] += 1
        if calls["n"] % max(lbfgs_steps // 25, 1) == 0:
            history.append({"phase": "lbfgs", "closure": calls["n"], "loss": float(loss.detach().cpu()),
                            "pde": float(pde.detach().cpu()), "bc": float(bc.detach().cpu())})
        return loss
    opt.step(closure)
    if device.type == "cuda": torch.cuda.synchronize()
    lbfgs_time = time.perf_counter() - lbfgs_started
    pred = eval_model(model, nodes, device)
    metrics = weighted_metrics(pred, ref, weights)
    audit_tensor = torch.as_tensor(audit_points, dtype=torch.float64, device=device)
    audit = torch_residual(model, audit_tensor, key).detach().cpu().numpy()[:, 0]
    dense_bc = float(np.max(np.abs(eval_model(model, boundary_points, device) - H.boundary_value(key, boundary_points))))
    record = MethodRecord("PINN", "nonlinear_heat", key, seed, "budget_completed",
                          **metrics, audit_residual_rms=float(np.sqrt(np.mean(audit**2))),
                          constraint_bc_linf=None, dense_boundary_linf=dense_bc,
                          end_to_end_time_s=time.perf_counter() - started,
                          stage_times_s={"adam": adam_time, "lbfgs": lbfgs_time},
                          counts={"adam_steps": adam_steps, "lbfgs_closures": calls["n"]},
                          history=history, details={"network": "2x128 tanh", "boundary": "soft normalized MSE",
                                                    "dtype": "float64", "device": str(device)})
    return record, pred


def run(output: Path, quick: bool, skip_pinn: bool):
    records, arrays = [], {}
    for key in H.GEOMETRIES:
        prior = H.build_mq_prior(key, quick=quick)
        fem = H.solve_fem(key, "fine", 1.0, quick=quick)
        nodes, ref = fem["nodes"], fem["u"]
        weights = H.lumped_area_weights(nodes, fem["triangles"])
        fixed = np.zeros(len(nodes), dtype=bool); fixed[fem["boundary"]] = True
        audit_points = nodes[~fixed]
        boundary_points = H.dense_boundary_points(key, nedge=21 if quick else 61)
        pipc, pipc_field, _ = solve_pipc(key, prior, nodes, ref, weights, audit_points, boundary_points)
        cl, cl_field = solve_cl_pielm(key, prior, nodes, ref, weights, audit_points, boundary_points)
        records.extend([pipc, cl])
        arrays[f"{key}_nodes"] = nodes; arrays[f"{key}_triangles"] = fem["triangles"]
        arrays[f"{key}_reference"] = ref; arrays[f"{key}_pipc"] = pipc_field; arrays[f"{key}_cl_pielm"] = cl_field
        if not skip_pinn:
            stochastic = []
            for seed in SEEDS:
                rec, field = solve_pinn(key, seed, prior, nodes, ref, weights, audit_points, boundary_points, quick)
                stochastic.append(rec); records.append(rec); arrays[f"{key}_pinn_seed_{seed}"] = field
            summary = summarize_stochastic(stochastic)
            arrays[f"{key}_pinn_summary_json"] = np.array(json.dumps(summary))
    metadata = {"quick": quick, "seeds": list(SEEDS), "beta": 1.0,
                "timing_scope": "method construction and solve; FEM reference and plotting excluded",
                "cl_pielm_scope": "Gaussian-feature steady quasilinear adaptation of the published flow algorithm"}
    write_results(output / "heat_results.json", metadata, records)
    np.savez_compressed(output / "heat_fields.npz", **arrays)
    return records


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--skip-pinn", action="store_true")
    args = parser.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    records = run(args.output, args.quick, args.skip_pinn)
    print(json.dumps([{"method": r.method, "domain": r.domain, "seed": r.seed,
                       "rel_l2": r.relative_l2, "residual": r.audit_residual_rms,
                       "bc": r.dense_boundary_linf, "time": r.end_to_end_time_s}
                      for r in records], indent=2))


if __name__ == "__main__":
    main()
