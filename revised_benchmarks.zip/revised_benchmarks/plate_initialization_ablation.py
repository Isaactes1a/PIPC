"""PIPC initialization audit for the square von Karman plate (PHS-RBF-FD)."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import phs_rbf_fd as PHS


def main():
    HERE = Path(__file__).resolve().parent
    out = HERE / "results" / "plate_full"
    out.mkdir(parents=True, exist_ok=True)
    pts, is_bnd = PHS.square_cloud(21)
    solver = PHS.VKRBFDSolver("square", {"stencil": 31, "poly_degree": 4, "phs_order": 3},
                              quick=False, pts=pts, is_bnd=is_bnd)
    linear = solver.linear_prior()
    n = solver.N_int
    deterministic = np.r_[linear[:n], linear[n:], np.zeros(2 * n)]
    rng = np.random.default_rng(42)
    random = rng.normal(size=4 * n)
    random *= np.linalg.norm(deterministic) / max(np.linalg.norm(random), 1e-30)
    rows = []
    for name, start in (("deterministic_prior", deterministic),
                        ("zero", np.zeros(4 * n)),
                        ("seeded_random", random)):
        r0 = solver.residual_and_jac(start)[0]
        sol, elapsed = solver.solve_trf(start, max_nfev=2000, xtol=1e-14)
        rf = solver.residual_and_jac(sol.x)[0]
        w = solver.E_map @ sol.x[:n]
        rows.append({
            "method": "PIPC", "initialization": name,
            "seed": 42 if name == "seeded_random" else None,
            "status": "converged" if sol.success else f"status_{sol.status}",
            "nfev": int(sol.nfev), "njev": int(sol.njev or 0), "time_s": elapsed,
            "initial_residual_rms": float(np.sqrt(np.mean(r0 * r0))),
            "final_residual_rms": float(np.sqrt(np.mean(rf * rf))),
            "w_max": float(np.max(np.abs(w))),
            "basis": "PHS-RBF-FD", "n_nodes": int(solver.N), "n_int": int(n),
        })
    (out / "plate_initialization_ablation.json").write_text(
        json.dumps({"schema_version": "pipc-initialization-ablation-v1", "records": rows},
                   indent=2), encoding="utf-8")
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
