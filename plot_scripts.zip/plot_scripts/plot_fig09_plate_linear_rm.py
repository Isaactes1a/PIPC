# -*- coding: utf-8 -*-
"""Figure 9: linear Reissner-Mindlin plate, CPI / FEM / PNI + errors.

Layout: 2 rows x 5 columns.  Row 1 = square plate, row 2 = star-shaped
plate.  Columns: CPI (MQ-RBF weak form), FEM reference, PNI
(MQ-RBF prior + PINN), |CPI - FEM|, |PNI - FEM|.

Data: data/plate_rm_linear_fields.npz.
Output: PIPC_LaTeX_Package/figures/fig09.png
"""

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

HERE = Path(__file__).resolve().parent
DATA = HERE / "data"
PACKAGE_FIGS = HERE.parents[2] / "PIPC_LaTeX_Package" / "figures"

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size": 9,
    "axes.titlesize": 9,
    "axes.labelsize": 9,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "savefig.dpi": 300,
})

COLUMN_TITLES = ["CPI (MQ-RBF)", "FEM reference", "PNI",
                 r"|CPI $-$ FEM|", r"|PNI $-$ FEM|"]


def field_panel(ax, X, Y, mask, values, vmax, title, cmap, vmin):
    Z = np.full_like(X, np.nan, dtype=float)
    Z.ravel()[mask] = values
    pc = ax.pcolormesh(X, Y, Z, cmap=cmap, vmin=vmin, vmax=vmax,
                       shading="auto")
    ax.set_aspect("equal")
    ax.set_title(title)
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    return pc


def main() -> None:
    z = np.load(DATA / "plate_rm_linear_fields.npz")
    rows = [
        ("Square plate", z["Xs"], z["Ys"], z["mask_s"],
         z["w_pipc_sq"], z["w_fem_sq"], z["w_pni_sq"]),
        ("Star-shaped plate", z["Xt"], z["Yt"], z["mask_t"],
         z["w_pipc_st"], z["w_fem_st"], z["w_pni_st"]),
    ]

    fig = plt.figure(figsize=(18.0, 8.8))
    gs = fig.add_gridspec(2, 10, width_ratios=[1.0] * 5 + [0.045] * 5,
                          hspace=0.38, wspace=0.22)
    axes = [[fig.add_subplot(gs[r, c]) for c in range(5)] for r in range(2)]
    caxes = [[fig.add_subplot(gs[r, 5 + c]) for c in range(5)]
             for r in range(2)]

    for r, (row_label, X, Y, mask, w_cpi, w_fem, w_pni) in enumerate(rows):
        vmax = max(float(np.abs(w_cpi).max()), float(np.abs(w_fem).max()),
                   float(np.abs(w_pni).max()))
        emax = max(float(np.max(np.abs(w_cpi - w_fem))),
                   float(np.max(np.abs(w_pni - w_fem))), 1e-14)
        panels = [
            (w_cpi, "viridis", -vmax),
            (w_fem, "viridis", -vmax),
            (w_pni, "viridis", -vmax),
            (np.abs(w_cpi - w_fem), "magma", 0.0),
            (np.abs(w_pni - w_fem), "magma", 0.0),
        ]
        for c, (values, cmap, vmin) in enumerate(panels):
            ax = axes[r][c]
            vmax_here = vmax if cmap == "viridis" else emax
            pc = field_panel(ax, X, Y, mask, values, vmax_here,
                             COLUMN_TITLES[c], cmap, vmin)
            cb = fig.colorbar(pc, cax=caxes[r][c])
            cb.ax.tick_params(labelsize=7)
        axes[r][0].set_ylabel(row_label, fontsize=10)

    fig.suptitle(
        "Linear Reissner\N{EN DASH}Mindlin plate: CPI, FEM reference, PNI "
        "and absolute errors",
        fontsize=13, y=0.99,
    )
    PACKAGE_FIGS.mkdir(parents=True, exist_ok=True)
    out = PACKAGE_FIGS / "fig09.png"
    fig.savefig(out, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("saved", out)


if __name__ == "__main__":
    main()
