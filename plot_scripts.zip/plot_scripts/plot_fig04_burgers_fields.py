# -*- coding: utf-8 -*-
"""Figure 4: Burgers reference / prior / CPI / PNI fields and absolute errors.

Data: data/burgers_mq_fields.npz (x, t, reference, prior, cpi, pni).
Output: PIPC_LaTeX_Package/figures/fig04.png
"""

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

HERE = Path(__file__).resolve().parent
DATA = HERE / "data"
PACKAGE_FIGS = HERE.parents[2] / "PIPC_LaTeX_Package" / "figures"


def main() -> None:
    z = np.load(DATA / "burgers_mq_fields.npz")
    x, t = z["x"], z["t"]
    ref, prior, cpi, pni = z["reference"], z["prior"], z["cpi"], z["pni"]

    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "xtick.direction": "in",
        "ytick.direction": "in",
        "font.size": 10,
        "axes.titlesize": 11,
        "axes.labelsize": 10,
        "figure.dpi": 150,
        "savefig.dpi": 300,
        "axes.spines.top": False,
        "axes.spines.right": False,
    })
    extent = [x[0], x[-1], t[0], t[-1]]
    vmax = float(np.max(np.abs(ref)))
    emax = float(max(np.max(np.abs(cpi - ref)), np.max(np.abs(pni - ref))))
    fig, axes = plt.subplots(2, 3, figsize=(12.2, 6.8), constrained_layout=True)
    panels = [
        (ref, "Reference (Cole-Hopf)", "coolwarm", -vmax, vmax),
        (cpi, "CPI: MQ-RBF + TRF\n(budget-limited iterate)", "coolwarm", -vmax, vmax),
        (pni, "PNI: MQ-RBF + PINN", "coolwarm", -vmax, vmax),
        (prior, "Shared MQ-RBF prior", "coolwarm", -vmax, vmax),
        (np.abs(cpi - ref), "|CPI - reference|", "magma", 0.0, emax),
        (np.abs(pni - ref), "|PNI - reference|", "magma", 0.0, emax),
    ]
    for ax, (field, title, cmap, lo, hi) in zip(axes.ravel(), panels):
        im = ax.imshow(field, origin="lower", aspect="auto", extent=extent,
                       cmap=cmap, vmin=lo, vmax=hi, interpolation="bilinear")
        ax.set_title(title)
        ax.set_xlabel("x")
        ax.set_ylabel("t")
        fig.colorbar(im, ax=ax, shrink=0.86, pad=0.02)
    fig.suptitle(r"Viscous Burgers equation, $\nu=0.01/\pi$ (hard IC/BC)",
                 fontsize=13)

    PACKAGE_FIGS.mkdir(parents=True, exist_ok=True)
    out = PACKAGE_FIGS / "fig04.png"
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    print("saved", out)


if __name__ == "__main__":
    main()
