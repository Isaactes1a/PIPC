# -*- coding: utf-8 -*-
"""Figure 7: nonlinear heat conduction fields (FEM / CPI / PNI + errors).

Data: data/nonlinear_heat_2d_results.json and
      data/nonlinear_heat_2d_fields.npz.
Output: PIPC_LaTeX_Package/figures/fig07.png
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
import numpy as np

HERE = Path(__file__).resolve().parent
DATA = HERE / "data"
PACKAGE_FIGS = HERE.parents[2] / "PIPC_LaTeX_Package" / "figures"


def main() -> None:
    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "xtick.direction": "in",
        "ytick.direction": "in",
        "font.size": 10,
        "axes.titlesize": 11,
        "axes.labelsize": 10,
    })
    report = json.loads((DATA / "nonlinear_heat_2d_results.json").read_text(encoding="utf-8"))
    metrics = report["geometries"]
    z = np.load(DATA / "nonlinear_heat_2d_fields.npz")
    arrays = {}
    for key in metrics:
        arrays[key] = {
            "nodes": z[f"{key}_nodes"],
            "triangles": z[f"{key}_triangles"],
            "fem": z[f"{key}_fem"],
            "cpi": z[f"{key}_cpi"],
            "pni": z[f"{key}_pni"],
        }

    keys = list(metrics)
    fig, axes = plt.subplots(3, len(keys), figsize=(4.55 * len(keys), 10.2),
                             squeeze=False)
    for col, key in enumerate(keys):
        a = arrays[key]
        tri = mtri.Triangulation(a["nodes"][:, 0], a["nodes"][:, 1], a["triangles"])
        ref, cpi, pni = a["fem"], a["cpi"], a["pni"]
        cpi_metric = metrics[key]["cpi_mq_rbf_trf"]["metrics_vs_fem"]
        pni_metric = metrics[key]["pni_mq_rbf_pinn"]["metrics_vs_fem"]
        vmin = float(min(np.min(ref), np.min(cpi), np.min(pni)))
        vmax = float(max(np.max(ref), np.max(cpi), np.max(pni)))
        e_cpi, e_pni = np.abs(cpi - ref), np.abs(pni - ref)
        emax = max(float(np.max(e_cpi)), float(np.max(e_pni)), 1e-14)
        fields = [ref, cpi, pni]
        row_titles = [
            "P1 FEM + damped Newton",
            rf"CPI: MQ-RBF + TRF" + "\n" + rf"rel. $L_2={cpi_metric['relative_l2']:.2e}$",
            rf"PNI: MQ-RBF + PINN" + "\n" + rf"rel. $L_2={pni_metric['relative_l2']:.2e}$",
        ]
        main_artist = None
        for row, (field, title) in enumerate(zip(fields, row_titles)):
            ax = axes[row, col]
            main_artist = ax.tricontourf(
                tri, field, levels=32, cmap="inferno", vmin=vmin, vmax=vmax
            )
            ax.set_aspect("equal")
            ax.set_title(title, fontsize=10.5, pad=5)
            ax.set_xlabel("x")
            ax.set_ylabel("y")
            if row > 0:
                err = e_cpi if row == 1 else e_pni
                linf = cpi_metric["linf"] if row == 1 else pni_metric["linf"]
                inset = ax.inset_axes([0.60, 0.055, 0.36, 0.34])
                inset.tricontourf(tri, err, levels=20, cmap="viridis",
                                  vmin=0.0, vmax=emax)
                inset.set_xticks([])
                inset.set_yticks([])
                inset.set_title(rf"$|e|_\infty={linf:.1e}$", fontsize=7.5, pad=1.5)
                for spine in inset.spines.values():
                    spine.set_linewidth(0.7)
                    spine.set_color("white")
        cax = axes[0, col].inset_axes([1.025, 0.14, 0.035, 0.70])
        cb = fig.colorbar(main_artist, cax=cax)
        cb.ax.tick_params(labelsize=7.5)
        cb.set_label("$T$", fontsize=9)
        axes[0, col].set_title(
            metrics[key]["label"] + "\n" + row_titles[0],
            fontsize=11.5, pad=5, fontweight="bold",
        )
    fig.suptitle(
        r"Nonlinear steady conduction: $-\nabla\!\cdot[(1+T^2)\nabla T]=Q$",
        fontsize=15, y=0.995,
    )
    fig.subplots_adjust(left=0.055, right=0.965, bottom=0.055, top=0.895,
                        wspace=0.42, hspace=0.32)

    PACKAGE_FIGS.mkdir(parents=True, exist_ok=True)
    out = PACKAGE_FIGS / "fig07.png"
    fig.savefig(out, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print("saved", out)


if __name__ == "__main__":
    main()
