# -*- coding: utf-8 -*-
"""One-time helper: generate the cached field data used by the plate figures.

Produces in ``data/``:
    plate_cpi_fields_square.npz   w_lin / w_cpi / w_new / w_pni + grid
    plate_cpi_fields_star.npz     same for the star-shaped plate
    plate_rm_linear_fields.npz    linear RM RBF/FEM/PNI fields (2x5 panels)

Run from this folder:
    python _prepare_plate_data.py
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
SRC = HERE.parent / "ablation_pielm"
sys.path.insert(0, str(SRC))
DATA = HERE / "data"


def fine_grid(shape: str, N: int = 201):
    x = np.linspace(-1.0, 1.0, N)
    X, Y = np.meshgrid(x, x, indexing="ij")
    pts = np.column_stack([X.ravel(), Y.ravel()])
    if shape == "square":
        mask = np.ones(len(pts), dtype=bool)
    else:
        R = np.hypot(pts[:, 0], pts[:, 1])
        th = np.arctan2(pts[:, 1], pts[:, 0])
        Rb = 1.0 + 0.3 * np.sin(5 * th)
        mask = R <= Rb
    return X, Y, pts, mask


def eval_field(solver, alpha, grid_pts):
    dx = grid_pts[:, 0:1] - solver.pts[:, 0:1].T
    dy = grid_pts[:, 1:2] - solver.pts[:, 1:2].T
    r2 = dx ** 2 + dy ** 2
    Phi_g = np.sqrt(r2 + solver.cfg["c"] ** 2)
    n = solver.N_int
    lam_w = solver.M_map @ alpha[:n]
    return Phi_g @ lam_w


def prepare_vk_cases() -> None:
    import plate_cpi_trf as P
    import plate_pni

    for shape in ["square", "star"]:
        solver = P.PlateCPI(shape)
        solver.ro = solver.reduced_ops()
        lam0 = solver.linear_prior()
        n = solver.N_int
        alpha0 = np.concatenate([lam0[:n], lam0[n:], np.zeros(2 * n)])
        sol, t_cpi = solver.solve_cpi_trf(alpha0)
        a_new, _t_new, _it_new = solver.solve_newton(alpha0)
        X, Y, pts, mask = fine_grid(shape)
        gpts = pts[mask]
        w_lin = eval_field(solver, alpha0, gpts)
        w_cpi = eval_field(solver, sol.x, gpts)
        w_new = eval_field(solver, a_new, gpts)
        w_pni = plate_pni.solve_vk_pni(shape)
        rel_l2 = float(np.linalg.norm(w_cpi - w_new) / (np.linalg.norm(w_new) + 1e-14))
        rel_l2_pni = float(np.linalg.norm(w_pni - w_new) / (np.linalg.norm(w_new) + 1e-14))
        linf_pni = float(np.max(np.abs(w_pni - w_new)))
        out = DATA / f"plate_cpi_fields_{shape}.npz"
        np.savez_compressed(
            out,
            X=X, Y=Y, mask=mask,
            pts=solver.pts, idx_bnd=solver.idx_bnd,
            w_lin=w_lin, w_cpi=w_cpi, w_new=w_new, w_pni=w_pni,
            nfev=int(sol.nfev), rel_l2=rel_l2, t_cpi=t_cpi,
            rel_l2_pni=rel_l2_pni, linf_pni=linf_pni,
            N_int=n,
            E=solver.cfg["E"], nu=solver.cfg["nu"], h=solver.cfg["h"],
            q0=solver.cfg["q0"], c=solver.cfg["c"],
        )
        print(f"saved {out.name}: N_int={n} nfev={sol.nfev} "
              f"rel_l2={rel_l2:.3e} rel_l2_pni={rel_l2_pni:.3e} "
              f"t_cpi={t_cpi:.1f}s")


def prepare_rm_linear() -> None:
    import plate_rm as R
    import plate_rm_rbf_weak as W
    import plate_pni

    h = 0.05
    Xs, Ys, pts_s, mask_s = R.fine_grid("square")
    # MQ-RBF weak-form CPI fields (the Fig. 9 narrative uses the weak form)
    cfg_w = dict(E=1e5, nu=0.3, h=h, q=0.005, c=0.3,
                 N_grid=20, N_bnd=120, N_layers=8)
    sol_sq = W.solve_rbf_weak("square", cfg_w)
    w_pipc_sq = W.eval_w(sol_sq, pts_s[mask_s], 0.3)
    cpts, cells, U, pts_p2 = R.fem_solve("square", 5, h=h)
    w_fem_sq = R.fem_field(pts_p2, cells, U, pts_s[mask_s], cpts)
    Xt, Yt, pts_t, mask_t = R.fine_grid("star")
    sol_st = W.solve_rbf_weak("star", cfg_w)
    w_pipc_st = W.eval_w(sol_st, pts_t[mask_t], 0.3)
    cpts2, cells2, U2, pts_p22 = R.fem_solve("star", 4, h=h)
    w_fem_st = R.fem_field(pts_p22, cells2, U2, pts_t[mask_t], cpts2)
    w_pni_sq = plate_pni.solve_rm_pni("square")
    w_pni_st = plate_pni.solve_rm_pni("star")
    rel_sq = float(np.linalg.norm(w_pipc_sq - w_fem_sq) / np.linalg.norm(w_fem_sq))
    rel_st = float(np.linalg.norm(w_pipc_st - w_fem_st) / np.linalg.norm(w_fem_st))
    rel_pni_sq = float(np.linalg.norm(w_pni_sq - w_fem_sq) / np.linalg.norm(w_fem_sq))
    rel_pni_st = float(np.linalg.norm(w_pni_st - w_fem_st) / np.linalg.norm(w_fem_st))
    out = DATA / "plate_rm_linear_fields.npz"
    np.savez_compressed(
        out,
        Xs=Xs, Ys=Ys, mask_s=mask_s,
        Xt=Xt, Yt=Yt, mask_t=mask_t,
        w_pipc_sq=w_pipc_sq, w_fem_sq=w_fem_sq,
        w_pipc_st=w_pipc_st, w_fem_st=w_fem_st,
        w_pni_sq=w_pni_sq, w_pni_st=w_pni_st,
        rel_sq=rel_sq, rel_st=rel_st,
        rel_pni_sq=rel_pni_sq, rel_pni_st=rel_pni_st,
        h=h,
    )
    print(f"saved {out.name}: |w_pipc_sq|={np.abs(w_pipc_sq).max():.4e} "
          f"|w_fem_sq|={np.abs(w_fem_sq).max():.4e} "
          f"|w_fem_st|={np.abs(w_fem_st).max():.4e} "
          f"rel_sq={rel_sq:.3e} rel_st={rel_st:.3e} "
          f"rel_pni_sq={rel_pni_sq:.3e} rel_pni_st={rel_pni_st:.3e}")


def main() -> None:
    DATA.mkdir(parents=True, exist_ok=True)
    prepare_vk_cases()
    prepare_rm_linear()
    print("plate data cache ready")


if __name__ == "__main__":
    main()
