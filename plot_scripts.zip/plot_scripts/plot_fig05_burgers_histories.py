# -*- coding: utf-8 -*-
"""Figure 5: Burgers correction histories (CPI TRF / PNI training).

Data: data/burgers_mq_cpi_history.csv and data/burgers_mq_pni_history.csv.
Output: PIPC_LaTeX_Package/figures/fig05.png
"""

from __future__ import annotations

import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

HERE = Path(__file__).resolve().parent
DATA = HERE / "data"
PACKAGE_FIGS = HERE.parents[2] / "PIPC_LaTeX_Package" / "figures"


def read_csv(path: Path):
    with path.open(encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def main() -> None:
    cpi_rows = read_csv(DATA / "burgers_mq_cpi_history.csv")
    pni_rows = read_csv(DATA / "burgers_mq_pni_history.csv")
    if not cpi_rows or not pni_rows:
        raise RuntimeError("CPI and PNI history CSV files are both required")

    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "xtick.direction": "in",
        "ytick.direction": "in",
        "font.size": 10,
        "axes.titlesize": 11,
        "axes.labelsize": 10,
        "figure.dpi": 150,
        "savefig.dpi": 300,
        "axes.spines.top": False,
        "axes.spines.right": False,
    })
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.1), constrained_layout=True)

    cx = np.arange(len(cpi_rows))
    cy = np.array([float(r["residual_rms"]) for r in cpi_rows])
    ck = np.array([float(r["nonlinearity"]) for r in cpi_rows])
    axes[0].semilogy(cx, np.maximum(cy, 1e-16), color="#276FBF", lw=1.7)
    changes = np.where(np.r_[True, ck[1:] != ck[:-1]])[0]
    for idx in changes:
        axes[0].axvline(idx, color="0.7", lw=0.8, ls="--")
        axes[0].text(idx + 1, max(cy) * 0.7, f"$\\alpha$={ck[idx]:.2g}",
                     rotation=90, va="top", fontsize=8, color="0.35")
    axes[0].set_title(r"CPI: MQ-RBF + continuation $\alpha$ / TRF (budget-limited)")
    axes[0].set_xlabel("TRF accepted iteration / event")
    axes[0].set_ylabel("Burgers residual RMS")
    axes[0].grid(True, which="both", alpha=0.22)

    colors = {"MQ-prior inheritance": "#D95F02",
              "PINN-Adam": "#1B9E77", "PINN-LBFGS": "#7570B3"}
    for stage, color in colors.items():
        rows = [r for r in pni_rows if r["stage"] == stage]
        if not rows:
            continue
        sx = [int(float(r["step"])) for r in rows]
        sy = [max(float(r["loss"]), 1e-16) for r in rows]
        axes[1].semilogy(sx, sy, marker="o", ms=2.3, lw=1.4, color=color,
                         label=stage)
    axes[1].set_title("PNI: MQ-RBF prior + PINN")
    axes[1].set_xlabel("optimization step / closure")
    axes[1].set_ylabel("training loss")
    axes[1].grid(True, which="both", alpha=0.22)
    axes[1].legend(frameon=False, fontsize=8)

    PACKAGE_FIGS.mkdir(parents=True, exist_ok=True)
    out = PACKAGE_FIGS / "fig05.png"
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    print("saved", out)


if __name__ == "__main__":
    main()
