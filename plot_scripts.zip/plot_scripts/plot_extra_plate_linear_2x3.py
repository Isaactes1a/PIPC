# -*- coding: utf-8 -*-
"""Exploratory figure: linear RM plate, 2x3 (square/star x result/ref/error).

Computed on the fly by _plate_2x3_common (cached in data/plate_2x3_fields.npz).
Output: outputs/plate_linear_2x3.png
"""

from __future__ import annotations

from pathlib import Path

import _plate_2x3_common as C

HERE = Path(__file__).resolve().parent
OUT_DIR = HERE / "outputs"


def main() -> None:
    d = C.load_or_compute()
    rows = [
        ("Square plate (linear)", dict(
            X=d["X_sq"], Y=d["Y_sq"], mask=d["mask_sq"],
            result=d["lin_sq_result"], ref=d["lin_sq_ref"],
            err=d["lin_sq_err"])),
        ("Star plate (linear)", dict(
            X=d["X_st"], Y=d["Y_st"], mask=d["mask_st"],
            result=d["lin_st_result"], ref=d["lin_st_ref"],
            err=d["lin_st_err"])),
    ]
    C.plot_2x3("plate_linear_2x3.png", rows,
               ["RBF result", "FEM reference", "|error| vs FEM"], OUT_DIR)


if __name__ == "__main__":
    main()
