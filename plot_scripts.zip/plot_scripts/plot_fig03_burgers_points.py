# -*- coding: utf-8 -*-
"""Figure 3: Burgers MQ centres / TRF residual points and PNI Sobol points.

Data: data/burgers_mq_cpi.npz and data/burgers_mq_pni.pt.
Output: PIPC_LaTeX_Package/figures/fig03.png
"""

from __future__ import annotations

import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

HERE = Path(__file__).resolve().parent
SRC = HERE.parent / "ablation_pielm"
sys.path.insert(0, str(SRC))
DATA = HERE / "data"
PACKAGE_FIGS = HERE.parents[2] / "PIPC_LaTeX_Package" / "figures"

from burgers_ablation_pielm import TMAX, TMIN, XMAX, XMIN  # noqa: E402


def main() -> None:
    cpi = np.load(DATA / "burgers_mq_cpi.npz")
    checkpoint = torch.load(DATA / "burgers_mq_pni.pt",
                            map_location="cpu", weights_only=False)

    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "xtick.direction": "in",
        "ytick.direction": "in",
        "font.size": 10,
        "axes.titlesize": 11,
        "axes.labelsize": 10,
        "figure.dpi": 150,
        "savefig.dpi": 300,
        "axes.spines.top": False,
        "axes.spines.right": False,
    })
    fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.2), constrained_layout=True)
    axes[0].scatter(cpi["residual_x"], cpi["residual_t"], s=2, alpha=0.24,
                    color="#4C78A8", label="TRF residual points")
    axes[0].scatter(cpi["cx"], cpi["ct"], s=16, facecolors="none",
                    edgecolors="#E45756", linewidths=0.7, label="MQ centers")
    axes[0].set_title("CPI: MQ centers and residual points")
    axes[0].legend(frameon=False, markerscale=1.3, fontsize=8)

    kind = np.asarray(checkpoint["collocation_kind"])
    px = np.asarray(checkpoint["collocation_x"])
    pt = np.asarray(checkpoint["collocation_t"])
    axes[1].scatter(px[kind == 0], pt[kind == 0], s=3, alpha=0.25,
                    color="#59A14F", label="uniform Sobol")
    axes[1].scatter(px[kind == 1], pt[kind == 1], s=3, alpha=0.25,
                    color="#F28E2B", label="layer-focused Sobol")
    axes[1].set_title("PNI: physics collocation points")
    axes[1].legend(frameon=False, markerscale=2.0, fontsize=8)
    for ax in axes:
        ax.set_xlim(XMIN, XMAX)
        ax.set_ylim(TMIN, TMAX)
        ax.set_xlabel("x")
        ax.set_ylabel("t")
        ax.grid(True, alpha=0.15)

    PACKAGE_FIGS.mkdir(parents=True, exist_ok=True)
    out = PACKAGE_FIGS / "fig03.png"
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    print("saved", out)


if __name__ == "__main__":
    main()
