# -*- coding: utf-8 -*-
"""Figure 8: collocation-point layouts for the square / star plates.

Data: data/plate_cpi_fields_square.npz and data/plate_cpi_fields_star.npz.
Output: PIPC_LaTeX_Package/figures/fig08.png
"""

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

HERE = Path(__file__).resolve().parent
DATA = HERE / "data"
PACKAGE_FIGS = HERE.parents[2] / "PIPC_LaTeX_Package" / "figures"

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "xtick.direction": "in",
    "ytick.direction": "in",
    "font.size": 10,
    "axes.titlesize": 10,
    "axes.labelsize": 9,
    "legend.fontsize": 8,
    "savefig.dpi": 200,
})


def main() -> None:
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.6))
    for ax, shape in zip(axes, ["square", "star"]):
        z = np.load(DATA / f"plate_cpi_fields_{shape}.npz")
        pts = z["pts"]
        idx_bnd = z["idx_bnd"]
        is_bnd = np.zeros(len(pts), dtype=bool)
        is_bnd[idx_bnd] = True
        ax.scatter(pts[~is_bnd, 0], pts[~is_bnd, 1], s=8, alpha=0.8,
                   label="Interior points")
        ax.scatter(pts[is_bnd, 0], pts[is_bnd, 1], s=18, marker="s",
                   facecolors="none", edgecolors="C1",
                   label="Boundary points")
        ax.set_aspect("equal")
        ax.grid(True, linestyle=":", alpha=0.5)
        ax.set_title("Square plate" if shape == "square" else "Star-shaped plate")
        ax.legend(loc="best")
    fig.tight_layout()
    PACKAGE_FIGS.mkdir(parents=True, exist_ok=True)
    out = PACKAGE_FIGS / "fig08.png"
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    print("saved", out)


if __name__ == "__main__":
    main()
