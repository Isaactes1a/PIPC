# -*- coding: utf-8 -*-
"""Figure 6: nonlinear-heat MQ centres and strong-residual points.

The point layouts are regenerated from the geometry functions of
nonlinear_heat_2d_mq_rbf.py (no saved data file is required).
Output: PIPC_LaTeX_Package/figures/fig06.png
"""

from __future__ import annotations

import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

HERE = Path(__file__).resolve().parent
SRC = HERE.parent / "ablation_pielm"
sys.path.insert(0, str(SRC))
PACKAGE_FIGS = HERE.parents[2] / "PIPC_LaTeX_Package" / "figures"

from nonlinear_heat_2d_mq_rbf import (  # noqa: E402
    GEOMETRIES,
    SPECS,
    koch_snowflake_vertices,
    rbf_discretization,
)


def main() -> None:
    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "xtick.direction": "in",
        "ytick.direction": "in",
        "font.size": 10,
        "axes.titlesize": 11,
        "axes.labelsize": 10,
    })
    fig, axes = plt.subplots(1, 3, figsize=(12.8, 4.25), constrained_layout=True)
    for ax, key in zip(axes, GEOMETRIES):
        centers, bnd, residual_pts = rbf_discretization(key, quick=False)
        bnd_mask = np.zeros(len(centers), dtype=bool)
        bnd_mask[bnd] = True
        if key == "square":
            outline = np.array([[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0]])
        elif key == "equilateral_triangle":
            outline = np.array([[0.0, 0.0], [1.0, 0.0], [0.5, np.sqrt(3.0) / 2.0]])
        else:
            outline = koch_snowflake_vertices(3)
        closed_outline = np.vstack([outline, outline[0]])
        ax.plot(closed_outline[:, 0], closed_outline[:, 1],
                color="0.15", lw=1.2, zorder=1)
        ax.scatter(residual_pts[:, 0], residual_pts[:, 1], s=8, c="#7AA6D8",
                   alpha=0.45, linewidths=0,
                   label="nonlinear residual points", zorder=2)
        ax.scatter(centers[~bnd_mask, 0], centers[~bnd_mask, 1], s=24,
                   facecolors="none", edgecolors="#D95F02", linewidths=0.9,
                   label="interior MQ centres", zorder=3)
        ax.scatter(centers[bnd_mask, 0], centers[bnd_mask, 1], s=27,
                   c="#B2182B", marker="s", linewidths=0,
                   label="boundary MQ centres", zorder=4)
        ax.set_aspect("equal", adjustable="box")
        ax.set_xlabel("x")
        ax.set_ylabel("y")
        ax.set_title(
            f"{SPECS[key].label}\n"
            rf"$N_c={len(centers)},\;N_b={len(bnd)},\;N_r={len(residual_pts)}$",
            fontsize=11,
        )
        ax.grid(True, alpha=0.18)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="outside lower center", ncol=3, frameon=False)
    fig.suptitle(
        r"Nonlinear heat conduction: MQ centres and strong-residual points",
        fontsize=14,
    )

    PACKAGE_FIGS.mkdir(parents=True, exist_ok=True)
    out = PACKAGE_FIGS / "fig06.png"
    fig.savefig(out, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print("saved", out)


if __name__ == "__main__":
    main()
