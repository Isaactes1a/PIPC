# -*- coding: utf-8 -*-
"""Figure 10: nonlinear von Karman square plate, CPI / Newton / PNI + errors.

Layout: 1 row x 5 columns: CPI (TRF), damped Newton reference, PNI
(MQ-RBF prior + PINN), |CPI - Newton|, |PNI - Newton|.

Data: data/plate_cpi_fields_square.npz.
Output: PIPC_LaTeX_Package/figures/fig10.png
"""

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

HERE = Path(__file__).resolve().parent
DATA = HERE / "data"
PACKAGE_FIGS = HERE.parents[2] / "PIPC_LaTeX_Package" / "figures"

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size": 9,
    "axes.titlesize": 9,
    "axes.labelsize": 9,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "savefig.dpi": 300,
})

TITLES = ["CPI (TRF)", "Damped Newton", "PNI",
          r"|CPI $-$ Newton|", r"|PNI $-$ Newton|"]


def field_panel(ax, X, Y, mask, values, vmax, title, cmap, vmin):
    Z = np.full_like(X, np.nan, dtype=float)
    Z.ravel()[mask] = values
    pc = ax.pcolormesh(X, Y, Z, cmap=cmap, vmin=vmin, vmax=vmax,
                       shading="auto")
    ax.set_aspect("equal")
    ax.set_title(title)
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    return pc


def main() -> None:
    z = np.load(DATA / "plate_cpi_fields_square.npz")
    X, Y, mask = z["X"], z["Y"], z["mask"]
    w_cpi, w_new, w_pni = z["w_cpi"], z["w_new"], z["w_pni"]

    fig = plt.figure(figsize=(18.0, 4.4))
    gs = fig.add_gridspec(1, 10, width_ratios=[1.0] * 5 + [0.045] * 5,
                          wspace=0.22)
    axes = [fig.add_subplot(gs[0, c]) for c in range(5)]
    caxes = [fig.add_subplot(gs[0, 5 + c]) for c in range(5)]

    vmax = max(float(np.abs(w_cpi).max()), float(np.abs(w_new).max()),
               float(np.abs(w_pni).max()))
    emax = max(float(np.max(np.abs(w_cpi - w_new))),
               float(np.max(np.abs(w_pni - w_new))), 1e-14)
    panels = [
        (w_cpi, "viridis", -vmax),
        (w_new, "viridis", -vmax),
        (w_pni, "viridis", -vmax),
        (np.abs(w_cpi - w_new), "magma", 0.0),
        (np.abs(w_pni - w_new), "magma", 0.0),
    ]
    for c, (values, cmap, vmin) in enumerate(panels):
        vmax_here = vmax if cmap == "viridis" else emax
        pc = field_panel(axes[c], X, Y, mask, values, vmax_here,
                         TITLES[c], cmap, vmin)
        cb = fig.colorbar(pc, cax=caxes[c])
        cb.ax.tick_params(labelsize=7)

    fig.suptitle(
        "Nonlinear von Kármán plate (square): CPI, damped Newton, PNI "
        "and absolute errors",
        fontsize=13, y=0.99,
    )
    PACKAGE_FIGS.mkdir(parents=True, exist_ok=True)
    out = PACKAGE_FIGS / "fig10.png"
    fig.savefig(out, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("saved", out)


if __name__ == "__main__":
    main()
