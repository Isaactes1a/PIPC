# -*- coding: utf-8 -*-
"""Figure 2: Euler--Bernoulli beam deflection curves and support schematics.

Data: data/beam_latest_fields.npz (CPI/PNI fields and analytical reference
for the three boundary conditions).
Output: PIPC_LaTeX_Package/figures/fig02.png
"""

from __future__ import annotations

import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Polygon, Rectangle
import numpy as np

HERE = Path(__file__).resolve().parent
SRC = HERE.parent / "ablation_pielm"
sys.path.insert(0, str(SRC))
DATA = HERE / "data"
PACKAGE_FIGS = HERE.parents[2] / "PIPC_LaTeX_Package" / "figures"

import beam_ablation_pielm as B  # noqa: E402  (L, exact_solution)


def _draw_fixed_wall(ax, x, side):
    ax.plot([x, x], [-0.13, 0.16], color="black", lw=1.7)
    sign = -1.0 if side == "left" else 1.0
    for y in np.linspace(-0.12, 0.15, 8):
        ax.plot([x, x + sign * 0.045], [y, y - 0.04], color="black", lw=0.8)


def _draw_uniform_load(ax, x0=0.10, x1=0.90):
    ax.plot([x0, x1], [0.30, 0.30], color="black", lw=0.9)
    for xpos in np.linspace(x0, x1, 15):
        ax.annotate(
            "", xy=(xpos, 0.105), xytext=(xpos, 0.30),
            arrowprops=dict(arrowstyle="-|>", color="black", lw=0.75,
                            mutation_scale=7),
        )
    ax.text(0.50, 0.34, r"$q_0=1\,\mathrm{N/m}$", ha="center", va="bottom",
            fontsize=8.5)


def draw_beam_schematic(ax, bc, panel_label):
    ax.set_xlim(0.0, 1.0)
    ax.set_ylim(-0.34, 0.44)
    ax.set_aspect("equal", adjustable="box")
    ax.axis("off")
    beam = Rectangle((0.10, 0.02), 0.80, 0.085, facecolor="white",
                     edgecolor="black", linewidth=1.5)
    ax.add_patch(beam)
    _draw_uniform_load(ax)
    if bc == "CF":
        _draw_fixed_wall(ax, 0.10, "left")
        label = "Cantilever (CF)"
    elif bc == "SS":
        left_triangle = Polygon([[0.10, 0.02], [0.055, -0.10], [0.145, -0.10]],
                                closed=True, facecolor="white", edgecolor="black", lw=1.2)
        ax.add_patch(left_triangle)
        ax.plot([0.035, 0.165], [-0.105, -0.105], color="black", lw=1.1)
        ax.add_patch(Circle((0.90, -0.005), 0.018, facecolor="white",
                            edgecolor="black", lw=1.1))
        right_triangle = Polygon([[0.90, -0.023], [0.855, -0.13], [0.945, -0.13]],
                                 closed=True, facecolor="white", edgecolor="black", lw=1.2)
        ax.add_patch(right_triangle)
        ax.plot([0.835, 0.965], [-0.135, -0.135], color="black", lw=1.1)
        label = "Simply supported (SS)"
    elif bc == "CC":
        _draw_fixed_wall(ax, 0.10, "left")
        _draw_fixed_wall(ax, 0.90, "right")
        label = "Fixed\N{EN DASH}fixed (CC)"
    else:
        raise ValueError(bc)
    ax.text(0.02, -0.26, f"({panel_label})  {label}", ha="left", va="center",
            fontsize=9.0)


def main() -> None:
    z = np.load(DATA / "beam_latest_fields.npz")
    x_eval = z["x"].reshape(-1, 1)
    field_data = {}
    for bc in ["SS", "CC", "CF"]:
        field_data[bc] = {
            "cpi": {"w": z[f"cpi_{bc}_w"].reshape(-1, 1)},
            "pni": {"w": z[f"pni_{bc}_w"].reshape(-1, 1)},
            "reference": {"w": z[f"reference_{bc}_w"].reshape(-1, 1)},
        }

    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "font.size": 9,
        "axes.linewidth": 0.9,
        "xtick.direction": "in",
        "ytick.direction": "in",
    })
    order = [("CF", "a"), ("SS", "b"), ("CC", "c")]
    fig, axes = plt.subplots(
        3, 2, figsize=(8.2, 7.2),
        gridspec_kw={"width_ratios": [1.02, 1.22], "hspace": 0.34, "wspace": 0.18},
    )
    handles = None
    labels = None
    x_flat = np.asarray(x_eval).ravel() / B.L
    for row, (bc, panel_label) in enumerate(order):
        draw_beam_schematic(axes[row, 0], bc, panel_label)
        ax = axes[row, 1]
        reference = field_data[bc]["reference"]["w"].ravel()
        cpi = field_data[bc]["cpi"]["w"].ravel()
        pni = field_data[bc]["pni"]["w"].ravel()
        ax.plot(x_flat, reference, color="black", lw=2.1,
                label="Reference (analytical)", zorder=4)
        ax.plot(x_flat, cpi, color="#2468B4", lw=1.8, ls="--",
                label="CPI (MQ-RBF+TRF)", zorder=5)
        ax.plot(x_flat, pni, color="#E57200", lw=1.35, ls=":", marker="o",
                markevery=32, ms=3.0, mfc="white", mew=0.9,
                label="PNI (MQ-RBF+PINN)", zorder=6)
        max_w = float(np.max(reference))
        ax.set_xlim(0.0, 1.0)
        ax.set_ylim(-0.045 * max_w, 1.08 * max_w)
        ax.set_xticks([0.0, 0.25, 0.5, 0.75, 1.0])
        ax.ticklabel_format(axis="y", style="sci", scilimits=(0, 0), useMathText=True)
        ax.grid(True, color="0.75", lw=0.55, ls=":", alpha=0.65)
        ax.set_ylabel(r"Deflection $w$ (m)")
        if row == 2:
            ax.set_xlabel(r"Normalized coordinate $x/L$")
        if handles is None:
            handles, labels = ax.get_legend_handles_labels()

    fig.suptitle(
        "Euler\N{EN DASH}Bernoulli beam "
        r"($EI=10^3\,\mathrm{N\,m^2}$, $L=1\,\mathrm{m}$)",
        y=0.992, fontsize=10.2,
    )
    fig.legend(handles, labels, loc="lower center", ncol=3, frameon=False,
               bbox_to_anchor=(0.5, 0.008), fontsize=8.2, handlelength=2.5,
               columnspacing=1.5)
    fig.subplots_adjust(left=0.045, right=0.985, top=0.915, bottom=0.095)

    PACKAGE_FIGS.mkdir(parents=True, exist_ok=True)
    out = PACKAGE_FIGS / "fig02.png"
    fig.savefig(out, dpi=400, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("saved", out)


if __name__ == "__main__":
    main()
