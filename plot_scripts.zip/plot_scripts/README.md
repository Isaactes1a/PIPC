# PIPC 论文绘图脚本（一个脚本对应一个图）

本文件夹将论文 `PIPC_LaTeX_Package/compiled/main.pdf` 的全部绘图过程
拆分为独立脚本，每个脚本只负责一张图，并把绘图所需数据复制到 `data/`。

## 图与脚本对应关系

| 论文图 | 内容 | 脚本 | 数据 |
|---|---|---|---|
| Fig. 1 | PIPC 框架示意（人工绘制的示意图，仓库中无生成代码） | — | — |
| Fig. 2 | Euler–Bernoulli 梁挠度与支承示意 | `plot_fig02_beam.py` | `data/beam_latest_fields.npz` |
| Fig. 3 | Burgers MQ 中心 / TRF 残差点 / PNI Sobol 点 | `plot_fig03_burgers_points.py` | `data/burgers_mq_cpi.npz`, `data/burgers_mq_pni.pt` |
| Fig. 4 | Burgers 参考解 / 先验 / CPI / PNI 场与误差 | `plot_fig04_burgers_fields.py` | `data/burgers_mq_fields.npz` |
| Fig. 5 | Burgers 修正历史（CPI TRF / PNI 训练） | `plot_fig05_burgers_histories.py` | `data/burgers_mq_cpi_history.csv`, `data/burgers_mq_pni_history.csv` |
| Fig. 6 | 非线性热传导 MQ 中心与残差点 | `plot_fig06_heat_points.py` | 由几何函数现场生成（无需数据文件） |
| Fig. 7 | 非线性热传导 FEM / CPI / PNI 场与误差 | `plot_fig07_heat_fields.py` | `data/nonlinear_heat_2d_results.json`, `data/nonlinear_heat_2d_fields.npz` |
| Fig. 8 | 方板 / 星板配点布局 | `plot_fig08_plate_points.py` | `data/plate_cpi_fields_square.npz`, `data/plate_cpi_fields_star.npz` |
| Fig. 9 | 线性 Reissner–Mindlin 板 RBF 先验 vs FEM 参考 | `plot_fig09_plate_linear_rm.py` | `data/plate_rm_linear_fields.npz` |
| Fig. 10 | 非线性 von Kármán 方板 CPI vs Newton | `plot_fig10_plate_vk_square.py` | `data/plate_cpi_fields_square.npz` |
| Fig. 11 | 非线性 von Kármán 星板 CPI vs Newton | `plot_fig11_plate_vk_star.py` | `data/plate_cpi_fields_star.npz` |

探索性图（论文未采用）：

| 图 | 脚本 | 说明 |
|---|---|---|
| `outputs/plate_linear_2x3.png` | `plot_extra_plate_linear_2x3.py` | 5 场 RM 线性板 2×3 对比（现场计算，缓存于 `data/plate_2x3_fields.npz`） |
| `outputs/plate_nonlinear_2x3.png` | `plot_extra_plate_nonlinear_2x3.py` | 5 场 RM–von Kármán 非线性 2×3 对比（现场计算） |

## 数据来源

`data/` 中的文件是从 `../ablation_pielm/` 复制/生成的一份独立副本：

- 梁：`beam_latest_fields.npz`（CPI/PNI/解析参考场）；
- Burgers：`burgers_mq_cpi.npz`、`burgers_mq_pni.pt`、
  `burgers_mq_fields.npz`、两个 history CSV；
- 热传导：`nonlinear_heat_2d_results.json`、`nonlinear_heat_2d_fields.npz`；
- 板：`plate_cpi_fields_{square,star}.npz` 与
  `plate_rm_linear_fields.npz` 由 `_prepare_plate_data.py`
  一次性生成（运行一次即可）；
- 探索性 2×3 图：`data/plate_2x3_fields.npz` 由对应脚本首次运行时生成。

## 使用方法

```powershell
# 1) 首次使用先生成板图缓存（约几分钟，含 FEM 求解）
python _prepare_plate_data.py

# 2) 逐图生成（输出到 PIPC_LaTeX_Package/figures/figNN.png）
python plot_fig02_beam.py
python plot_fig03_burgers_points.py
python plot_fig04_burgers_fields.py
python plot_fig05_burgers_histories.py
python plot_fig06_heat_points.py
python plot_fig07_heat_fields.py
python plot_fig08_plate_points.py
python plot_fig09_plate_linear_rm.py
python plot_fig10_plate_vk_square.py
python plot_fig11_plate_vk_star.py
```

脚本依赖 `../ablation_pielm/` 中的求解/几何模块（自动加入 `sys.path`）。
原组合脚本中的绘图函数保留在原文件中以便向后兼容；本文件夹是
按“一图一脚本”组织的规范绘图入口。
