# -*- coding: utf-8 -*-
"""Exploratory figure: nonlinear RM-vK plate, 2x3 (square/star x result/ref/error).

Computed on the fly by _plate_2x3_common (cached in data/plate_2x3_fields.npz).
Output: outputs/plate_nonlinear_2x3.png
"""

from __future__ import annotations

from pathlib import Path

import _plate_2x3_common as C

HERE = Path(__file__).resolve().parent
OUT_DIR = HERE / "outputs"


def main() -> None:
    d = C.load_or_compute()
    rows = [
        ("Square plate (nonlinear)", dict(
            X=d["X_sq"], Y=d["Y_sq"], mask=d["mask_sq"],
            result=d["nl_sq_result"], ref=d["nl_sq_ref"],
            err=d["nl_sq_err"])),
        ("Star plate (nonlinear)", dict(
            X=d["X_st"], Y=d["Y_st"], mask=d["mask_st"],
            result=d["nl_st_result"], ref=d["nl_st_ref"],
            err=d["nl_st_err"])),
    ]
    C.plot_2x3("plate_nonlinear_2x3.png", rows,
               ["PIPC-CPI (TRF)", "Damped Newton reference",
                "|error| vs Newton"], OUT_DIR)


if __name__ == "__main__":
    main()
