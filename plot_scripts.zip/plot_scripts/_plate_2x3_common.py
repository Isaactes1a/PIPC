# -*- coding: utf-8 -*-
"""Shared computation helpers for the two exploratory 2x3 plate figures."""

from __future__ import annotations

import os
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
SRC = HERE.parent / "ablation_pielm"
sys.path.insert(0, str(SRC))

import plate_rm as R  # noqa: E402
import plate_rm_vk_rbf_weak as M  # noqa: E402

DATA = HERE / "data"
CACHE_NPZ = DATA / "plate_2x3_fields.npz"

CFG_SQ = dict(E=1e5, nu=0.3, h=0.05, q=0.25, c=0.6,
              N_grid=20, N_bnd=120, N_layers=8)
CFG_ST = dict(E=1e5, nu=0.3, h=0.05, q=0.25, c=0.15,
              N_grid=20, N_bnd=120, N_layers=12)
FEM_LEVEL = {"square": 5, "star": 4}


def eval_w_field(sol, grid_pts):
    return M.eval_w(sol, grid_pts)


def linear_prior_w(shape, cfg):
    ctx = M.build_rm_system(shape, cfg)
    u0 = np.linalg.solve(ctx["Klin"], ctx["Flin"])
    n_r = ctx["n_r"]
    return dict(pts=ctx["pts"],
                lam_w=ctx["Z"] @ u0[2 * n_r:3 * n_r],
                c=cfg["c"])


def solve_newton_ref(shape, cfg, max_iter=12, tol=1e-9):
    ctx = M.build_rm_system(shape, cfg)
    u = np.linalg.solve(ctx["Klin"], ctx["Flin"])
    for _ in range(max_iter):
        r, J = M.residual_jac(u, ctx)
        if np.linalg.norm(r) < tol:
            break
        try:
            d = np.linalg.solve(J, -r)
        except np.linalg.LinAlgError:
            d = np.linalg.lstsq(J, -r, rcond=1e-13)[0]
        step = d
        for _ in range(24):
            rn2 = np.linalg.norm(M.residual_jac(u + step, ctx)[0])
            if rn2 < np.linalg.norm(r):
                break
            step = 0.5 * step
        u = u + step
    n_r = ctx["n_r"]
    return dict(pts=ctx["pts"],
                lam_w=ctx["Z"] @ u[2 * n_r:3 * n_r],
                c=cfg["c"])


def compute_linear(shape, cfg):
    X, Y, pts, mask = R.fine_grid(shape)
    gpts = pts[mask]
    sol = linear_prior_w(shape, cfg)
    w_rbf = eval_w_field(sol, gpts)
    cpts, cells, U, pts_p2 = R.fem_solve(shape, FEM_LEVEL[shape],
                                         h=cfg["h"], q0=cfg["q"])
    w_fem = R.fem_field(pts_p2, cells, U, gpts, cpts)
    err = np.abs(w_rbf - w_fem)
    rel = np.linalg.norm(err) / (np.linalg.norm(w_fem) + 1e-14)
    print(f"[linear {shape}] |w_rbf|max={np.abs(w_rbf).max():.4e}  "
          f"|w_fem|max={np.abs(w_fem).max():.4e}  "
          f"|err|max={err.max():.3e}  rel L2={rel:.3%}")
    return dict(X=X, Y=Y, mask=mask, result=w_rbf, ref=w_fem, err=err)


def compute_nonlinear(shape, cfg):
    X, Y, pts, mask = R.fine_grid(shape)
    gpts = pts[mask]
    t0 = time.perf_counter()
    sol_trf = M.solve_rm_vk_rbf(shape, cfg, max_nfev=200, xtol=1e-12, verbose=1)
    w_trf = eval_w_field(sol_trf, gpts)
    print(f"[nonlinear {shape}] TRF done: nfev={sol_trf['nfev']} "
          f"resid={sol_trf['residual']:.1e}  t={time.perf_counter()-t0:.0f}s",
          flush=True)
    t0 = time.perf_counter()
    sol_new = solve_newton_ref(shape, cfg)
    w_new = eval_w_field(sol_new, gpts)
    print(f"[nonlinear {shape}] Newton ref done: t={time.perf_counter()-t0:.0f}s",
          flush=True)
    err = np.abs(w_trf - w_new)
    rel = np.linalg.norm(err) / (np.linalg.norm(w_new) + 1e-14)
    print(f"[nonlinear {shape}] |w_trf|max={np.abs(w_trf).max():.4e}  "
          f"|w_new|max={np.abs(w_new).max():.4e}  "
          f"|err|max={err.max():.3e}  rel L2={rel:.3e}")
    return dict(X=X, Y=Y, mask=mask, result=w_trf, ref=w_new, err=err)


def load_or_compute():
    if CACHE_NPZ.exists():
        try:
            z = np.load(CACHE_NPZ, allow_pickle=False)
            keys = ["lin_sq_result", "lin_sq_ref", "lin_sq_err",
                    "lin_st_result", "lin_st_ref", "lin_st_err",
                    "nl_sq_result", "nl_sq_ref", "nl_sq_err",
                    "nl_st_result", "nl_st_ref", "nl_st_err",
                    "X_sq", "Y_sq", "mask_sq", "X_st", "Y_st", "mask_st"]
            if all(k in z for k in keys):
                print("loading cached fields from", CACHE_NPZ)
                d = {k: z[k] for k in keys}
                d["mask_sq"] = d["mask_sq"].astype(bool)
                d["mask_st"] = d["mask_st"].astype(bool)
                return d
        except Exception as exc:
            print("cache load failed:", exc)

    print("computing linear square ...", flush=True)
    lin_sq = compute_linear("square", CFG_SQ)
    print("computing linear star ...", flush=True)
    lin_st = compute_linear("star", CFG_ST)
    print("computing nonlinear square ...", flush=True)
    nl_sq = compute_nonlinear("square", CFG_SQ)
    print("computing nonlinear star ...", flush=True)
    nl_st = compute_nonlinear("star", CFG_ST)

    data = {
        "lin_sq_result": lin_sq["result"], "lin_sq_ref": lin_sq["ref"],
        "lin_sq_err": lin_sq["err"],
        "lin_st_result": lin_st["result"], "lin_st_ref": lin_st["ref"],
        "lin_st_err": lin_st["err"],
        "nl_sq_result": nl_sq["result"], "nl_sq_ref": nl_sq["ref"],
        "nl_sq_err": nl_sq["err"],
        "nl_st_result": nl_st["result"], "nl_st_ref": nl_st["ref"],
        "nl_st_err": nl_st["err"],
        "X_sq": lin_sq["X"], "Y_sq": lin_sq["Y"],
        "mask_sq": lin_sq["mask"].astype(np.int8),
        "X_st": lin_st["X"], "Y_st": lin_st["Y"],
        "mask_st": lin_st["mask"].astype(np.int8),
    }
    DATA.mkdir(parents=True, exist_ok=True)
    np.savez(CACHE_NPZ, **data)
    print("saved fields ->", CACHE_NPZ)
    data["mask_sq"] = data["mask_sq"].astype(bool)
    data["mask_st"] = data["mask_st"].astype(bool)
    return data


def plot_2x3(fname, rows, col_labels, out_dir):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "xtick.direction": "in",
        "ytick.direction": "in",
        "font.size": 10,
        "axes.titlesize": 10,
        "axes.labelsize": 9,
        "savefig.dpi": 200,
    })
    fig, axes = plt.subplots(2, 3, figsize=(17.0, 9.6))
    for row, (label, d) in enumerate(rows):
        X, Y, mask = d["X"], d["Y"], d["mask"]
        for col, key in enumerate(("result", "ref", "err")):
            vals = np.asarray(d[key], dtype=float)
            vmin = float(np.nanmin(vals))
            vmax = float(np.nanmax(vals))
            Z = np.full_like(X, np.nan, dtype=float)
            Z.ravel()[mask] = vals
            cmap = "viridis" if key != "err" else "magma"
            pc = axes[row, col].pcolormesh(X, Y, Z, cmap=cmap,
                                           vmin=vmin, vmax=vmax, shading="auto")
            axes[row, col].set_aspect("equal")
            axes[row, col].set_title(f"{label} - {col_labels[col]}")
            axes[row, col].set_xlabel("x")
            axes[row, col].set_ylabel("y")
            cb = fig.colorbar(pc, ax=axes[row, col], fraction=0.046, pad=0.04)
            cb.mappable.set_clim(vmin, vmax)
    fig.tight_layout()
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / fname
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    print("saved", out)
